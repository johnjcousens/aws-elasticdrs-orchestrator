"""
AWS DRS Orchestration - API Handler Lambda
Handles REST API requests for Protection Groups, Recovery Plans, and Executions
"""

import json
import os
import uuid
import time
import re
from datetime import datetime, timezone
import boto3
from boto3.dynamodb.conditions import Key, Attr
from decimal import Decimal
from typing import Dict, Any, List, Optional

# Initialize AWS clients
dynamodb = boto3.resource('dynamodb')
stepfunctions = boto3.client('stepfunctions')
drs = boto3.client('drs')
lambda_client = boto3.client('lambda')

# Environment variables
PROTECTION_GROUPS_TABLE = os.environ['PROTECTION_GROUPS_TABLE']
RECOVERY_PLANS_TABLE = os.environ['RECOVERY_PLANS_TABLE']
EXECUTION_HISTORY_TABLE = os.environ['EXECUTION_HISTORY_TABLE']
TARGET_ACCOUNTS_TABLE = os.environ.get('TARGET_ACCOUNTS_TABLE', '')
STATE_MACHINE_ARN = os.environ.get('STATE_MACHINE_ARN', '')

# All 28 commercial AWS regions where DRS is available
DRS_REGIONS = [
    # Americas (6)
    'us-east-1', 'us-east-2', 'us-west-1', 'us-west-2', 'ca-central-1', 'sa-east-1',
    # Europe (8)
    'eu-west-1', 'eu-west-2', 'eu-west-3', 'eu-central-1', 'eu-central-2',
    'eu-north-1', 'eu-south-1', 'eu-south-2',
    # Asia Pacific (10)
    'ap-northeast-1', 'ap-northeast-2', 'ap-northeast-3', 'ap-southeast-1',
    'ap-southeast-2', 'ap-southeast-3', 'ap-southeast-4', 'ap-south-1', 'ap-south-2', 'ap-east-1',
    # Middle East & Africa (4)
    'me-south-1', 'me-central-1', 'af-south-1', 'il-central-1',
]

# DRS Service Limits (from AWS Service Quotas)
# Reference: https://docs.aws.amazon.com/general/latest/gr/drs.html
DRS_LIMITS = {
    'MAX_SERVERS_PER_JOB': 100,           # L-B827C881 - Hard limit
    'MAX_CONCURRENT_JOBS': 20,             # L-D88FAC3A - Hard limit
    'MAX_SERVERS_IN_ALL_JOBS': 500,        # L-05AFA8C6 - Hard limit
    'MAX_REPLICATING_SERVERS': 300,        # L-C1D14A2B - Hard limit (cannot increase)
    'MAX_SOURCE_SERVERS': 4000,            # L-E28BE5E0 - Adjustable
    'WARNING_REPLICATING_THRESHOLD': 250,  # Show warning at 83%
    'CRITICAL_REPLICATING_THRESHOLD': 280  # Block new servers at 93%
}

# Valid replication states for recovery
# Note: DRS API returns 'CONTINUOUS' not 'CONTINUOUS_REPLICATION'
VALID_REPLICATION_STATES = [
    'CONTINUOUS',
    'INITIAL_SYNC',
    'RESCAN'
]

INVALID_REPLICATION_STATES = [
    'DISCONNECTED',
    'STOPPED',
    'STALLED',
    'NOT_STARTED'
]

# DynamoDB tables
protection_groups_table = dynamodb.Table(PROTECTION_GROUPS_TABLE)
recovery_plans_table = dynamodb.Table(RECOVERY_PLANS_TABLE)
execution_history_table = dynamodb.Table(EXECUTION_HISTORY_TABLE)
# Initialize target accounts table only if environment variable is set
if TARGET_ACCOUNTS_TABLE:
    target_accounts_table = dynamodb.Table(TARGET_ACCOUNTS_TABLE)
else:
    target_accounts_table = None


def get_cognito_user_from_event(event: Dict) -> Dict:
    """Extract Cognito user info from API Gateway authorizer"""
    try:
        authorizer = event.get('requestContext', {}).get('authorizer', {})
        claims = authorizer.get('claims', {})
        return {
            'email': claims.get('email', 'system'),
            'userId': claims.get('sub', 'system'),
            'username': claims.get('cognito:username', 'system')
        }
    except Exception as e:
        print(f"Error extracting Cognito user: {e}")
        return {'email': 'system', 'userId': 'system', 'username': 'system'}


class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder for DynamoDB Decimal types"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super(DecimalEncoder, self).default(obj)


# ============================================================================
# Cross-Account Support Functions
# ============================================================================

def determine_target_account_context(plan: Dict) -> Dict:
    """
    Determine the target account context for multi-account hub and spoke architecture.
    
    This function determines which target account to use for DRS operations by:
    1. Checking Protection Groups in the Recovery Plan for AccountId
    2. Falling back to default target account from settings (if implemented)
    3. Using current account as final fallback
    
    Args:
        plan: Recovery Plan dictionary containing Waves with ProtectionGroupId references
    
    Returns:
        Dict with AccountId, AssumeRoleName, and isCurrentAccount for cross-account access
    """
    try:
        # FIX #1: Better current account detection with environment variable fallback
        try:
            current_account_id = get_current_account_id()
            if current_account_id == "unknown":
                # In test environment, use environment variable fallback
                current_account_id = os.environ.get('AWS_ACCOUNT_ID')
                if not current_account_id:
                    raise ValueError("Unable to determine current account ID and no AWS_ACCOUNT_ID environment variable set")
                print(f"Using AWS_ACCOUNT_ID environment variable for current account: {current_account_id}")
        except Exception as e:
            # In test environment, use environment variable fallback
            current_account_id = os.environ.get('AWS_ACCOUNT_ID')
            if not current_account_id:
                raise ValueError(f"Unable to determine current account ID: {e}")
            print(f"Using AWS_ACCOUNT_ID environment variable for current account: {current_account_id}")
        
        waves = plan.get('Waves', [])
        
        # Collect unique account IDs from all Protection Groups in the plan
        all_target_account_ids = set()
        
        for wave in waves:
            pg_id = wave.get('ProtectionGroupId')
            if not pg_id:
                continue
                
            try:
                # Get Protection Group to check its AccountId
                pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
                if 'Item' in pg_result:
                    pg = pg_result['Item']
                    account_id = pg.get('AccountId')
                    if account_id and account_id.strip():
                        all_target_account_ids.add(account_id.strip())
                        print(f"Found target account {account_id} from Protection Group {pg_id}")
            except Exception as e:
                print(f"Error getting Protection Group {pg_id}: {e}")
                continue
        
        # FIX #2: Enforce mixed account validation - throw exception instead of warning
        if len(all_target_account_ids) > 1:
            raise ValueError(
                f"Recovery Plan contains Protection Groups from multiple accounts: {all_target_account_ids}. "
                f"Multi-account Recovery Plans are not supported. "
                f"Please create separate Recovery Plans for each account."
            )
        
        # Check if all protection groups are in current account
        if not all_target_account_ids or (len(all_target_account_ids) == 1 and current_account_id in all_target_account_ids):
            # All protection groups are in current account (or no protection groups found)
            print(f"All Protection Groups are in current account {current_account_id}")
            return {
                'AccountId': current_account_id,
                'AssumeRoleName': None,  # No role assumption needed for current account
                'isCurrentAccount': True
            }
        
        # Single cross-account target
        target_account_id = next(iter(all_target_account_ids))
        
        # Get target account configuration from target accounts table
        if target_accounts_table:
            try:
                account_result = target_accounts_table.get_item(Key={'AccountId': target_account_id})
                if 'Item' in account_result:
                    account_config = account_result['Item']
                    assume_role_name = account_config.get('AssumeRoleName') or account_config.get('CrossAccountRoleArn', '').split('/')[-1]
                    
                    print(f"Using target account {target_account_id} with role {assume_role_name}")
                    return {
                        'AccountId': target_account_id,
                        'AssumeRoleName': assume_role_name,
                        'isCurrentAccount': False
                    }
                else:
                    print(f"WARNING: Target account {target_account_id} not found in target accounts table")
            except Exception as e:
                print(f"Error getting target account configuration for {target_account_id}: {e}")
        
        # Fallback: target account found but no configuration - assume standard role name
        print(f"Using target account {target_account_id} with default role name")
        return {
            'AccountId': target_account_id,
            'AssumeRoleName': 'DRSOrchestrationCrossAccountRole',  # Default role name
            'isCurrentAccount': False
        }
        
    except Exception as e:
        print(f"Error determining target account context: {e}")
        # Re-raise the exception instead of silently falling back
        raise


def create_drs_client(region: str, account_context: Optional[Dict] = None):
    """
    Create DRS client with optional cross-account role assumption.
    
    Args:
        region: AWS region for the DRS client
        account_context: Optional dict with AccountId and AssumeRoleName for cross-account access
    
    Returns:
        boto3 DRS client configured for the target account
    """
    # If no account context provided or it's current account, use current account
    if not account_context or account_context.get('isCurrentAccount', True):
        print(f"Creating DRS client for current account in region {region}")
        return boto3.client('drs', region_name=region)
    
    # FIX #3: Improved cross-account role validation and error handling
    account_id = account_context.get('AccountId')
    assume_role_name = account_context.get('AssumeRoleName')
    
    if not account_id:
        raise ValueError("Cross-account operation requires AccountId in account_context")
    
    if not assume_role_name:
        raise ValueError(
            f"Cross-account operation requires AssumeRoleName for account {account_id}. "
            f"Please ensure the target account is registered with a valid cross-account role."
        )
    
    print(f"Creating cross-account DRS client for account {account_id} using role {assume_role_name}")
    
    try:
        # Assume role in target account
        sts_client = boto3.client('sts', region_name=region)
        role_arn = f"arn:aws:iam::{account_id}:role/{assume_role_name}"
        session_name = f"drs-orchestration-{int(time.time())}"
        
        print(f"Assuming role: {role_arn}")
        
        assumed_role = sts_client.assume_role(
            RoleArn=role_arn,
            RoleSessionName=session_name,
            DurationSeconds=3600  # 1 hour
        )
        
        credentials = assumed_role['Credentials']
        
        # Create DRS client with assumed role credentials
        drs_client = boto3.client(
            'drs',
            region_name=region,
            aws_access_key_id=credentials['AccessKeyId'],
            aws_secret_access_key=credentials['SecretAccessKey'],
            aws_session_token=credentials['SessionToken']
        )
        
        print(f"Successfully created cross-account DRS client for account {account_id}")
        return drs_client
        
    except Exception as e:
        # FIX #3: Don't fall back silently - raise clear error messages
        error_msg = f"Failed to assume cross-account role for account {account_id}: {e}"
        
        if "AccessDenied" in str(e):
            error_msg += (
                f"\n\nPossible causes:\n"
                f"1. Cross-account role '{assume_role_name}' does not exist in account {account_id}\n"
                f"2. Trust relationship not configured to allow this hub account\n"
                f"3. Insufficient permissions on the cross-account role\n"
                f"4. Role ARN: {role_arn}\n\n"
                f"Please verify the cross-account role is deployed and configured correctly."
            )
        elif "InvalidUserID.NotFound" in str(e):
            error_msg += f"\n\nThe role '{assume_role_name}' does not exist in account {account_id}."
        
        print(f"Cross-account role assumption failed: {error_msg}")
        raise RuntimeError(error_msg)





def response(status_code: int, body: Any, headers: Optional[Dict] = None) -> Dict:
    """Generate API Gateway response with CORS headers"""
    default_headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
    }
    if headers:
        default_headers.update(headers)
    
    return {
        'statusCode': status_code,
        'headers': default_headers,
        'body': json.dumps(body, cls=DecimalEncoder)
    }


# ============================================================================
# Conflict Detection Helpers
# ============================================================================

# Active execution statuses that indicate an execution is still running
ACTIVE_EXECUTION_STATUSES = ['PENDING', 'POLLING', 'INITIATED', 'LAUNCHING', 'STARTED', 
                             'IN_PROGRESS', 'RUNNING', 'PAUSED', 'CANCELLING']

# DRS job statuses that indicate servers are still being processed
DRS_ACTIVE_JOB_STATUSES = ['PENDING', 'STARTED']


def get_servers_in_active_drs_jobs(region: str, account_context: Optional[Dict] = None) -> Dict[str, Dict]:
    """
    Query DRS for servers currently being processed by active LAUNCH jobs.
    This catches conflicts even when DynamoDB execution records are stale/failed.
    
    Returns dict mapping server_id -> {jobId, jobStatus, jobType}
    """
    servers_in_drs_jobs = {}
    
    try:
        # Get DRS client for the appropriate account/region
        drs_client = create_drs_client(region, account_context)
        print(f"[DRS Job Check] Querying DRS jobs in region {region}")
        
        # Get all jobs (no filter = all jobs)
        # Note: describe_jobs without filters returns recent jobs
        jobs_response = drs_client.describe_jobs(maxResults=100)
        
        jobs_found = jobs_response.get('items', [])
        print(f"[DRS Job Check] Found {len(jobs_found)} total jobs in {region}")
        
        for job in jobs_found:
            job_id = job.get('jobID')
            job_status = job.get('status', '')
            job_type = job.get('type', '')
            
            print(f"[DRS Job Check] Job {job_id}: type={job_type}, status={job_status}")
            
            # Only check active LAUNCH jobs (not TERMINATE, CREATE_CONVERTED_SNAPSHOT, etc.)
            if job_type == 'LAUNCH' and job_status in DRS_ACTIVE_JOB_STATUSES:
                # Get servers participating in this job
                for server in job.get('participatingServers', []):
                    server_id = server.get('sourceServerID')
                    if server_id:
                        servers_in_drs_jobs[server_id] = {
                            'jobId': job_id,
                            'jobStatus': job_status,
                            'jobType': job_type,
                            'launchStatus': server.get('launchStatus', 'UNKNOWN')
                        }
                        print(f"[DRS Job Check] Server {server_id} in active job {job_id}")
        
        print(f"[DRS Job Check] Found {len(servers_in_drs_jobs)} servers in active DRS jobs in {region}")
        return servers_in_drs_jobs
        
    except Exception as e:
        print(f"[DRS Job Check] Error checking DRS jobs in {region}: {e}")
        import traceback
        traceback.print_exc()
        return {}


def get_active_executions_for_plan(plan_id: str) -> List[Dict]:
    """Get all active executions for a specific recovery plan"""
    try:
        # Try GSI first
        try:
            result = execution_history_table.query(
                IndexName='PlanIdIndex',
                KeyConditionExpression=Key('PlanId').eq(plan_id)
            )
            executions = result.get('Items', [])
        except Exception:
            # Fallback to scan
            result = execution_history_table.scan(
                FilterExpression=Attr('PlanId').eq(plan_id)
            )
            executions = result.get('Items', [])
        
        # Filter to active statuses
        return [e for e in executions if e.get('Status', '').upper() in ACTIVE_EXECUTION_STATUSES]
    except Exception as e:
        print(f"Error checking active executions for plan {plan_id}: {e}")
        return []


def get_active_execution_for_protection_group(group_id: str) -> Optional[Dict]:
    """
    Check if a protection group is part of any active execution.
    Returns execution info if found, None otherwise.
    """
    try:
        # First, find all recovery plans that use this protection group
        plans_result = recovery_plans_table.scan()
        all_plans = plans_result.get('Items', [])
        
        # Handle pagination
        while 'LastEvaluatedKey' in plans_result:
            plans_result = recovery_plans_table.scan(
                ExclusiveStartKey=plans_result['LastEvaluatedKey']
            )
            all_plans.extend(plans_result.get('Items', []))
        
        # Find plan IDs that reference this protection group
        plan_ids_with_pg = []
        for plan in all_plans:
            for wave in plan.get('Waves', []):
                pg_id_in_wave = wave.get('ProtectionGroupId')
                if pg_id_in_wave == group_id:
                    plan_ids_with_pg.append(plan.get('PlanId'))
                    break
        
        if not plan_ids_with_pg:
            return None  # PG not used in any plan
        
        # Check if any of these plans have active executions
        for plan_id in plan_ids_with_pg:
            active_executions = get_active_executions_for_plan(plan_id)
            if active_executions:
                exec_info = active_executions[0]
                # Get plan name
                plan = next((p for p in all_plans if p.get('PlanId') == plan_id), {})
                return {
                    'executionId': exec_info.get('ExecutionId'),
                    'planId': plan_id,
                    'planName': plan.get('PlanName', 'Unknown'),
                    'status': exec_info.get('Status')
                }
        
        return None
    except Exception as e:
        print(f"Error checking active execution for protection group: {e}")
        return None


def get_all_active_executions() -> List[Dict]:
    """Get all active executions across all plans"""
    try:
        # Try StatusIndex GSI first
        active_executions = []
        for status in ACTIVE_EXECUTION_STATUSES:
            try:
                result = execution_history_table.query(
                    IndexName='StatusIndex',
                    KeyConditionExpression=Key('Status').eq(status)
                )
                active_executions.extend(result.get('Items', []))
            except Exception:
                pass  # GSI might not exist for all statuses
        
        # If no results from GSI, fallback to scan
        if not active_executions:
            result = execution_history_table.scan()
            all_executions = result.get('Items', [])
            active_executions = [e for e in all_executions 
                                if e.get('Status', '').upper() in ACTIVE_EXECUTION_STATUSES]
        
        return active_executions
    except Exception as e:
        print(f"Error getting all active executions: {e}")
        return []


def get_servers_in_active_executions() -> Dict[str, Dict]:
    """
    Get all servers currently in active executions.
    Returns dict mapping server_id -> {execution_id, plan_id, wave_name, status}
    
    For tag-based Protection Groups, we resolve servers at check time by:
    1. Looking at ServerStatuses in execution waves (servers already resolved)
    2. For PAUSED/PENDING executions, resolving remaining waves' PGs via tags
    """
    active_executions = get_all_active_executions()
    servers_in_use = {}
    
    # Cache for recovery plans and protection groups
    plan_cache = {}
    pg_cache = {}
    
    for execution in active_executions:
        execution_id = execution.get('ExecutionId')
        plan_id = execution.get('PlanId')
        exec_status = execution.get('Status', '').upper()
        
        # First, check ServerStatuses in execution waves (already resolved servers)
        for wave in execution.get('Waves', []):
            wave_name = wave.get('WaveName', 'Unknown')
            wave_status = wave.get('Status', '')
            
            for server in wave.get('ServerStatuses', []):
                server_id = server.get('SourceServerId')
                launch_status = server.get('LaunchStatus', '')
                # Track servers not yet launched
                if server_id and launch_status.upper() not in ['LAUNCHED', 'FAILED', 'TERMINATED']:
                    servers_in_use[server_id] = {
                        'executionId': execution_id,
                        'planId': plan_id,
                        'waveName': wave_name,
                        'launchStatus': launch_status,
                        'executionStatus': exec_status
                    }
        
        # For ALL active executions, resolve servers from the recovery plan's protection groups
        # This ensures we catch conflicts even if ServerStatuses isn't populated yet
        if plan_id not in plan_cache:
            try:
                plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
                plan_cache[plan_id] = plan_result.get('Item', {})
            except Exception as e:
                print(f"Error fetching plan {plan_id}: {e}")
                plan_cache[plan_id] = {}
        
        plan = plan_cache.get(plan_id, {})
        current_wave = execution.get('CurrentWave', 1)
        
        # Convert Decimal to int if needed
        if hasattr(current_wave, '__int__'):
            current_wave = int(current_wave)
        
        # Get servers from all waves (for active executions, all servers are "in use")
        for idx, wave in enumerate(plan.get('Waves', []), start=1):
            wave_name = wave.get('WaveName', f'Wave {idx}')
            
            # Get Protection Group ID for this wave
            pg_id = wave.get('ProtectionGroupId') or (wave.get('ProtectionGroupIds', []) or [None])[0]
            
            if pg_id:
                # Resolve servers from Protection Group (handles both tags and explicit IDs)
                server_ids = resolve_pg_servers_for_conflict_check(pg_id, pg_cache)
                for server_id in server_ids:
                    # Only add if not already tracked (ServerStatuses takes precedence)
                    if server_id not in servers_in_use:
                        servers_in_use[server_id] = {
                            'executionId': execution_id,
                            'planId': plan_id,
                            'waveName': wave_name,
                            'waveStatus': f'Wave {idx}' if idx <= current_wave else 'PENDING',
                            'executionStatus': exec_status
                        }
    
    return servers_in_use


def resolve_pg_servers_for_conflict_check(pg_id: str, pg_cache: Dict, account_context: Optional[Dict] = None) -> List[str]:
    """
    Resolve a Protection Group to server IDs for conflict checking.
    Handles both tag-based and explicit server ID selection.
    """
    if pg_id in pg_cache:
        return pg_cache[pg_id]
    
    try:
        pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
        pg = pg_result.get('Item', {})
        
        if not pg:
            pg_cache[pg_id] = []
            return []
        
        region = pg.get('Region', 'us-east-1')
        selection_tags = pg.get('ServerSelectionTags', {})
        source_server_ids = pg.get('SourceServerIds', [])
        
        # Extract account context from Protection Group if not provided
        if not account_context and pg.get('AccountId'):
            account_context = {
                'AccountId': pg.get('AccountId'),
                'AssumeRoleName': pg.get('AssumeRoleName')
            }
        
        if selection_tags:
            # Resolve servers by tags
            resolved = query_drs_servers_by_tags(region, selection_tags, account_context)
            server_ids = [s.get('sourceServerID') for s in resolved if s.get('sourceServerID')]
        elif source_server_ids:
            # Use explicit server IDs
            server_ids = source_server_ids
        else:
            server_ids = []
        
        pg_cache[pg_id] = server_ids
        return server_ids
        
    except Exception as e:
        print(f"Error resolving PG {pg_id} for conflict check: {e}")
        pg_cache[pg_id] = []
        return []


def check_server_conflicts(plan: Dict, account_context: Optional[Dict] = None) -> List[Dict]:
    """
    Check if any servers in the plan are currently in active executions OR active DRS jobs.
    Returns list of conflicts with details.
    
    For tag-based Protection Groups, resolves servers at check time.
    Also checks DRS directly for active LAUNCH jobs (catches stale DynamoDB records).
    """
    print(f"[Conflict Check] Starting conflict check for plan {plan.get('PlanId')}")
    print(f"[Conflict Check] Account context: {account_context}")
    
    servers_in_use = get_servers_in_active_executions()
    print(f"[Conflict Check] Servers in active executions: {list(servers_in_use.keys())}")
    
    conflicts = []
    pg_cache = {}
    checked_regions = set()
    drs_servers_by_region = {}
    
    for wave in plan.get('Waves', []):
        wave_name = wave.get('WaveName', 'Unknown')
        
        # Get Protection Group ID for this wave
        pg_id = wave.get('ProtectionGroupId') or (wave.get('ProtectionGroupIds', []) or [None])[0]
        print(f"[Conflict Check] Wave '{wave_name}' has PG: {pg_id}")
        
        if pg_id:
            # Get PG to find region
            if pg_id not in pg_cache:
                try:
                    pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
                    pg_cache[pg_id] = pg_result.get('Item', {})
                except Exception as e:
                    print(f"[Conflict Check] Error fetching PG {pg_id}: {e}")
                    pg_cache[pg_id] = {}
            
            pg = pg_cache.get(pg_id, {})
            region = pg.get('Region', 'us-east-1')
            print(f"[Conflict Check] PG {pg_id} is in region {region}")
            
            # Check DRS jobs for this region (once per region)
            if region not in checked_regions:
                checked_regions.add(region)
                print(f"[Conflict Check] Checking DRS jobs in region {region}")
                drs_servers_by_region[region] = get_servers_in_active_drs_jobs(region, account_context)
                print(f"[Conflict Check] DRS servers in {region}: {list(drs_servers_by_region[region].keys())}")
            
            # Resolve servers from Protection Group tags
            server_ids = resolve_pg_servers_for_conflict_check(pg_id, pg_cache)
            print(f"[Conflict Check] Resolved {len(server_ids)} servers from PG {pg_id}: {server_ids}")
            
            for server_id in server_ids:
                # Check DynamoDB execution conflicts
                if server_id in servers_in_use:
                    conflict_info = servers_in_use[server_id]
                    print(f"[Conflict Check] Server {server_id} has execution conflict")
                    conflicts.append({
                        'serverId': server_id,
                        'waveName': wave_name,
                        'conflictingExecutionId': conflict_info['executionId'],
                        'conflictingPlanId': conflict_info['planId'],
                        'conflictingWaveName': conflict_info.get('waveName'),
                        'conflictingStatus': conflict_info.get('executionStatus'),
                        'conflictSource': 'execution'
                    })
                # Check DRS job conflicts (even if not in DynamoDB)
                elif server_id in drs_servers_by_region.get(region, {}):
                    drs_info = drs_servers_by_region[region][server_id]
                    print(f"[Conflict Check] Server {server_id} has DRS job conflict: {drs_info['jobId']}")
                    conflicts.append({
                        'serverId': server_id,
                        'waveName': wave_name,
                        'conflictingJobId': drs_info['jobId'],
                        'conflictingJobStatus': drs_info['jobStatus'],
                        'conflictingLaunchStatus': drs_info.get('launchStatus'),
                        'conflictSource': 'drs_job'
                    })
    
    print(f"[Conflict Check] Total conflicts found: {len(conflicts)}")
    return conflicts


def get_plans_with_conflicts() -> Dict[str, Dict]:
    """
    Get all recovery plans that have server conflicts with active executions OR active DRS jobs.
    Returns dict mapping plan_id -> conflict info for plans that cannot be executed.
    
    This is used by the frontend to gray out Drill/Recovery buttons.
    For tag-based Protection Groups, resolves servers at check time.
    Also checks DRS directly for active LAUNCH jobs.
    """
    servers_in_use = get_servers_in_active_executions()
    
    # Also get servers in active DRS jobs (per region, cached)
    drs_servers_by_region = {}
    
    if not servers_in_use and not drs_servers_by_region:
        # Will populate drs_servers_by_region lazily per region below
        pass
    
    # Get all recovery plans
    try:
        result = recovery_plans_table.scan()
        all_plans = result.get('Items', [])
        
        # Handle pagination
        while 'LastEvaluatedKey' in result:
            result = recovery_plans_table.scan(
                ExclusiveStartKey=result['LastEvaluatedKey']
            )
            all_plans.extend(result.get('Items', []))
    except Exception as e:
        print(f"Error fetching plans for conflict check: {e}")
        return {}
    
    plans_with_conflicts = {}
    pg_cache = {}
    
    for plan in all_plans:
        plan_id = plan.get('PlanId')
        
        # Check if this plan has any servers in active executions
        conflicting_servers = []
        conflicting_execution_id = None
        conflicting_plan_id = None
        conflicting_status = None
        
        for wave in plan.get('Waves', []):
            # Get Protection Group ID for this wave
            pg_id = wave.get('ProtectionGroupId') or (wave.get('ProtectionGroupIds', []) or [None])[0]
            
            if pg_id:
                # Resolve servers from Protection Group tags
                server_ids = resolve_pg_servers_for_conflict_check(pg_id, pg_cache)
                
                for server_id in server_ids:
                    if server_id in servers_in_use:
                        conflict_info = servers_in_use[server_id]
                        # Don't count as conflict if it's this plan's own execution
                        if conflict_info['planId'] != plan_id:
                            conflicting_servers.append(server_id)
                            conflicting_execution_id = conflict_info['executionId']
                            conflicting_plan_id = conflict_info['planId']
                            conflicting_status = conflict_info.get('executionStatus')
        
        # Also check DRS jobs for this plan's regions
        drs_conflicting_servers = []
        drs_conflicting_job_id = None
        pg_metadata_cache = {}  # Separate cache for PG metadata (region, etc.)
        
        for wave in plan.get('Waves', []):
            pg_id = wave.get('ProtectionGroupId') or (wave.get('ProtectionGroupIds', []) or [None])[0]
            if pg_id:
                # Get PG metadata (region) - use separate cache since pg_cache stores server IDs
                if pg_id not in pg_metadata_cache:
                    try:
                        pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
                        pg_metadata_cache[pg_id] = pg_result.get('Item', {})
                    except Exception:
                        pg_metadata_cache[pg_id] = {}
                
                pg_metadata = pg_metadata_cache.get(pg_id, {})
                region = pg_metadata.get('Region', 'us-east-1')
                
                # Lazy load DRS jobs per region
                if region not in drs_servers_by_region:
                    drs_servers_by_region[region] = get_servers_in_active_drs_jobs(region)
                
                server_ids = resolve_pg_servers_for_conflict_check(pg_id, pg_cache)
                for server_id in server_ids:
                    # Skip if already in execution conflict
                    if server_id not in conflicting_servers and server_id in drs_servers_by_region.get(region, {}):
                        drs_info = drs_servers_by_region[region][server_id]
                        drs_conflicting_servers.append(server_id)
                        drs_conflicting_job_id = drs_info['jobId']
        
        all_conflicting = list(set(conflicting_servers + drs_conflicting_servers))
        
        if all_conflicting:
            # Build reason message
            if conflicting_servers and drs_conflicting_servers:
                reason = f'{len(set(conflicting_servers))} server(s) in execution, {len(set(drs_conflicting_servers))} in DRS jobs'
            elif drs_conflicting_servers:
                reason = f'{len(set(drs_conflicting_servers))} server(s) being processed by DRS job {drs_conflicting_job_id}'
            else:
                reason = f'{len(set(conflicting_servers))} server(s) in use by another execution'
            
            plans_with_conflicts[plan_id] = {
                'hasConflict': True,
                'conflictingServers': all_conflicting,
                'conflictingExecutionId': conflicting_execution_id,
                'conflictingPlanId': conflicting_plan_id,
                'conflictingStatus': conflicting_status,
                'conflictingDrsJobId': drs_conflicting_job_id,
                'reason': reason
            }
    
    return plans_with_conflicts


# ============================================================================
# DRS Service Limits Validation Functions
# ============================================================================

def validate_wave_sizes(plan: Dict) -> List[Dict]:
    """
    Validate that no wave exceeds the DRS limit of 100 servers per job.
    Returns list of validation errors.
    
    For tag-based Protection Groups, resolves servers at validation time.
    """
    errors = []
    pg_cache = {}
    
    for idx, wave in enumerate(plan.get('Waves', []), start=1):
        # Get Protection Group ID for this wave
        pg_id = wave.get('ProtectionGroupId') or (wave.get('ProtectionGroupIds', []) or [None])[0]
        
        if pg_id:
            # Resolve servers from Protection Group tags
            server_ids = resolve_pg_servers_for_conflict_check(pg_id, pg_cache)
            server_count = len(server_ids)
        else:
            server_count = 0
        
        if server_count > DRS_LIMITS['MAX_SERVERS_PER_JOB']:
            errors.append({
                'type': 'WAVE_SIZE_EXCEEDED',
                'wave': wave.get('WaveName', f'Wave {idx}'),
                'waveIndex': idx,
                'serverCount': server_count,
                'limit': DRS_LIMITS['MAX_SERVERS_PER_JOB'],
                'message': f"Wave '{wave.get('WaveName', f'Wave {idx}')}' has {server_count} servers, exceeds limit of {DRS_LIMITS['MAX_SERVERS_PER_JOB']}"
            })
    
    return errors


def validate_concurrent_jobs(region: str) -> Dict:
    """
    Check current DRS job count against the 20 concurrent jobs limit.
    Returns validation result with current count and availability.
    """
    try:
        regional_drs = boto3.client('drs', region_name=region)
        
        # Get active jobs (PENDING or STARTED status)
        active_jobs = []
        paginator = regional_drs.get_paginator('describe_jobs')
        
        for page in paginator.paginate():
            for job in page.get('items', []):
                if job.get('status') in ['PENDING', 'STARTED']:
                    active_jobs.append({
                        'jobId': job.get('jobID'),
                        'status': job.get('status'),
                        'type': job.get('type'),
                        'serverCount': len(job.get('participatingServers', []))
                    })
        
        current_count = len(active_jobs)
        available_slots = DRS_LIMITS['MAX_CONCURRENT_JOBS'] - current_count
        
        return {
            'valid': current_count < DRS_LIMITS['MAX_CONCURRENT_JOBS'],
            'currentJobs': current_count,
            'maxJobs': DRS_LIMITS['MAX_CONCURRENT_JOBS'],
            'availableSlots': available_slots,
            'activeJobs': active_jobs,
            'message': f"DRS has {current_count}/{DRS_LIMITS['MAX_CONCURRENT_JOBS']} active jobs" if current_count < DRS_LIMITS['MAX_CONCURRENT_JOBS'] else f"DRS concurrent job limit reached ({current_count}/{DRS_LIMITS['MAX_CONCURRENT_JOBS']})"
        }
        
    except Exception as e:
        error_str = str(e)
        print(f"Error checking concurrent jobs: {e}")
        
        # Check for uninitialized region errors
        if any(x in error_str for x in ['UninitializedAccountException', 'UnrecognizedClientException', 'security token']):
            return {
                'valid': True,
                'currentJobs': 0,
                'maxJobs': DRS_LIMITS['MAX_CONCURRENT_JOBS'],
                'availableSlots': DRS_LIMITS['MAX_CONCURRENT_JOBS'],
                'notInitialized': True
            }
        
        return {
            'valid': True,
            'warning': f'Could not verify concurrent jobs: {error_str}',
            'currentJobs': None,
            'maxJobs': DRS_LIMITS['MAX_CONCURRENT_JOBS']
        }


def validate_servers_in_all_jobs(region: str, new_server_count: int) -> Dict:
    """
    Check if adding new servers would exceed the 500 servers in all jobs limit.
    Returns validation result.
    """
    try:
        regional_drs = boto3.client('drs', region_name=region)
        
        # Count servers in active jobs
        servers_in_jobs = 0
        paginator = regional_drs.get_paginator('describe_jobs')
        
        for page in paginator.paginate():
            for job in page.get('items', []):
                if job.get('status') in ['PENDING', 'STARTED']:
                    servers_in_jobs += len(job.get('participatingServers', []))
        
        total_after_new = servers_in_jobs + new_server_count
        
        return {
            'valid': total_after_new <= DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS'],
            'currentServersInJobs': servers_in_jobs,
            'newServerCount': new_server_count,
            'totalAfterNew': total_after_new,
            'maxServers': DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS'],
            'message': f"Would have {total_after_new}/{DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS']} servers in active jobs" if total_after_new <= DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS'] else f"Would exceed max servers in all jobs ({total_after_new}/{DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS']})"
        }
        
    except Exception as e:
        error_str = str(e)
        print(f"Error checking servers in all jobs: {e}")
        
        # Check for uninitialized region errors
        if any(x in error_str for x in ['UninitializedAccountException', 'UnrecognizedClientException', 'security token']):
            return {
                'valid': True,
                'currentServersInJobs': 0,
                'maxServers': DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS'],
                'notInitialized': True
            }
        
        return {
            'valid': True,
            'warning': f'Could not verify servers in jobs: {error_str}',
            'currentServersInJobs': None,
            'maxServers': DRS_LIMITS['MAX_SERVERS_IN_ALL_JOBS']
        }


def validate_server_replication_states(region: str, server_ids: List[str]) -> Dict:
    """
    Validate that all servers have healthy replication state for recovery.
    Returns validation result with unhealthy servers list.
    """
    if not server_ids:
        return {'valid': True, 'healthyCount': 0, 'unhealthyCount': 0, 'unhealthyServers': []}
    
    try:
        regional_drs = boto3.client('drs', region_name=region)
        
        unhealthy_servers = []
        healthy_servers = []
        
        # Batch describe servers (max 200 per call)
        for i in range(0, len(server_ids), 200):
            batch = server_ids[i:i+200]
            
            response = regional_drs.describe_source_servers(
                filters={'sourceServerIDs': batch}
            )
            
            for server in response.get('items', []):
                server_id = server.get('sourceServerID')
                replication_state = server.get('dataReplicationInfo', {}).get('dataReplicationState', 'UNKNOWN')
                lifecycle_state = server.get('lifeCycle', {}).get('state', 'UNKNOWN')
                
                if replication_state in INVALID_REPLICATION_STATES or lifecycle_state == 'STOPPED':
                    unhealthy_servers.append({
                        'serverId': server_id,
                        'hostname': server.get('sourceProperties', {}).get('identificationHints', {}).get('hostname', 'Unknown'),
                        'replicationState': replication_state,
                        'lifecycleState': lifecycle_state,
                        'reason': f"Replication: {replication_state}, Lifecycle: {lifecycle_state}"
                    })
                else:
                    healthy_servers.append(server_id)
        
        return {
            'valid': len(unhealthy_servers) == 0,
            'healthyCount': len(healthy_servers),
            'unhealthyCount': len(unhealthy_servers),
            'unhealthyServers': unhealthy_servers,
            'message': f"All {len(healthy_servers)} servers have healthy replication" if len(unhealthy_servers) == 0 else f"{len(unhealthy_servers)} server(s) have unhealthy replication state"
        }
        
    except Exception as e:
        print(f"Error checking server replication states: {e}")
        return {
            'valid': True,
            'warning': f'Could not verify server replication states: {str(e)}',
            'unhealthyServers': []
        }


def get_drs_regional_capacity(region: str) -> Dict:
    """
    Get DRS capacity metrics for a specific region.
    Returns regional server counts for debugging/monitoring.
    """
    try:
        regional_drs = boto3.client('drs', region_name=region)
        
        # Count all source servers and replicating servers in this region
        total_servers = 0
        replicating_servers = 0
        
        paginator = regional_drs.get_paginator('describe_source_servers')
        
        for page in paginator.paginate():
            for server in page.get('items', []):
                total_servers += 1
                replication_state = server.get('dataReplicationInfo', {}).get('dataReplicationState', '')
                if replication_state in ['CONTINUOUS', 'INITIAL_SYNC', 'RESCAN', 'CREATING_SNAPSHOT']:
                    replicating_servers += 1
        
        return {
            'region': region,
            'totalSourceServers': total_servers,
            'replicatingServers': replicating_servers,
            'status': 'OK'
        }
        
    except Exception as e:
        error_str = str(e)
        print(f"Error getting regional capacity for {region}: {e}")
        
        # Check for common uninitialized/access errors
        if ('UninitializedAccountException' in error_str or 
            'not initialized' in error_str.lower() or
            'UnrecognizedClientException' in error_str):
            return {
                'region': region,
                'totalSourceServers': 0,
                'replicatingServers': 0,
                'status': 'NOT_INITIALIZED'
            }
        elif 'AccessDeniedException' in error_str or 'not authorized' in error_str.lower():
            return {
                'region': region,
                'totalSourceServers': None,
                'replicatingServers': None,
                'status': 'ACCESS_DENIED'
            }
        
        return {
            'region': region,
            'error': error_str,
            'status': 'ERROR'
        }


def get_drs_account_capacity(region: str) -> Dict:
    """
    Get current DRS account capacity metrics for a specific region.
    Returns capacity info including replicating server count vs 300 hard limit.
    Note: DRS limits are account-wide, but this shows regional usage for the selected region.
    """
    try:
        regional_drs = boto3.client('drs', region_name=region)
        
        # Count all source servers and replicating servers in this region
        total_servers = 0
        replicating_servers = 0
        
        paginator = regional_drs.get_paginator('describe_source_servers')
        
        for page in paginator.paginate():
            for server in page.get('items', []):
                total_servers += 1
                replication_state = server.get('dataReplicationInfo', {}).get('dataReplicationState', '')
                if replication_state in ['CONTINUOUS', 'INITIAL_SYNC', 'RESCAN', 'CREATING_SNAPSHOT']:
                    replicating_servers += 1
        
        # Determine capacity status
        if replicating_servers >= DRS_LIMITS['MAX_REPLICATING_SERVERS']:
            status = 'CRITICAL'
            message = f"Account at hard limit: {replicating_servers}/{DRS_LIMITS['MAX_REPLICATING_SERVERS']} replicating servers in {region}"
        elif replicating_servers >= DRS_LIMITS['CRITICAL_REPLICATING_THRESHOLD']:
            status = 'WARNING'
            message = f"Approaching hard limit: {replicating_servers}/{DRS_LIMITS['MAX_REPLICATING_SERVERS']} replicating servers in {region}"
        elif replicating_servers >= DRS_LIMITS['WARNING_REPLICATING_THRESHOLD']:
            status = 'INFO'
            message = f"Monitor capacity: {replicating_servers}/{DRS_LIMITS['MAX_REPLICATING_SERVERS']} replicating servers in {region}"
        else:
            status = 'OK'
            message = f"Capacity OK: {replicating_servers}/{DRS_LIMITS['MAX_REPLICATING_SERVERS']} replicating servers in {region}"
        
        return {
            'totalSourceServers': total_servers,
            'replicatingServers': replicating_servers,
            'maxReplicatingServers': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
            'maxSourceServers': DRS_LIMITS['MAX_SOURCE_SERVERS'],
            'availableReplicatingSlots': max(0, DRS_LIMITS['MAX_REPLICATING_SERVERS'] - replicating_servers),
            'status': status,
            'message': message
        }
        
    except regional_drs.exceptions.UninitializedAccountException:
        # DRS not initialized in this region
        return {
            'totalSourceServers': 0,
            'replicatingServers': 0,
            'maxReplicatingServers': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
            'maxSourceServers': DRS_LIMITS['MAX_SOURCE_SERVERS'],
            'availableReplicatingSlots': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
            'status': 'NOT_INITIALIZED',
            'message': f'DRS not initialized in {region}. Initialize DRS in the AWS Console to use this region.'
        }
        
    except Exception as e:
        error_str = str(e)
        print(f"Error getting account capacity: {e}")
        
        # Check for common uninitialized/access errors
        if 'UninitializedAccountException' in error_str or 'not initialized' in error_str.lower():
            return {
                'totalSourceServers': 0,
                'replicatingServers': 0,
                'maxReplicatingServers': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
                'maxSourceServers': DRS_LIMITS['MAX_SOURCE_SERVERS'],
                'availableReplicatingSlots': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
                'status': 'NOT_INITIALIZED',
                'message': f'DRS not initialized in {region}. Initialize DRS in the AWS Console to use this region.'
            }
        elif 'UnrecognizedClientException' in error_str or 'security token' in error_str.lower():
            return {
                'totalSourceServers': 0,
                'replicatingServers': 0,
                'maxReplicatingServers': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
                'maxSourceServers': DRS_LIMITS['MAX_SOURCE_SERVERS'],
                'availableReplicatingSlots': DRS_LIMITS['MAX_REPLICATING_SERVERS'],
                'status': 'NOT_INITIALIZED',
                'message': f'DRS not initialized in {region}. Initialize DRS in the AWS Console to use this region.'
            }
        elif 'AccessDeniedException' in error_str or 'not authorized' in error_str.lower():
            return {
                'totalSourceServers': None,
                'replicatingServers': None,
                'status': 'ACCESS_DENIED',
                'message': f'Access denied to DRS in {region}. Check IAM permissions.'
            }
        
        return {
            'error': error_str,
            'status': 'UNKNOWN',
            'message': f'Could not determine account capacity: {str(e)}'
        }


def lambda_handler(event: Dict, context: Any) -> Dict:
    """Main Lambda handler - routes requests to appropriate functions"""
    print(f"Received event: {json.dumps(event)}")
    print("Lambda handler started")
    
    try:
        print("Entering try block")
        
        # Check if this is a worker invocation (async execution)
        if event.get('worker'):
            print("Worker mode detected - executing background task")
            execute_recovery_plan_worker(event)
            return {'statusCode': 200, 'body': 'Worker completed'}
        
        print("Not worker mode, processing API Gateway request")
        
        # Normal API Gateway request handling
        http_method = event.get('httpMethod', '')
        path = event.get('path', '')
        path_parameters = event.get('pathParameters') or {}
        query_parameters = event.get('queryStringParameters') or {}
        body = json.loads(event.get('body', '{}')) if event.get('body') else {}
        
        print(f"Extracted values - Method: {http_method}, Path: {path}")
        
        # Handle OPTIONS requests for CORS
        if http_method == 'OPTIONS':
            print("Handling OPTIONS request")
            return response(200, {'message': 'OK'})
        
        print(f"Checking authentication for path: {path}")
        
        # Skip authentication check for health endpoint
        if path != '/health':
            # Validate authentication - check for Cognito authorizer context
            auth_context = event.get('requestContext', {}).get('authorizer', {})
            claims = auth_context.get('claims', {})
            print(f"Auth validation - path: {path}, auth_context: {auth_context}, claims: {claims}")
            
            # If no claims or essential fields missing, return 401 with CORS headers
            if not claims or not claims.get('email') or not claims.get('sub'):
                print("Authentication validation failed - missing or invalid Cognito claims")
                return response(401, {
                    'error': 'Unauthorized', 
                    'message': 'Valid authentication required'
                })
        
        print("Authentication passed, proceeding to routing")
        
        # Route to appropriate handler
        print(f"Routing request - Method: {http_method}, Path: '{path}'")
        
        if path == '/health':
            print("Matched /health route")
            return response(200, {'status': 'healthy', 'service': 'drs-orchestration-api'})
        elif path.startswith('/protection-groups'):
            print("Matched /protection-groups route")
            return handle_protection_groups(http_method, path_parameters, body, query_parameters)
        elif '/execute' in path and path.startswith('/recovery-plans'):
            print("Matched /recovery-plans execute route")
            # Handle /recovery-plans/{planId}/execute endpoint
            plan_id = path_parameters.get('id')
            body['PlanId'] = plan_id
            if 'InitiatedBy' not in body:
                body['InitiatedBy'] = 'system'
            return execute_recovery_plan(body)
        elif '/check-existing-instances' in path and path.startswith('/recovery-plans'):
            print("Matched /recovery-plans check-existing-instances route")
            # Handle /recovery-plans/{planId}/check-existing-instances endpoint
            plan_id = path_parameters.get('id')
            return check_existing_recovery_instances(plan_id)
        elif path.startswith('/recovery-plans'):
            print("Matched /recovery-plans route")
            return handle_recovery_plans(http_method, path_parameters, query_parameters, body)
        elif path.startswith('/executions'):
            print("Matched /executions route")
            # Pass full path for action routing (cancel, pause, resume)
            path_parameters['_full_path'] = path
            return handle_executions(http_method, path_parameters, query_parameters, body)
        elif path.startswith('/drs/source-servers'):
            print("Matched /drs/source-servers route")
            return handle_drs_source_servers(query_parameters)
        elif path.startswith('/drs/quotas'):
            print("Matched /drs/quotas route")
            return handle_drs_quotas(query_parameters)
        elif path.startswith('/drs/accounts'):
            print(f"Matched /drs/accounts route, calling handle_drs_accounts")
            return handle_drs_accounts(query_parameters)
        elif path.startswith('/accounts/targets'):
            return handle_target_accounts(path, http_method, body, query_parameters)
        elif path == '/drs/tag-sync' and http_method == 'POST':
            print("Matched /drs/tag-sync route")
            return handle_drs_tag_sync(body)
        elif path.startswith('/ec2/'):
            print("Matched /ec2/ route")
            return handle_ec2_resources(path, query_parameters)
        elif path.startswith('/config'):
            print("Matched /config route")
            return handle_config(http_method, path, body, query_parameters)
        else:
            print(f"No route matched for path: '{path}' - checking all conditions:")
            print(f"  path == '/health': {path == '/health'}")
            print(f"  path.startswith('/protection-groups'): {path.startswith('/protection-groups')}")
            print(f"  path.startswith('/recovery-plans'): {path.startswith('/recovery-plans')}")
            print(f"  path.startswith('/executions'): {path.startswith('/executions')}")
            print(f"  path.startswith('/drs/source-servers'): {path.startswith('/drs/source-servers')}")
            print(f"  path.startswith('/drs/quotas'): {path.startswith('/drs/quotas')}")
            print(f"  path.startswith('/drs/accounts'): {path.startswith('/drs/accounts')}")
            print(f"  path.startswith('/accounts/targets'): {path.startswith('/accounts/targets')}")
            print(f"  path.startswith('/ec2/'): {path.startswith('/ec2/')}")
            print(f"  path.startswith('/config'): {path.startswith('/config')}")
            return response(404, {'error': 'Not Found', 'path': path})
            
    except Exception as e:
        print(f"Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': 'Internal Server Error', 'message': str(e)})


# ============================================================================
# Protection Groups Handlers
# ============================================================================

def handle_protection_groups(method: str, path_params: Dict, body: Dict, query_params: Dict = None) -> Dict:
    """Route Protection Groups requests"""
    group_id = path_params.get('id')
    query_params = query_params or {}
    
    # Handle /protection-groups/resolve endpoint (POST with tags to preview servers)
    if method == 'POST' and group_id == 'resolve':
        return resolve_protection_group_tags(body)
    
    if method == 'POST':
        return create_protection_group(body)
    elif method == 'GET' and not group_id:
        return get_protection_groups(query_params)
    elif method == 'GET' and group_id:
        return get_protection_group(group_id)
    elif method == 'PUT' and group_id:
        return update_protection_group(group_id, body)
    elif method == 'DELETE' and group_id:
        return delete_protection_group(group_id)
    else:
        return response(405, {'error': 'Method Not Allowed'})


def resolve_protection_group_tags(body: Dict) -> Dict:
    """
    Resolve tag-based server selection to actual DRS source servers.
    Used for previewing which servers match the specified tags.
    
    Request body:
    {
        "region": "us-east-1",
        "ServerSelectionTags": {"DR-Application": "HRP", "DR-Tier": "Database"}
    }
    
    Returns list of servers matching ALL specified tags.
    """
    try:
        region = body.get('region')
        tags = body.get('ServerSelectionTags') or body.get('tags', {})
        
        if not region:
            return response(400, {'error': 'region is required'})
        
        if not tags or not isinstance(tags, dict):
            return response(400, {'error': 'ServerSelectionTags must be a non-empty object'})
        
        # Extract account context from request body
        account_context = None
        if body.get('AccountId'):
            account_context = {
                'AccountId': body.get('AccountId'),
                'AssumeRoleName': body.get('AssumeRoleName')
            }
        
        # Query DRS for servers matching tags
        resolved_servers = query_drs_servers_by_tags(region, tags, account_context)
        
        return response(200, {
            'region': region,
            'ServerSelectionTags': tags,
            'resolvedServers': resolved_servers,
            'serverCount': len(resolved_servers),
            'resolvedAt': int(time.time())
        })
        
    except Exception as e:
        print(f"Error resolving protection group tags: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def query_drs_servers_by_tags(region: str, tags: Dict[str, str], account_context: Optional[Dict] = None) -> List[Dict]:
    """
    Query DRS source servers that have ALL specified tags.
    Uses AND logic - DRS source server must have all tags to be included.
    
    This queries the DRS source server tags directly, not EC2 instance tags.
    Returns full server details matching the dynamic server discovery format.
    
    Args:
        region: AWS region to query
        tags: Dictionary of tag key-value pairs to match
        account_context: Optional dict with AccountId and AssumeRoleName for cross-account access
    """
    try:
        regional_drs = create_drs_client(region, account_context)
        
        # Get all source servers in the region
        all_servers = []
        paginator = regional_drs.get_paginator('describe_source_servers')
        
        for page in paginator.paginate():
            all_servers.extend(page.get('items', []))
        
        if not all_servers:
            return []
        
        # Filter servers that match ALL specified tags
        matching_servers = []
        
        for server in all_servers:
            source_props = server.get('sourceProperties', {})
            ident_hints = source_props.get('identificationHints', {})
            instance_id = ident_hints.get('awsInstanceID', '')
            hostname = ident_hints.get('hostname', 'Unknown')
            
            # Extract source IP
            network_interfaces = source_props.get('networkInterfaces', [])
            source_ip = ''
            if network_interfaces:
                ips = network_interfaces[0].get('ips', [])
                if ips:
                    source_ip = ips[0]
            
            # Extract source region/account from sourceCloudProperties
            source_cloud_props = server.get('sourceCloudProperties', {})
            source_region = source_cloud_props.get('originRegion', '')
            source_account = source_cloud_props.get('originAccountID', '')
            
            # Extract replication info
            data_rep_info = server.get('dataReplicationInfo', {})
            rep_state = data_rep_info.get('dataReplicationState', 'UNKNOWN')
            lag_duration = data_rep_info.get('lagDuration', 'UNKNOWN')
            
            # Map replication state to lifecycle state for display
            state_mapping = {
                'STOPPED': 'STOPPED',
                'INITIATING': 'INITIATING',
                'INITIAL_SYNC': 'SYNCING',
                'BACKLOG': 'SYNCING',
                'CREATING_SNAPSHOT': 'SYNCING',
                'CONTINUOUS': 'READY_FOR_RECOVERY',
                'PAUSED': 'PAUSED',
                'RESCAN': 'SYNCING',
                'STALLED': 'STALLED',
                'DISCONNECTED': 'DISCONNECTED'
            }
            display_state = state_mapping.get(rep_state, rep_state)
            
            # Get DRS source server tags directly from server object
            drs_tags = server.get('tags', {})
            
            # Check if DRS server has ALL required tags with matching values
            # Use case-insensitive matching and strip whitespace for robustness
            matches_all = True
            for tag_key, tag_value in tags.items():
                # Normalize tag key and value (strip whitespace, case-insensitive)
                normalized_required_key = tag_key.strip()
                normalized_required_value = tag_value.strip().lower()
                
                # Check if any DRS tag matches (case-insensitive)
                found_match = False
                for drs_key, drs_value in drs_tags.items():
                    normalized_drs_key = drs_key.strip()
                    normalized_drs_value = drs_value.strip().lower()
                    
                    if normalized_drs_key == normalized_required_key and normalized_drs_value == normalized_required_value:
                        found_match = True
                        break
                
                if not found_match:
                    matches_all = False
                    print(f"Server {server.get('sourceServerID')} missing tag {tag_key}={tag_value}. Available DRS tags: {list(drs_tags.keys())}")
                    break
            
            if matches_all:
                # Extract hardware info - CPU
                cpus = source_props.get('cpus', [])
                cpu_info = []
                total_cores = 0
                
                # Debug: Log the source properties structure for this server
                print(f"DEBUG: Server {server.get('sourceServerID')} source properties keys: {list(source_props.keys())}")
                print(f"DEBUG: CPUs data: {cpus}")
                print(f"DEBUG: RAM bytes: {source_props.get('ramBytes', 'NOT_FOUND')}")
                print(f"DEBUG: Disks data: {source_props.get('disks', 'NOT_FOUND')}")
                
                for cpu in cpus:
                    cpu_info.append({
                        'modelName': cpu.get('modelName', 'Unknown'),
                        'cores': cpu.get('cores', 0)
                    })
                    total_cores += cpu.get('cores', 0)
                
                # Extract hardware info - RAM
                ram_bytes = source_props.get('ramBytes', 0)
                ram_gib = round(ram_bytes / (1024 ** 3), 1) if ram_bytes else 0
                
                # Extract hardware info - Disks
                disks = source_props.get('disks', [])
                disk_info = []
                total_disk_bytes = 0
                for disk in disks:
                    disk_bytes = disk.get('bytes', 0)
                    total_disk_bytes += disk_bytes
                    disk_info.append({
                        'deviceName': disk.get('deviceName', 'Unknown'),
                        'bytes': disk_bytes,
                        'sizeGiB': round(disk_bytes / (1024 ** 3), 1) if disk_bytes else 0
                    })
                total_disk_gib = round(total_disk_bytes / (1024 ** 3), 1) if total_disk_bytes else 0
                
                # Extract OS info
                os_info = source_props.get('os', {})
                os_string = os_info.get('fullString', '')
                
                # Extract FQDN
                fqdn = ident_hints.get('fqdn', '')
                
                # Extract MAC address from first network interface
                source_mac = ''
                if network_interfaces:
                    source_mac = network_interfaces[0].get('macAddress', '')
                
                # Extract all network interfaces
                all_network_interfaces = []
                for nic in network_interfaces:
                    all_network_interfaces.append({
                        'ips': nic.get('ips', []),
                        'macAddress': nic.get('macAddress', ''),
                        'isPrimary': nic.get('isPrimary', False)
                    })
                
                # Extract lifecycle info
                lifecycle = server.get('lifeCycle', {})
                last_seen = lifecycle.get('lastSeenByServiceDateTime', '')
                
                # Return full server details matching dynamic UI format with hardware details
                matching_servers.append({
                    'sourceServerID': server.get('sourceServerID', ''),
                    'hostname': hostname,
                    'fqdn': fqdn,
                    'nameTag': drs_tags.get('Name', ''),
                    'sourceInstanceId': instance_id,
                    'sourceIp': source_ip,
                    'sourceMac': source_mac,
                    'sourceRegion': source_region,
                    'sourceAccount': source_account,
                    'os': os_string,
                    'state': display_state,
                    'replicationState': rep_state,
                    'lagDuration': lag_duration,
                    'lastSeen': last_seen,
                    # Hardware details matching ServerListItem expectations
                    'hardware': {
                        'cpus': cpu_info,
                        'totalCores': total_cores,
                        'ramBytes': ram_bytes,
                        'ramGiB': ram_gib,
                        'disks': disk_info,
                        'totalDiskGiB': total_disk_gib
                    },
                    'networkInterfaces': all_network_interfaces,
                    'drsTags': drs_tags,  # DRS resource tags for tag-based selection
                    'tags': drs_tags,  # All DRS source server tags (for compatibility)
                    'assignedToProtectionGroup': None,  # Will be populated if needed
                    'selectable': True  # Always selectable in tag preview
                })
        
        print(f"Tag matching results:")
        print(f"  - Total DRS servers: {len(all_servers)}")
        print(f"  - Servers matching tags {tags}: {len(matching_servers)}")
        
        # Debug: Show sample of available tags if no matches found
        if len(matching_servers) == 0 and all_servers:
            print("Sample of available DRS tags:")
            for i, server in enumerate(all_servers[:3]):
                sample_tags = server.get('tags', {})
                if sample_tags:
                    print(f"  Server {server.get('sourceServerID')}: {list(sample_tags.keys())}")
        
        return matching_servers
        
    except Exception as e:
        error_str = str(e)
        if 'UninitializedAccountException' in error_str:
            print(f"DRS not initialized in region {region}")
            return []
        print(f"Error querying DRS servers by tags: {error_str}")
        raise


def create_protection_group(body: Dict) -> Dict:
    """Create a new Protection Group - supports both tag-based and explicit server selection"""
    try:
        # Validate required fields
        if 'GroupName' not in body:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'GroupName is required',
                'field': 'GroupName'
            })
        
        if 'Region' not in body:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'Region is required',
                'field': 'Region'
            })
        
        name = body['GroupName']
        region = body['Region']
        
        # Validate name is not empty or whitespace-only
        if not name or not name.strip():
            return response(400, {
                'error': 'INVALID_NAME',
                'message': 'GroupName cannot be empty or whitespace-only',
                'field': 'GroupName'
            })
        
        # Validate name length (1-64 characters)
        if len(name.strip()) > 64:
            return response(400, {
                'error': 'INVALID_NAME',
                'message': 'GroupName must be 64 characters or fewer',
                'field': 'GroupName',
                'maxLength': 64,
                'actualLength': len(name.strip())
            })
        
        # Use trimmed name
        name = name.strip()
        
        # Support both selection modes
        selection_tags = body.get('ServerSelectionTags', {})
        source_server_ids = body.get('SourceServerIds', [])
        
        # Must have at least one selection method
        has_tags = isinstance(selection_tags, dict) and len(selection_tags) > 0
        has_servers = isinstance(source_server_ids, list) and len(source_server_ids) > 0
        
        if not has_tags and not has_servers:
            return response(400, {'error': 'Either ServerSelectionTags or SourceServerIds is required'})
        
        # Validate unique name (case-insensitive, global across all users)
        if not validate_unique_pg_name(name):
            return response(409, {
                'error': 'PG_NAME_EXISTS',
                'message': f'A Protection Group named "{name}" already exists',
                'existingName': name
            })
        
        # If using tags, check for tag conflicts with other PGs
        if has_tags:
            tag_conflicts = check_tag_conflicts_for_create(selection_tags, region)
            if tag_conflicts:
                return response(409, {
                    'error': 'TAG_CONFLICT',
                    'message': 'Another Protection Group already uses these exact tags',
                    'conflicts': tag_conflicts
                })
        
        # If using explicit server IDs, validate they exist and aren't assigned elsewhere
        if has_servers:
            # Validate servers exist in DRS
            regional_drs = boto3.client('drs', region_name=region)
            try:
                drs_response = regional_drs.describe_source_servers(
                    filters={'sourceServerIDs': source_server_ids}
                )
                found_ids = {s['sourceServerID'] for s in drs_response.get('items', [])}
                missing = set(source_server_ids) - found_ids
                if missing:
                    return response(400, {'error': f'Invalid server IDs: {list(missing)}'})
            except Exception as e:
                print(f"Error validating servers: {e}")
                # Continue anyway - servers might be valid
            
            # Check for server conflicts with other PGs
            conflicts = check_server_conflicts_for_create(source_server_ids)
            if conflicts:
                return response(409, {
                    'error': 'SERVER_CONFLICT',
                    'message': 'One or more servers are already assigned to another Protection Group',
                    'conflicts': conflicts
                })
        
        # Generate UUID for GroupId
        group_id = str(uuid.uuid4())
        timestamp = int(time.time())
        
        if timestamp <= 0:
            timestamp = int(time.time())
            if timestamp <= 0:
                raise Exception("Failed to generate valid timestamp")
        
        item = {
            'GroupId': group_id,
            'GroupName': name,
            'Description': body.get('Description', ''),
            'Region': region,
            'AccountId': body.get('AccountId', ''),
            'AssumeRoleName': body.get('AssumeRoleName', ''),
            'Owner': body.get('Owner', ''),
            'CreatedDate': timestamp,
            'LastModifiedDate': timestamp,
            'Version': 1  # Optimistic locking - starts at version 1
        }
        
        # Store the appropriate selection method (MUTUALLY EXCLUSIVE)
        # Tags take precedence if both are somehow provided
        if has_tags:
            item['ServerSelectionTags'] = selection_tags
            item['SourceServerIds'] = []  # Ensure empty
        elif has_servers:
            item['SourceServerIds'] = source_server_ids
            item['ServerSelectionTags'] = {}  # Ensure empty
        
        # Handle LaunchConfig if provided
        launch_config_apply_results = None
        if 'LaunchConfig' in body:
            launch_config = body['LaunchConfig']
            
            # Validate LaunchConfig structure
            if not isinstance(launch_config, dict):
                return response(400, {'error': 'LaunchConfig must be an object', 'code': 'INVALID_LAUNCH_CONFIG'})
            
            # Validate SecurityGroupIds is array if present
            if 'SecurityGroupIds' in launch_config:
                if not isinstance(launch_config['SecurityGroupIds'], list):
                    return response(400, {'error': 'SecurityGroupIds must be an array', 'code': 'INVALID_SECURITY_GROUPS'})
            
            # Get server IDs to apply settings to
            server_ids_to_apply = source_server_ids if has_servers else []
            
            # If using tags, resolve servers first
            if has_tags and not server_ids_to_apply:
                # Create account context for cross-account access
                account_context = None
                if body.get('AccountId'):
                    account_context = {
                        'AccountId': body.get('AccountId'),
                        'AssumeRoleName': body.get('AssumeRoleName')
                    }
                resolved = query_drs_servers_by_tags(region, selection_tags, account_context)
                server_ids_to_apply = [s.get('sourceServerID') for s in resolved if s.get('sourceServerID')]
            
            # Apply LaunchConfig to DRS/EC2 immediately
            if server_ids_to_apply and launch_config:
                launch_config_apply_results = apply_launch_config_to_servers(
                    server_ids_to_apply, launch_config, region,
                    protection_group_id=group_id, protection_group_name=name
                )
                
                # If any failed, return error (don't save partial state)
                if launch_config_apply_results.get('failed', 0) > 0:
                    failed_servers = [d for d in launch_config_apply_results.get('details', []) if d.get('status') == 'failed']
                    return response(400, {
                        'error': 'Failed to apply launch settings to some servers',
                        'code': 'LAUNCH_CONFIG_APPLY_FAILED',
                        'failedServers': failed_servers,
                        'applyResults': launch_config_apply_results
                    })
            
            # Store LaunchConfig in item
            item['LaunchConfig'] = launch_config
        
        print(f"Creating Protection Group: {group_id}")
        
        # Store in DynamoDB
        protection_groups_table.put_item(Item=item)
        
        # Transform to camelCase for frontend
        response_item = transform_pg_to_camelcase(item)
        
        # Include LaunchConfig apply results if applicable
        if launch_config_apply_results:
            response_item['launchConfigApplyResults'] = launch_config_apply_results
        
        return response(201, response_item)
        
    except Exception as e:
        print(f"Error creating Protection Group: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def get_protection_groups(query_params: Dict = None) -> Dict:
    """List all Protection Groups with optional account filtering"""
    try:
        query_params = query_params or {}
        account_id = query_params.get('accountId')
        
        result = protection_groups_table.scan()
        groups = result.get('Items', [])
        
        # Handle pagination
        while 'LastEvaluatedKey' in result:
            result = protection_groups_table.scan(
                ExclusiveStartKey=result['LastEvaluatedKey']
            )
            groups.extend(result.get('Items', []))
        
        # Filter by account if specified
        if account_id:
            # For now, implement client-side filtering based on region or stored account info
            # In future, could add AccountId field to DynamoDB schema
            filtered_groups = []
            for group in groups:
                # Check if group has account info or matches current account
                group_account = group.get('AccountId')
                if group_account == account_id or not group_account:
                    # Include groups that match account or have no account specified (legacy)
                    filtered_groups.append(group)
            groups = filtered_groups
        
        # Transform to camelCase (no server enrichment - tags are resolved at execution time)
        camelcase_groups = [transform_pg_to_camelcase(group) for group in groups]
        
        return response(200, {'groups': camelcase_groups, 'count': len(camelcase_groups)})
        
    except Exception as e:
        print(f"Error listing Protection Groups: {str(e)}")
        return response(500, {'error': str(e)})


def get_protection_group(group_id: str) -> Dict:
    """Get a single Protection Group by ID"""
    try:
        result = protection_groups_table.get_item(Key={'GroupId': group_id})
        
        if 'Item' not in result:
            return response(404, {'error': 'Protection Group not found'})
        
        group = result['Item']
        
        # Transform to camelCase (no server enrichment - use /resolve endpoint for that)
        camelcase_group = transform_pg_to_camelcase(group)
        
        return response(200, camelcase_group)
        
    except Exception as e:
        print(f"Error getting Protection Group: {str(e)}")
        return response(500, {'error': str(e)})


def update_protection_group(group_id: str, body: Dict) -> Dict:
    """Update an existing Protection Group with validation and optimistic locking"""
    try:
        # Check if group exists
        result = protection_groups_table.get_item(Key={'GroupId': group_id})
        if 'Item' not in result:
            return response(404, {'error': 'Protection Group not found'})
        
        existing_group = result['Item']
        current_version = existing_group.get('Version', 1)  # Default to 1 for legacy items
        
        # Optimistic locking: Check if client provided expected version
        client_version = body.get('version') or body.get('Version')
        if client_version is not None:
            # Convert to int for comparison (handles Decimal from DynamoDB)
            client_version = int(client_version)
            if client_version != int(current_version):
                return response(409, {
                    'error': 'VERSION_CONFLICT',
                    'message': 'Resource was modified by another user. Please refresh and try again.',
                    'expectedVersion': client_version,
                    'currentVersion': int(current_version),
                    'resourceId': group_id
                })
        
        # BLOCK: Cannot update protection group if it's part of a RUNNING execution
        # Note: PAUSED executions allow edits - only block when actively running
        active_exec_info = get_active_execution_for_protection_group(group_id)
        if active_exec_info:
            exec_status = active_exec_info.get('status', '').upper()
            # Only block if execution is actively running (not paused)
            running_statuses = ['PENDING', 'POLLING', 'INITIATED', 'LAUNCHING', 'STARTED', 
                               'IN_PROGRESS', 'RUNNING', 'CANCELLING']
            if exec_status in running_statuses:
                return response(409, {
                    'error': 'PG_IN_ACTIVE_EXECUTION',
                    'message': f'Cannot modify Protection Group while it is part of a running execution',
                    'activeExecution': active_exec_info
                })
        
        # Prevent region changes
        if 'Region' in body and body['Region'] != existing_group.get('Region'):
            return response(400, {'error': 'Cannot change region after creation'})
        
        # Validate name if provided
        if 'GroupName' in body:
            name = body['GroupName']
            
            # Validate name is not empty or whitespace-only
            if not name or not name.strip():
                return response(400, {
                    'error': 'INVALID_NAME',
                    'message': 'GroupName cannot be empty or whitespace-only',
                    'field': 'GroupName'
                })
            
            # Validate name length (1-64 characters)
            if len(name.strip()) > 64:
                return response(400, {
                    'error': 'INVALID_NAME',
                    'message': 'GroupName must be 64 characters or fewer',
                    'field': 'GroupName',
                    'maxLength': 64,
                    'actualLength': len(name.strip())
                })
            
            # Trim the name
            body['GroupName'] = name.strip()
            
            # Validate unique name if changing
            if body['GroupName'] != existing_group.get('GroupName'):
                if not validate_unique_pg_name(body['GroupName'], group_id):
                    return response(409, {
                        'error': 'PG_NAME_EXISTS',
                        'message': f'A Protection Group named "{body["GroupName"]}" already exists',
                        'existingName': body['GroupName']
                    })
        
        # Validate tags if provided
        if 'ServerSelectionTags' in body:
            selection_tags = body['ServerSelectionTags']
            if not isinstance(selection_tags, dict) or len(selection_tags) == 0:
                return response(400, {
                    'error': 'INVALID_TAGS',
                    'message': 'ServerSelectionTags must be a non-empty object with tag key-value pairs'
                })
            
            # Check for tag conflicts with other PGs (excluding this one)
            region = existing_group.get('Region', '')
            tag_conflicts = check_tag_conflicts_for_update(selection_tags, region, group_id)
            if tag_conflicts:
                return response(409, {
                    'error': 'TAG_CONFLICT',
                    'message': 'Another Protection Group already uses these exact tags',
                    'conflicts': tag_conflicts
                })
        
        # Validate server IDs if provided
        if 'SourceServerIds' in body:
            source_server_ids = body['SourceServerIds']
            if not isinstance(source_server_ids, list) or len(source_server_ids) == 0:
                return response(400, {
                    'error': 'INVALID_SERVERS',
                    'message': 'SourceServerIds must be a non-empty array'
                })
            
            # Check for conflicts with other PGs (excluding this one)
            conflicts = check_server_conflicts_for_update(source_server_ids, group_id)
            if conflicts:
                return response(409, {
                    'error': 'SERVER_CONFLICT',
                    'message': 'One or more servers are already assigned to another Protection Group',
                    'conflicts': conflicts
                })
        
        # Build update expression with version increment (optimistic locking)
        new_version = int(current_version) + 1
        update_expression = "SET LastModifiedDate = :timestamp, Version = :new_version"
        expression_values = {
            ':timestamp': int(time.time()),
            ':new_version': new_version,
            ':current_version': int(current_version)
        }
        expression_names = {}
        
        if 'GroupName' in body:
            update_expression += ", GroupName = :name"
            expression_values[':name'] = body['GroupName']
        
        if 'Description' in body:
            update_expression += ", #desc = :desc"
            expression_values[':desc'] = body['Description']
            expression_names['#desc'] = 'Description'
        
        # MUTUALLY EXCLUSIVE: Tags OR Servers, not both
        # When one is set, clear the other
        if 'ServerSelectionTags' in body:
            update_expression += ", ServerSelectionTags = :tags"
            expression_values[':tags'] = body['ServerSelectionTags']
            # Clear SourceServerIds when using tags
            update_expression += ", SourceServerIds = :empty_servers"
            expression_values[':empty_servers'] = []
        
        if 'SourceServerIds' in body:
            update_expression += ", SourceServerIds = :servers"
            expression_values[':servers'] = body['SourceServerIds']
            # Clear ServerSelectionTags when using explicit servers
            update_expression += ", ServerSelectionTags = :empty_tags"
            expression_values[':empty_tags'] = {}
        
        # Handle LaunchConfig - EC2 launch settings for recovery instances
        launch_config_apply_results = None
        if 'LaunchConfig' in body:
            launch_config = body['LaunchConfig']
            
            # Validate LaunchConfig structure
            if not isinstance(launch_config, dict):
                return response(400, {'error': 'LaunchConfig must be an object', 'code': 'INVALID_LAUNCH_CONFIG'})
            
            # Validate SecurityGroupIds is array if present
            if 'SecurityGroupIds' in launch_config:
                if not isinstance(launch_config['SecurityGroupIds'], list):
                    return response(400, {'error': 'SecurityGroupIds must be an array', 'code': 'INVALID_SECURITY_GROUPS'})
            
            # Get server IDs to apply settings to
            region = existing_group.get('Region')
            server_ids = body.get('SourceServerIds', existing_group.get('SourceServerIds', []))
            
            # If using tags, resolve servers first
            if not server_ids and existing_group.get('ServerSelectionTags'):
                # Extract account context from existing group
                account_context = None
                if existing_group.get('AccountId'):
                    account_context = {
                        'AccountId': existing_group.get('AccountId'),
                        'AssumeRoleName': existing_group.get('AssumeRoleName')
                    }
                resolved = query_drs_servers_by_tags(region, existing_group['ServerSelectionTags'], account_context)
                server_ids = [s.get('sourceServerID') for s in resolved if s.get('sourceServerID')]
            
            # Apply LaunchConfig to DRS/EC2 immediately
            if server_ids and launch_config:
                # Get group name (use updated name if provided, else existing)
                pg_name = body.get('GroupName', existing_group.get('GroupName', ''))
                launch_config_apply_results = apply_launch_config_to_servers(
                    server_ids, launch_config, region,
                    protection_group_id=group_id, protection_group_name=pg_name
                )
                
                # If any failed, return error (don't save partial state)
                if launch_config_apply_results.get('failed', 0) > 0:
                    failed_servers = [d for d in launch_config_apply_results.get('details', []) if d.get('status') == 'failed']
                    return response(400, {
                        'error': 'Failed to apply launch settings to some servers',
                        'code': 'LAUNCH_CONFIG_APPLY_FAILED',
                        'failedServers': failed_servers,
                        'applyResults': launch_config_apply_results
                    })
            
            # Store LaunchConfig in DynamoDB
            update_expression += ", LaunchConfig = :launchConfig"
            expression_values[':launchConfig'] = launch_config
        
        # Update item with conditional write (optimistic locking)
        # Only succeeds if version hasn't changed since we read it
        update_args = {
            'Key': {'GroupId': group_id},
            'UpdateExpression': update_expression,
            'ConditionExpression': 'Version = :current_version OR attribute_not_exists(Version)',
            'ExpressionAttributeValues': expression_values,
            'ReturnValues': 'ALL_NEW'
        }
        
        if expression_names:
            update_args['ExpressionAttributeNames'] = expression_names
        
        try:
            result = protection_groups_table.update_item(**update_args)
        except dynamodb.meta.client.exceptions.ConditionalCheckFailedException:
            # Another process updated the item between our read and write
            return response(409, {
                'error': 'VERSION_CONFLICT',
                'message': 'Resource was modified by another user. Please refresh and try again.',
                'resourceId': group_id
            })
        
        # Transform to camelCase for frontend
        response_item = transform_pg_to_camelcase(result['Attributes'])
        
        # Include LaunchConfig apply results if applicable
        if launch_config_apply_results:
            response_item['launchConfigApplyResults'] = launch_config_apply_results
        
        print(f"Updated Protection Group: {group_id}")
        return response(200, response_item)
        
    except Exception as e:
        print(f"Error updating Protection Group: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def delete_protection_group(group_id: str) -> Dict:
    """Delete a Protection Group - blocked if used in ANY recovery plan"""
    try:
        # Check if group is referenced in ANY Recovery Plans (not just active ones)
        # Scan all plans and check if any wave references this PG
        plans_result = recovery_plans_table.scan()
        all_plans = plans_result.get('Items', [])
        
        # Handle pagination
        while 'LastEvaluatedKey' in plans_result:
            plans_result = recovery_plans_table.scan(
                ExclusiveStartKey=plans_result['LastEvaluatedKey']
            )
            all_plans.extend(plans_result.get('Items', []))
        
        # Find plans that reference this protection group
        referencing_plans = []
        for plan in all_plans:
            for wave in plan.get('Waves', []):
                if wave.get('ProtectionGroupId') == group_id:
                    referencing_plans.append({
                        'planId': plan.get('PlanId'),
                        'planName': plan.get('PlanName'),
                        'waveName': wave.get('WaveName')
                    })
                    break  # Only need to find one wave per plan
        
        if referencing_plans:
            plan_names = list(set([p['planName'] for p in referencing_plans]))
            return response(409, {
                'error': 'PG_IN_USE',
                'message': f'Cannot delete Protection Group - it is used in {len(plan_names)} Recovery Plan(s)',
                'plans': plan_names,
                'details': referencing_plans
            })
        
        # Delete the group
        protection_groups_table.delete_item(Key={'GroupId': group_id})
        
        print(f"Deleted Protection Group: {group_id}")
        return response(200, {'message': 'Protection Group deleted successfully'})
        
    except Exception as e:
        print(f"Error deleting Protection Group: {str(e)}")
        return response(500, {'error': str(e)})


# ============================================================================
# Recovery Plans Handlers
# ============================================================================

def handle_recovery_plans(method: str, path_params: Dict, query_params: Dict, body: Dict) -> Dict:
    """Route Recovery Plans requests"""
    plan_id = path_params.get('id')
    path = path_params.get('proxy', '')
    
    # Handle /recovery-plans/{planId}/execute endpoint
    if method == 'POST' and plan_id and 'execute' in path:
        # Transform body for execute_recovery_plan
        body['PlanId'] = plan_id
        # Get InitiatedBy from Cognito if not provided
        if 'InitiatedBy' not in body:
            body['InitiatedBy'] = 'system'  # Will be replaced by Cognito user
        return execute_recovery_plan(body)
    
    # Handle /recovery-plans/{planId}/check-existing-instances endpoint
    if method == 'GET' and plan_id and 'check-existing-instances' in path:
        return check_existing_recovery_instances(plan_id)

    if method == 'POST':
        return create_recovery_plan(body)
    elif method == 'GET' and not plan_id:
        return get_recovery_plans(query_params)
    elif method == 'GET' and plan_id:
        return get_recovery_plan(plan_id)
    elif method == 'PUT' and plan_id:
        return update_recovery_plan(plan_id, body)
    elif method == 'DELETE' and plan_id:
        return delete_recovery_plan(plan_id)
    else:
        return response(405, {'error': 'Method Not Allowed'})


def create_recovery_plan(body: Dict) -> Dict:
    """Create a new Recovery Plan"""
    try:
        # Validate required fields
        if 'PlanName' not in body:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'PlanName is required',
                'field': 'PlanName'
            })
        
        if 'Waves' not in body or not body['Waves']:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'At least one Wave is required',
                'field': 'Waves'
            })
        
        # Validate name is not empty or whitespace-only
        plan_name = body['PlanName']
        if not plan_name or not plan_name.strip():
            return response(400, {
                'error': 'INVALID_NAME',
                'message': 'PlanName cannot be empty or whitespace-only',
                'field': 'PlanName'
            })
        
        # Validate name length (1-64 characters)
        if len(plan_name.strip()) > 64:
            return response(400, {
                'error': 'INVALID_NAME',
                'message': 'PlanName must be 64 characters or fewer',
                'field': 'PlanName',
                'maxLength': 64,
                'actualLength': len(plan_name.strip())
            })
        
        # Use trimmed name
        plan_name = plan_name.strip()
        
        # Validate unique name (case-insensitive, global across all users)
        if not validate_unique_rp_name(plan_name):
            return response(409, {  # Conflict
                'error': 'RP_NAME_EXISTS',
                'message': f'A Recovery Plan named "{plan_name}" already exists',
                'existingName': plan_name
            })
        
        # Generate UUID for PlanId
        plan_id = str(uuid.uuid4())
        
        # Create Recovery Plan item
        timestamp = int(time.time())
        item = {
            'PlanId': plan_id,
            'PlanName': body['PlanName'],
            'Description': body.get('Description', ''),  # Optional
            'Waves': body.get('Waves', []),
            'CreatedDate': timestamp,
            'LastModifiedDate': timestamp,
            'Version': 1  # Optimistic locking - starts at version 1
        }
        
        # Validate waves if provided
        if item['Waves']:
            validation_error = validate_waves(item['Waves'])
            if validation_error:
                return response(400, {'error': validation_error})
        
        # Store in DynamoDB
        recovery_plans_table.put_item(Item=item)
        
        print(f"Created Recovery Plan: {plan_id}")
        return response(201, item)
        
    except Exception as e:
        print(f"Error creating Recovery Plan: {str(e)}")
        return response(500, {'error': str(e)})


def get_recovery_plans(query_params: Dict = None) -> Dict:
    """List all Recovery Plans with latest execution history and conflict info
    
    Query Parameters:
        accountId: Filter by target account ID
        name: Filter by plan name (case-insensitive partial match)
        nameExact: Filter by exact plan name (case-insensitive)
        tag: Filter by tag key=value (plans with protection groups having this tag)
        hasConflict: Filter by conflict status (true/false)
        status: Filter by last execution status
    """
    try:
        query_params = query_params or {}
        
        result = recovery_plans_table.scan()
        plans = result.get('Items', [])
        
        # Apply filters
        account_id = query_params.get('accountId')
        name_filter = query_params.get('name', '').lower()
        name_exact_filter = query_params.get('nameExact', '').lower()
        tag_filter = query_params.get('tag', '')  # Format: key=value
        has_conflict_filter = query_params.get('hasConflict')
        status_filter = query_params.get('status', '').lower()
        
        # Parse tag filter
        tag_key, tag_value = None, None
        if tag_filter and '=' in tag_filter:
            tag_key, tag_value = tag_filter.split('=', 1)
        
        # Build protection group tag lookup if tag filter is specified
        pg_tags_map = {}
        if tag_key:
            try:
                pg_result = protection_groups_table.scan()
                for pg in pg_result.get('Items', []):
                    pg_id = pg.get('GroupId')
                    pg_tags = pg.get('ServerSelectionTags', {})
                    pg_tags_map[pg_id] = pg_tags
            except Exception as e:
                print(f"Error loading PG tags for filter: {e}")
        
        # Get conflict info for all plans (for graying out Drill/Recovery buttons)
        plans_with_conflicts = get_plans_with_conflicts()

        # Enrich each plan with latest execution data and conflict info
        for plan in plans:
            plan_id = plan.get('PlanId')
            
            # Add conflict info if this plan has conflicts with other active executions
            if plan_id in plans_with_conflicts:
                conflict_info = plans_with_conflicts[plan_id]
                plan['HasServerConflict'] = True
                plan['ConflictInfo'] = conflict_info
            else:
                plan['HasServerConflict'] = False
                plan['ConflictInfo'] = None
            
            # Query ExecutionHistoryTable for latest execution
            try:
                execution_result = execution_history_table.query(
                    IndexName='PlanIdIndex',
                    KeyConditionExpression=Key('PlanId').eq(plan_id),
                    ScanIndexForward=False,  # Sort by StartTime DESC
                    Limit=1  # Get only the latest execution
                )
                
                if execution_result.get('Items'):
                    latest_execution = execution_result['Items'][0]
                    plan['LastExecutionStatus'] = latest_execution.get('Status')
                    plan['LastStartTime'] = latest_execution.get('StartTime')
                    plan['LastEndTime'] = latest_execution.get('EndTime')
                else:
                    # No executions found for this plan
                    plan['LastExecutionStatus'] = None
                    plan['LastStartTime'] = None
                    plan['LastEndTime'] = None
                    
            except Exception as e:
                print(f"Error querying execution history for plan {plan_id}: {str(e)}")
                # Set null values on error
                plan['LastExecutionStatus'] = None
                plan['LastStartTime'] = None
                plan['LastEndTime'] = None

            # Add wave count before transformation
            plan['WaveCount'] = len(plan.get('Waves', []))

        # Apply filters to plans
        filtered_plans = []
        for plan in plans:
            # Account filter - check if plan targets the specified account
            if account_id:
                # For now, implement client-side filtering based on stored account info
                # In future, could add AccountId field to DynamoDB schema
                plan_account = plan.get('AccountId')
                if plan_account and plan_account != account_id:
                    continue
                # If no account specified in plan, include it (legacy plans)
            
            # Name filter (partial match, case-insensitive)
            if name_filter:
                plan_name = plan.get('PlanName', '').lower()
                if name_filter not in plan_name:
                    continue
            
            # Exact name filter (case-insensitive)
            if name_exact_filter:
                plan_name = plan.get('PlanName', '').lower()
                if name_exact_filter != plan_name:
                    continue
            
            # Conflict filter
            if has_conflict_filter is not None:
                has_conflict = plan.get('HasServerConflict', False)
                if has_conflict_filter.lower() == 'true' and not has_conflict:
                    continue
                if has_conflict_filter.lower() == 'false' and has_conflict:
                    continue
            
            # Status filter (last execution status)
            if status_filter:
                last_status = (plan.get('LastExecutionStatus') or '').lower()
                if status_filter != last_status:
                    continue
            
            # Tag filter - check if any protection group in plan has matching tag
            if tag_key:
                plan_waves = plan.get('Waves', [])
                has_matching_tag = False
                for wave in plan_waves:
                    pg_id = wave.get('ProtectionGroupId')
                    if pg_id and pg_id in pg_tags_map:
                        pg_tags = pg_tags_map[pg_id]
                        if tag_key in pg_tags and pg_tags[tag_key] == tag_value:
                            has_matching_tag = True
                            break
                if not has_matching_tag:
                    continue
            
            filtered_plans.append(plan)

        # Transform to camelCase for frontend
        camelcase_plans = []
        for plan in filtered_plans:
            camelcase_plans.append(transform_rp_to_camelcase(plan))

        return response(200, {'plans': camelcase_plans, 'count': len(camelcase_plans)})

    except Exception as e:
        print(f"Error listing Recovery Plans: {str(e)}")
        return response(500, {'error': str(e)})


def get_recovery_plan(plan_id: str) -> Dict:
    """Get a single Recovery Plan by ID"""
    try:
        result = recovery_plans_table.get_item(Key={'PlanId': plan_id})

        if 'Item' not in result:
            return response(404, {'error': 'Recovery Plan not found'})

        plan = result['Item']
        plan['WaveCount'] = len(plan.get('Waves', []))
        
        # Transform to camelCase for frontend
        camelcase_plan = transform_rp_to_camelcase(plan)
        
        return response(200, camelcase_plan)

    except Exception as e:
        print(f"Error getting Recovery Plan: {str(e)}")
        return response(500, {'error': str(e)})


def update_recovery_plan(plan_id: str, body: Dict) -> Dict:
    """Update an existing Recovery Plan - blocked if execution in progress, with optimistic locking"""
    try:
        # Check if plan exists
        result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
        if 'Item' not in result:
            return response(404, {'error': 'Recovery Plan not found'})
        
        existing_plan = result['Item']
        current_version = existing_plan.get('Version', 1)  # Default to 1 for legacy items
        
        # Optimistic locking: Check if client provided expected version
        client_version = body.get('version') or body.get('Version')
        if client_version is not None:
            # Convert to int for comparison (handles Decimal from DynamoDB)
            client_version = int(client_version)
            if client_version != int(current_version):
                return response(409, {
                    'error': 'VERSION_CONFLICT',
                    'message': 'Resource was modified by another user. Please refresh and try again.',
                    'expectedVersion': client_version,
                    'currentVersion': int(current_version),
                    'resourceId': plan_id
                })
        
        # BLOCK: Cannot update plan with active execution
        active_executions = get_active_executions_for_plan(plan_id)
        if active_executions:
            exec_ids = [e.get('ExecutionId') for e in active_executions]
            return response(409, {
                'error': 'PLAN_HAS_ACTIVE_EXECUTION',
                'message': 'Cannot modify Recovery Plan while an execution is in progress',
                'activeExecutions': exec_ids,
                'planId': plan_id
            })
        
        # Validate name if provided
        if 'PlanName' in body:
            plan_name = body['PlanName']
            
            # Validate name is not empty or whitespace-only
            if not plan_name or not plan_name.strip():
                return response(400, {
                    'error': 'INVALID_NAME',
                    'message': 'PlanName cannot be empty or whitespace-only',
                    'field': 'PlanName'
                })
            
            # Validate name length (1-64 characters)
            if len(plan_name.strip()) > 64:
                return response(400, {
                    'error': 'INVALID_NAME',
                    'message': 'PlanName must be 64 characters or fewer',
                    'field': 'PlanName',
                    'maxLength': 64,
                    'actualLength': len(plan_name.strip())
                })
            
            # Trim the name
            body['PlanName'] = plan_name.strip()
            
            # Validate unique name if changing
            if body['PlanName'] != existing_plan.get('PlanName'):
                if not validate_unique_rp_name(body['PlanName'], plan_id):
                    return response(409, {
                        'error': 'RP_NAME_EXISTS',
                        'message': f'A Recovery Plan named "{body["PlanName"]}" already exists',
                        'existingName': body['PlanName']
                    })
        
        # NEW: Pre-write validation for Waves
        if 'Waves' in body:
            print(f"Updating plan {plan_id} with {len(body['Waves'])} waves")
            
            # DEFENSIVE: Validate ServerIds in each wave
            for idx, wave in enumerate(body['Waves']):
                server_ids = wave.get('ServerIds', [])
                if not isinstance(server_ids, list):
                    print(f"ERROR: Wave {idx} ServerIds is not a list: {type(server_ids)}")
                    return response(400, {
                        'error': 'INVALID_WAVE_DATA',
                        'message': f'Wave {idx} has invalid ServerIds format (must be array)',
                        'waveIndex': idx
                    })
                print(f"Wave {idx}: {wave.get('WaveName')} - {len(server_ids)} servers")
            
            validation_error = validate_waves(body['Waves'])
            if validation_error:
                return response(400, {'error': validation_error})
        
        # Build update expression with version increment (optimistic locking)
        new_version = int(current_version) + 1
        update_expression = "SET LastModifiedDate = :timestamp, Version = :new_version"
        expression_values = {
            ':timestamp': int(time.time()),
            ':new_version': new_version,
            ':current_version': int(current_version)
        }
        expression_names = {}
        
        updatable_fields = ['PlanName', 'Description', 'RPO', 'RTO', 'Waves']
        for field in updatable_fields:
            if field in body:
                if field == 'Description':
                    update_expression += ", #desc = :desc"
                    expression_values[':desc'] = body['Description']
                    expression_names['#desc'] = 'Description'
                else:
                    update_expression += f", {field} = :{field.lower()}"
                    expression_values[f':{field.lower()}'] = body[field]
        
        # Update item with conditional write (optimistic locking)
        update_args = {
            'Key': {'PlanId': plan_id},
            'UpdateExpression': update_expression,
            'ConditionExpression': 'Version = :current_version OR attribute_not_exists(Version)',
            'ExpressionAttributeValues': expression_values,
            'ReturnValues': 'ALL_NEW'
        }
        
        if expression_names:
            update_args['ExpressionAttributeNames'] = expression_names
        
        try:
            result = recovery_plans_table.update_item(**update_args)
        except dynamodb.meta.client.exceptions.ConditionalCheckFailedException:
            # Another process updated the item between our read and write
            return response(409, {
                'error': 'VERSION_CONFLICT',
                'message': 'Resource was modified by another user. Please refresh and try again.',
                'resourceId': plan_id
            })
        
        print(f"Updated Recovery Plan: {plan_id}")
        # Transform to camelCase for frontend consistency
        updated_plan = result['Attributes']
        updated_plan['WaveCount'] = len(updated_plan.get('Waves', []))
        return response(200, transform_rp_to_camelcase(updated_plan))
        
    except Exception as e:
        print(f"Error updating Recovery Plan: {str(e)}")
        return response(500, {'error': str(e)})


def delete_recovery_plan(plan_id: str) -> Dict:
    """Delete a Recovery Plan - blocked if any active execution exists"""
    try:
        # Check for ANY active execution (not just RUNNING)
        active_executions = get_active_executions_for_plan(plan_id)
        
        if active_executions:
            exec_ids = [e.get('ExecutionId') for e in active_executions]
            statuses = [e.get('Status') for e in active_executions]
            print(f"Cannot delete plan {plan_id}: {len(active_executions)} active execution(s)")
            return response(409, {
                'error': 'PLAN_HAS_ACTIVE_EXECUTION',
                'message': f'Cannot delete Recovery Plan while {len(active_executions)} execution(s) are in progress',
                'activeExecutions': exec_ids,
                'activeStatuses': statuses,
                'planId': plan_id
            })
        
        # No active executions, safe to delete
        print(f"Deleting Recovery Plan: {plan_id}")
        recovery_plans_table.delete_item(Key={'PlanId': plan_id})
        
        print(f"Successfully deleted Recovery Plan: {plan_id}")
        return response(200, {
            'message': 'Recovery Plan deleted successfully',
            'planId': plan_id
        })
        
    except Exception as e:
        print(f"Error deleting Recovery Plan {plan_id}: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {
            'error': 'DELETE_FAILED',
            'message': f'Failed to delete Recovery Plan: {str(e)}',
            'planId': plan_id
        })


def check_existing_recovery_instances(plan_id: str) -> Dict:
    """Check if servers in this plan have existing recovery instances from completed executions.
    
    Returns info about any recovery instances that haven't been terminated yet.
    Used by frontend to prompt user before starting a new drill.
    """
    try:
        # Get the recovery plan
        plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
        if 'Item' not in plan_result:
            return response(404, {
                'error': 'RECOVERY_PLAN_NOT_FOUND',
                'message': f'Recovery Plan with ID {plan_id} not found',
                'planId': plan_id
            })
        
        plan = plan_result['Item']
        
        # Collect all server IDs from all waves by resolving protection groups
        all_server_ids = set()
        region = 'us-east-1'
        
        for wave in plan.get('Waves', []):
            pg_id = wave.get('ProtectionGroupId')
            if not pg_id:
                continue
                
            pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
            pg = pg_result.get('Item', {})
            if not pg:
                continue
            
            # Get region from protection group
            pg_region = pg.get('Region', 'us-east-1')
            if pg_region:
                region = pg_region
            
            # Check for explicit server IDs first
            explicit_servers = pg.get('SourceServerIds', [])
            if explicit_servers:
                print(f"PG {pg_id} has explicit servers: {explicit_servers}")
                for server_id in explicit_servers:
                    all_server_ids.add(server_id)
            else:
                # Resolve servers from tags using EC2 instance tags (not DRS tags)
                selection_tags = pg.get('ServerSelectionTags', {})
                print(f"PG {pg_id} has selection tags: {selection_tags}")
                if selection_tags:
                    try:
                        # Extract account context from Protection Group
                        account_context = None
                        if pg.get('AccountId'):
                            account_context = {
                                'AccountId': pg.get('AccountId'),
                                'AssumeRoleName': pg.get('AssumeRoleName')
                            }
                        resolved = query_drs_servers_by_tags(pg_region, selection_tags, account_context)
                        print(f"Resolved {len(resolved)} servers from tags")
                        for server in resolved:
                            server_id = server.get('sourceServerID')
                            if server_id:
                                all_server_ids.add(server_id)
                                print(f"Added server {server_id} to check list")
                    except Exception as e:
                        print(f"Error resolving tags for PG {pg_id}: {e}")
        
        print(f"Total servers to check for recovery instances: {len(all_server_ids)}: {all_server_ids}")
        
        if not all_server_ids:
            return response(200, {
                'hasExistingInstances': False,
                'existingInstances': [],
                'planId': plan_id
            })
        
        # Query DRS for recovery instances
        drs_client = boto3.client('drs', region_name=region)
        
        existing_instances = []
        try:
            # Get all recovery instances in the region
            paginator = drs_client.get_paginator('describe_recovery_instances')
            ri_count = 0
            for page in paginator.paginate():
                for ri in page.get('items', []):
                    ri_count += 1
                    source_server_id = ri.get('sourceServerID')
                    ec2_state = ri.get('ec2InstanceState')
                    print(f"Recovery instance: source={source_server_id}, state={ec2_state}, in_list={source_server_id in all_server_ids}")
                    if source_server_id in all_server_ids:
                        ec2_instance_id = ri.get('ec2InstanceID')
                        recovery_instance_id = ri.get('recoveryInstanceID')
                        
                        # Find which execution created this instance
                        source_execution = None
                        source_plan_name = None
                        
                        # Search execution history for this recovery instance
                        # Structure: Waves[].ServerStatuses[] with SourceServerId, RecoveryInstanceID
                        try:
                            # Scan recent executions that have Waves data
                            exec_scan = execution_history_table.scan(
                                FilterExpression='attribute_exists(Waves)',
                                Limit=100  # Check last 100 executions
                            )
                            
                            # Sort by StartTime descending to find most recent match
                            exec_items = sorted(
                                exec_scan.get('Items', []),
                                key=lambda x: x.get('StartTime', 0),
                                reverse=True
                            )
                            
                            for exec_item in exec_items:
                                exec_waves = exec_item.get('Waves', [])
                                found = False
                                for wave in exec_waves:
                                    # Check ServerStatuses array (correct structure)
                                    for server in wave.get('ServerStatuses', []):
                                        # Match by source server ID (most reliable)
                                        if server.get('SourceServerId') == source_server_id:
                                            source_execution = exec_item.get('ExecutionId')
                                            # Get plan name
                                            exec_plan_id = exec_item.get('PlanId')
                                            if exec_plan_id:
                                                plan_lookup = recovery_plans_table.get_item(Key={'PlanId': exec_plan_id})
                                                source_plan_name = plan_lookup.get('Item', {}).get('PlanName', exec_plan_id)
                                            found = True
                                            break
                                    if found:
                                        break
                                if found:
                                    break
                        except Exception as e:
                            print(f"Error looking up execution for recovery instance: {e}")
                        
                        existing_instances.append({
                            'sourceServerId': source_server_id,
                            'recoveryInstanceId': recovery_instance_id,
                            'ec2InstanceId': ec2_instance_id,
                            'ec2InstanceState': ri.get('ec2InstanceState'),
                            'sourceExecutionId': source_execution,
                            'sourcePlanName': source_plan_name,
                            'region': region
                        })
        except Exception as e:
            print(f"Error querying DRS recovery instances: {e}")
            # Don't fail the whole request, just return empty
        
        # Enrich with EC2 instance details (Name tag, IP, launch time)
        if existing_instances:
            try:
                ec2_client = boto3.client('ec2', region_name=region)
                ec2_ids = [inst['ec2InstanceId'] for inst in existing_instances if inst.get('ec2InstanceId')]
                if ec2_ids:
                    ec2_response = ec2_client.describe_instances(InstanceIds=ec2_ids)
                    ec2_details = {}
                    for reservation in ec2_response.get('Reservations', []):
                        for instance in reservation.get('Instances', []):
                            inst_id = instance.get('InstanceId')
                            name_tag = next((t['Value'] for t in instance.get('Tags', []) if t['Key'] == 'Name'), None)
                            ec2_details[inst_id] = {
                                'name': name_tag,
                                'privateIp': instance.get('PrivateIpAddress'),
                                'publicIp': instance.get('PublicIpAddress'),
                                'instanceType': instance.get('InstanceType'),
                                'launchTime': instance.get('LaunchTime').isoformat() if instance.get('LaunchTime') else None
                            }
                    # Merge EC2 details into existing_instances
                    for inst in existing_instances:
                        ec2_id = inst.get('ec2InstanceId')
                        if ec2_id and ec2_id in ec2_details:
                            inst.update(ec2_details[ec2_id])
            except Exception as e:
                print(f"Error fetching EC2 details: {e}")
        
        return response(200, {
            'hasExistingInstances': len(existing_instances) > 0,
            'existingInstances': existing_instances,
            'instanceCount': len(existing_instances),
            'planId': plan_id
        })
        
    except Exception as e:
        print(f"Error checking existing recovery instances for plan {plan_id}: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {
            'error': 'CHECK_FAILED',
            'message': f'Failed to check existing recovery instances: {str(e)}',
            'planId': plan_id
        })


# ============================================================================
# Execution Handlers
# ============================================================================

def handle_executions(method: str, path_params: Dict, query_params: Dict, body: Dict) -> Dict:
    """Route Execution requests"""
    execution_id = path_params.get('executionId')
    # Use full path for action detection (cancel, pause, resume)
    full_path = path_params.get('_full_path', '')
    
    print(f"EXECUTIONS ROUTE - execution_id: {execution_id}, full_path: {full_path}, method: {method}")
    
    # Handle action-specific routes
    if execution_id and '/cancel' in full_path:
        return cancel_execution(execution_id)
    elif execution_id and '/pause' in full_path:
        return pause_execution(execution_id)
    elif execution_id and '/resume' in full_path:
        return resume_execution(execution_id)
    elif execution_id and '/terminate-instances' in full_path:
        return terminate_recovery_instances(execution_id)
    elif execution_id and '/termination-status' in full_path:
        job_ids = query_params.get('jobIds', '')
        region = query_params.get('region', 'us-west-2')
        return get_termination_job_status(execution_id, job_ids, region)
    elif execution_id and '/job-logs' in full_path:
        job_id = query_params.get('jobId')
        return get_job_log_items(execution_id, job_id)
    elif method == 'POST' and not execution_id:
        return execute_recovery_plan(body)
    elif method == 'GET' and execution_id:
        return get_execution_details(execution_id)
    elif method == 'GET':
        # List all executions with optional pagination
        return list_executions(query_params)
    elif method == 'DELETE' and not execution_id:
        # Delete completed executions only (bulk operation)
        return delete_completed_executions()
    else:
        return response(405, {'error': 'Method Not Allowed'})


def execute_recovery_plan(body: Dict, event: Dict = None) -> Dict:
    """Execute a Recovery Plan - Async pattern to avoid API Gateway timeout"""
    try:
        # Extract Cognito user if event provided
        cognito_user = get_cognito_user_from_event(event) if event else {'email': 'system', 'userId': 'system'}
        
        # Validate required fields with helpful messages
        if 'PlanId' not in body:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'PlanId is required - specify which Recovery Plan to execute',
                'field': 'PlanId'
            })
        
        if 'ExecutionType' not in body:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'ExecutionType is required - must be DRILL or RECOVERY',
                'field': 'ExecutionType',
                'allowedValues': ['DRILL', 'RECOVERY']
            })
        
        if 'InitiatedBy' not in body:
            return response(400, {
                'error': 'MISSING_FIELD',
                'message': 'InitiatedBy is required - identify who/what started this execution',
                'field': 'InitiatedBy'
            })
        
        plan_id = body['PlanId']
        execution_type = body['ExecutionType'].upper() if body['ExecutionType'] else ''
        
        # Validate execution type
        if execution_type not in ['DRILL', 'RECOVERY']:
            return response(400, {
                'error': 'INVALID_EXECUTION_TYPE',
                'message': f'ExecutionType must be DRILL or RECOVERY, got: {body["ExecutionType"]}',
                'field': 'ExecutionType',
                'providedValue': body['ExecutionType'],
                'allowedValues': ['DRILL', 'RECOVERY']
            })
        
        # Get Recovery Plan
        plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
        if 'Item' not in plan_result:
            return response(404, {
                'error': 'RECOVERY_PLAN_NOT_FOUND',
                'message': f'Recovery Plan with ID {plan_id} not found',
                'planId': plan_id
            })
        
        plan = plan_result['Item']
        
        # Validate plan has waves
        if not plan.get('Waves'):
            return response(400, {
                'error': 'PLAN_HAS_NO_WAVES',
                'message': f'Recovery Plan "{plan.get("PlanName", plan_id)}" has no waves configured - add at least one wave before executing',
                'planId': plan_id,
                'planName': plan.get('PlanName')
            })
        
        # BLOCK: Cannot execute plan that already has an active execution
        active_executions = get_active_executions_for_plan(plan_id)
        if active_executions:
            exec_ids = [e.get('ExecutionId') for e in active_executions]
            return response(409, {
                'error': 'PLAN_ALREADY_EXECUTING',
                'message': 'This Recovery Plan already has an execution in progress',
                'activeExecutions': exec_ids,
                'planId': plan_id
            })
        
        # BLOCK: Check for server conflicts with other running executions OR active DRS jobs
        # Parse account context from request
        account_context = body.get('AccountContext') or body.get('accountContext')
        server_conflicts = check_server_conflicts(plan, account_context)
        if server_conflicts:
            # Separate execution conflicts from DRS job conflicts
            execution_conflicts = [c for c in server_conflicts if c.get('conflictSource') == 'execution']
            drs_job_conflicts = [c for c in server_conflicts if c.get('conflictSource') == 'drs_job']
            
            # Group execution conflicts by execution
            conflict_executions = {}
            for conflict in execution_conflicts:
                exec_id = conflict.get('conflictingExecutionId')
                if exec_id and exec_id not in conflict_executions:
                    conflict_executions[exec_id] = {
                        'executionId': exec_id,
                        'planId': conflict.get('conflictingPlanId'),
                        'servers': []
                    }
                if exec_id:
                    conflict_executions[exec_id]['servers'].append(conflict['serverId'])
            
            # Group DRS job conflicts by job
            conflict_drs_jobs = {}
            for conflict in drs_job_conflicts:
                job_id = conflict.get('conflictingJobId')
                if job_id and job_id not in conflict_drs_jobs:
                    conflict_drs_jobs[job_id] = {
                        'jobId': job_id,
                        'jobStatus': conflict.get('conflictingJobStatus'),
                        'servers': []
                    }
                if job_id:
                    conflict_drs_jobs[job_id]['servers'].append(conflict['serverId'])
            
            # Build appropriate error message
            if drs_job_conflicts and not execution_conflicts:
                message = f'{len(drs_job_conflicts)} server(s) are being processed by active DRS jobs'
            elif execution_conflicts and not drs_job_conflicts:
                message = f'{len(execution_conflicts)} server(s) are already in active executions'
            else:
                message = f'{len(server_conflicts)} server(s) are in use (executions: {len(execution_conflicts)}, DRS jobs: {len(drs_job_conflicts)})'
            
            return response(409, {
                'error': 'SERVER_CONFLICT',
                'message': message,
                'conflicts': server_conflicts,
                'conflictingExecutions': list(conflict_executions.values()),
                'conflictingDrsJobs': list(conflict_drs_jobs.values())
            })
        
        # ============================================================
        # DRS SERVICE LIMITS VALIDATION
        # ============================================================
        
        # Get region from first wave's protection group
        first_wave = plan.get('Waves', [{}])[0]
        pg_id = first_wave.get('ProtectionGroupId')
        if pg_id:
            pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
            region = pg_result.get('Item', {}).get('Region', 'us-east-1')
        else:
            region = 'us-east-1'  # Default fallback
        
        # Collect all server IDs from all waves
        all_server_ids = []
        for wave in plan.get('Waves', []):
            all_server_ids.extend(wave.get('ServerIds', []))
        total_servers_in_plan = len(all_server_ids)
        
        # 1. Validate wave sizes (max 100 servers per wave)
        wave_size_errors = validate_wave_sizes(plan)
        if wave_size_errors:
            return response(400, {
                'error': 'WAVE_SIZE_LIMIT_EXCEEDED',
                'message': f'{len(wave_size_errors)} wave(s) exceed the DRS limit of {DRS_LIMITS["MAX_SERVERS_PER_JOB"]} servers per job',
                'errors': wave_size_errors,
                'limit': DRS_LIMITS['MAX_SERVERS_PER_JOB']
            })
        
        # 2. Validate concurrent jobs (max 20)
        concurrent_jobs_result = validate_concurrent_jobs(region)
        if not concurrent_jobs_result.get('valid'):
            return response(429, {  # Too Many Requests
                'error': 'CONCURRENT_JOBS_LIMIT_EXCEEDED',
                'message': concurrent_jobs_result.get('message'),
                'currentJobs': concurrent_jobs_result.get('currentJobs'),
                'maxJobs': concurrent_jobs_result.get('maxJobs'),
                'activeJobs': concurrent_jobs_result.get('activeJobs', [])
            })
        
        # 3. Validate servers in all jobs (max 500)
        servers_in_jobs_result = validate_servers_in_all_jobs(region, total_servers_in_plan)
        if not servers_in_jobs_result.get('valid'):
            return response(429, {
                'error': 'SERVERS_IN_JOBS_LIMIT_EXCEEDED',
                'message': servers_in_jobs_result.get('message'),
                'currentServersInJobs': servers_in_jobs_result.get('currentServersInJobs'),
                'newServerCount': servers_in_jobs_result.get('newServerCount'),
                'totalAfterNew': servers_in_jobs_result.get('totalAfterNew'),
                'maxServers': servers_in_jobs_result.get('maxServers')
            })
        
        # 4. Validate server replication states
        replication_result = validate_server_replication_states(region, all_server_ids)
        if not replication_result.get('valid'):
            return response(400, {
                'error': 'UNHEALTHY_SERVER_REPLICATION',
                'message': replication_result.get('message'),
                'unhealthyServers': replication_result.get('unhealthyServers'),
                'healthyCount': replication_result.get('healthyCount'),
                'unhealthyCount': replication_result.get('unhealthyCount')
            })
        
        print(f"✅ DRS service limits validation passed for plan {plan_id}")
        
        # Generate execution ID
        execution_id = str(uuid.uuid4())
        timestamp = int(time.time())
        
        print(f"Creating async execution {execution_id} for plan {plan_id}")
        
        # Create initial execution history record with PENDING status
        # Store PlanName directly so it's preserved even if plan is later deleted
        # Determine account context early so we can store it for resume
        account_context = body.get('AccountContext') or body.get('accountContext')
        if not account_context:
            # Derive from plan if not provided in request
            account_context = determine_target_account_context(plan)
        
        history_item = {
            'ExecutionId': execution_id,
            'PlanId': plan_id,
            'PlanName': plan.get('PlanName', 'Unknown'),  # Preserve plan name in execution record
            'ExecutionType': execution_type,
            'Status': 'PENDING',
            'StartTime': timestamp,
            'InitiatedBy': body['InitiatedBy'],
            'Waves': [],
            'TotalWaves': len(plan.get('Waves', [])),  # Store total wave count for UI display
            'AccountContext': account_context  # Store for resume operations
        }
        
        # Store execution history immediately
        execution_history_table.put_item(Item=history_item)
        
        # Invoke this same Lambda asynchronously to do the actual work
        # AWS_LAMBDA_FUNCTION_NAME is automatically set by Lambda runtime
        current_function_name = os.environ['AWS_LAMBDA_FUNCTION_NAME']
        
        # Prepare payload for async worker
        worker_payload = {
            'worker': True,  # Flag to route to worker handler
            'executionId': execution_id,
            'planId': plan_id,
            'executionType': execution_type,
            'isDrill': execution_type == 'DRILL',
            'plan': plan,
            'cognitoUser': cognito_user  # Pass Cognito user info to worker
        }
        
        # Invoke async (Event invocation type = fire and forget)
        try:
            invoke_response = lambda_client.invoke(
                FunctionName=current_function_name,
                InvocationType='Event',  # Async invocation
                Payload=json.dumps(worker_payload, cls=DecimalEncoder)
            )
            # Check for invocation errors (StatusCode should be 202 for async)
            status_code = invoke_response.get('StatusCode', 0)
            if status_code != 202:
                raise Exception(f"Async invocation returned unexpected status: {status_code}")
            print(f"Async worker invoked for execution {execution_id}, StatusCode: {status_code}")
        except Exception as invoke_error:
            # If async invocation fails, mark execution as FAILED immediately
            print(f"ERROR: Failed to invoke async worker: {str(invoke_error)}")
            execution_history_table.update_item(
                Key={'ExecutionId': execution_id, 'PlanId': plan_id},
                UpdateExpression='SET #status = :status, EndTime = :end_time, ErrorMessage = :error',
                ExpressionAttributeNames={'#status': 'Status'},
                ExpressionAttributeValues={
                    ':status': 'FAILED',
                    ':end_time': timestamp,
                    ':error': f'Failed to start worker: {str(invoke_error)}'
                }
            )
            return response(500, {
                'error': f'Failed to start execution worker: {str(invoke_error)}',
                'executionId': execution_id
            })
        
        # Return immediately with 202 Accepted
        return response(202, {
            'executionId': execution_id,
            'status': 'PENDING',
            'message': 'Execution started - check status with GET /executions/{id}',
            'statusUrl': f'/executions/{execution_id}'
        })
        
    except Exception as e:
        print(f"Error starting execution: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def execute_with_step_functions(execution_id: str, plan_id: str, plan: Dict, is_drill: bool, state_machine_arn: str, resume_from_wave: int = None) -> None:
    """
    Execute recovery plan using Step Functions
    This properly waits for EC2 instances to launch by checking participatingServers[].launchStatus
    
    Args:
        resume_from_wave: If set, this is a resumed execution starting from this wave index
    """
    try:
        if resume_from_wave is not None:
            print(f"RESUMING Step Functions execution for {execution_id} from wave {resume_from_wave}")
        else:
            print(f"Starting NEW Step Functions execution for {execution_id}")
        
        # Determine target account context for multi-account hub and spoke architecture
        account_context = determine_target_account_context(plan)
        
        # Prepare Step Functions input
        # Step Functions input format for step-functions-stack.yaml state machine
        # Uses 'Plan' (singular) not 'Plans' (array)
        # ALWAYS include ResumeFromWave (null for new executions) so Step Functions doesn't fail
        sfn_input = {
            'Execution': {'Id': execution_id},
            'Plan': {
                'PlanId': plan_id,
                'PlanName': plan.get('PlanName', 'Unknown'),
                'Waves': plan.get('Waves', [])
            },
            'IsDrill': is_drill,
            'ResumeFromWave': resume_from_wave,  # None for new executions, wave index for resume
            'AccountContext': account_context
        }
        
        # For resumed executions, use a unique name suffix to avoid conflicts
        sfn_name = execution_id if resume_from_wave is None else f"{execution_id}-resume-{resume_from_wave}"
        
        # Start Step Functions execution
        sfn_response = stepfunctions.start_execution(
            stateMachineArn=state_machine_arn,
            name=sfn_name,
            input=json.dumps(sfn_input, cls=DecimalEncoder)
        )
        
        print(f"Step Functions execution started: {sfn_response['executionArn']}")
        
        # Update DynamoDB with Step Functions execution ARN
        execution_history_table.update_item(
            Key={'ExecutionId': execution_id, 'PlanId': plan_id},
            UpdateExpression='SET StateMachineArn = :arn, #status = :status',
            ExpressionAttributeNames={'#status': 'Status'},
            ExpressionAttributeValues={
                ':arn': sfn_response['executionArn'],
                ':status': 'RUNNING'
            }
        )
        
        print(f"✅ Step Functions execution initiated successfully")
        
    except Exception as e:
        print(f"❌ Error starting Step Functions execution: {e}")
        import traceback
        traceback.print_exc()
        
        # Update execution as failed
        try:
            execution_history_table.update_item(
                Key={'ExecutionId': execution_id, 'PlanId': plan_id},
                UpdateExpression='SET #status = :status, ErrorMessage = :error',
                ExpressionAttributeNames={'#status': 'Status'},
                ExpressionAttributeValues={
                    ':status': 'FAILED',
                    ':error': str(e)
                }
            )
        except Exception as update_error:
            print(f"Error updating execution failure: {update_error}")


def execute_recovery_plan_worker(payload: Dict) -> None:
    """Background worker - executes recovery via Step Functions
    
    Handles both new executions and resumed executions.
    For resumed executions, resumeFromWave specifies which wave to start from.
    """
    try:
        execution_id = payload['executionId']
        plan_id = payload['planId']
        is_drill = payload['isDrill']
        plan = payload['plan']
        cognito_user = payload.get('cognitoUser', {'email': 'system', 'userId': 'system'})
        resume_from_wave = payload.get('resumeFromWave')  # None for new executions, wave index for resume
        
        if resume_from_wave is not None:
            print(f"Worker RESUMING execution {execution_id} from wave {resume_from_wave} (isDrill: {is_drill})")
        else:
            print(f"Worker initiating NEW execution {execution_id} (isDrill: {is_drill})")
        print(f"Initiated by: {cognito_user.get('email')}")
        
        # Always use Step Functions
        state_machine_arn = os.environ.get('STATE_MACHINE_ARN')
        if not state_machine_arn:
            raise ValueError("STATE_MACHINE_ARN environment variable not set")
        
        print(f"Using Step Functions for execution {execution_id}")
        return execute_with_step_functions(execution_id, plan_id, plan, is_drill, state_machine_arn, resume_from_wave)
        
    except Exception as e:
        print(f"Worker error for execution {execution_id}: {str(e)}")
        import traceback
        traceback.print_exc()
        
        # Mark execution as failed
        try:
            execution_history_table.update_item(
                Key={'ExecutionId': execution_id, 'PlanId': plan_id},
                UpdateExpression='SET #status = :status, EndTime = :endtime, ErrorMessage = :error',
                ExpressionAttributeNames={'#status': 'Status'},
                ExpressionAttributeValues={
                    ':status': 'FAILED',
                    ':endtime': int(time.time()),
                    ':error': str(e)
                }
            )
        except Exception as update_error:
            print(f"Failed to update error status: {str(update_error)}")


def initiate_wave(
    wave: Dict, 
    protection_group_id: str, 
    execution_id: str, 
    is_drill: bool, 
    execution_type: str = 'DRILL',
    plan_name: str = None,  # STEP 6: Add metadata parameters
    wave_name: str = None,
    wave_number: int = None,
    cognito_user: Dict = None
) -> Dict:
    """Initiate DRS recovery jobs for a wave without waiting for completion"""
    try:
        # Get Protection Group
        pg_result = protection_groups_table.get_item(Key={'GroupId': protection_group_id})
        if 'Item' not in pg_result:
            return {
                'WaveName': wave.get('name', 'Unknown'),
                'ProtectionGroupId': protection_group_id,
                'Status': 'FAILED',
                'Error': 'Protection Group not found',
                'Servers': [],
                'StartTime': int(time.time())
            }
        
        pg = pg_result['Item']
        region = pg['Region']
        
        # Get servers from both wave and protection group
        pg_servers = pg.get('SourceServerIds', [])
        wave_servers = wave.get('ServerIds', [])
        
        # Filter to only launch servers specified in this wave
        # This ensures each wave launches its designated subset of servers
        if wave_servers:
            # Wave has explicit server list - filter PG servers to this subset
            server_ids = [s for s in wave_servers if s in pg_servers]
            print(f"Wave specifies {len(wave_servers)} servers, {len(server_ids)} are in Protection Group")
        else:
            # No ServerIds in wave - launch all PG servers (legacy behavior)
            server_ids = pg_servers
            print(f"Wave has no ServerIds field, launching all {len(server_ids)} Protection Group servers")
        
        if not server_ids:
            return {
                'WaveName': wave.get('name', 'Unknown'),
                'ProtectionGroupId': protection_group_id,
                'Status': 'INITIATED',
                'Servers': [],
                'StartTime': int(time.time())
            }
        
        print(f"Initiating recovery for {len(server_ids)} servers in region {region}")
        
        # CRITICAL FIX: Launch ALL servers in wave with ONE DRS API call
        # This gives us ONE job ID per wave (which poller expects)
        # STEP 6: Pass metadata to start_drs_recovery_for_wave
        wave_job_result = start_drs_recovery_for_wave(
            server_ids, region, is_drill, execution_id, execution_type,
            plan_name=plan_name,
            wave_name=wave_name,
            wave_number=wave_number,
            cognito_user=cognito_user
        )
        
        # Extract job ID and server results
        wave_job_id = wave_job_result.get('JobId')
        server_results = wave_job_result.get('Servers', [])
        
        # Wave status is INITIATED (not IN_PROGRESS)
        # External poller will update to IN_PROGRESS/COMPLETED
        has_failures = any(s['Status'] == 'FAILED' for s in server_results)
        wave_status = 'PARTIAL' if has_failures else 'INITIATED'
        
        return {
            'WaveName': wave.get('name', 'Unknown'),
            'WaveId': wave.get('WaveId') or wave.get('waveNumber'),  # Support both formats
            'JobId': wave_job_id,  # CRITICAL: Wave-level Job ID for poller
            'ProtectionGroupId': protection_group_id,
            'Region': region,
            'Status': wave_status,
            'Servers': server_results,
            'StartTime': int(time.time())
        }
        
    except Exception as e:
        print(f"Error initiating wave: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            'WaveName': wave.get('name', 'Unknown'),
            'ProtectionGroupId': protection_group_id,
            'Status': 'FAILED',
            'Error': str(e),
            'Servers': [],
            'StartTime': int(time.time())
        }


def get_server_launch_configurations(region: str, server_ids: List[str]) -> Dict[str, Dict]:
    """
    Fetch launch configurations for all servers in wave from DRS
    
    Args:
        region: AWS region
        server_ids: List of DRS source server IDs
    
    Returns:
        Dictionary mapping server_id to launch configuration
        
    Example:
        {
            's-111': {
                'targetInstanceTypeRightSizingMethod': 'BASIC',
                'copyPrivateIp': False,
                'copyTags': True
            },
            's-222': {
                'targetInstanceTypeRightSizingMethod': 'NONE',
                'copyPrivateIp': True,
                'copyTags': True
            }
        }
    """
    drs_client = boto3.client('drs', region_name=region)
    configs = {}
    
    for server_id in server_ids:
        try:
            response = drs_client.get_launch_configuration(
                sourceServerID=server_id
            )
            
            configs[server_id] = {
                'targetInstanceTypeRightSizingMethod': response.get('targetInstanceTypeRightSizingMethod', 'BASIC'),
                'copyPrivateIp': response.get('copyPrivateIp', False),
                'copyTags': response.get('copyTags', True),
                'launchDisposition': response.get('launchDisposition', 'STARTED'),
                'bootMode': response.get('bootMode', 'USE_DEFAULT')
            }
            
            print(f"[Launch Config] {server_id}: rightSizing={configs[server_id]['targetInstanceTypeRightSizingMethod']}")
            
        except Exception as e:
            print(f"[Launch Config] ERROR for {server_id}: {str(e)}")
            # FALLBACK: Use safe defaults if config query fails
            configs[server_id] = {
                'targetInstanceTypeRightSizingMethod': 'BASIC',
                'copyPrivateIp': False,
                'copyTags': True,
                'launchDisposition': 'STARTED',
                'bootMode': 'USE_DEFAULT'
            }
            print(f"[Launch Config] {server_id}: Using fallback defaults")
    
    return configs


def start_drs_recovery_for_wave(
    server_ids: List[str], 
    region: str, 
    is_drill: bool, 
    execution_id: str, 
    execution_type: str = 'DRILL',
    plan_name: str = None,  # STEP 7: Add metadata parameters
    wave_name: str = None,
    wave_number: int = None,
    cognito_user: Dict = None
) -> Dict:
    """
    Launch DRS recovery for all servers in a wave with ONE API call
    
    CRITICAL PATTERN (from DRS drill learning session):
    - Launches ALL servers in wave with SINGLE start_recovery() call
    - Returns ONE job ID for entire wave (not per server)
    - This job ID is what ExecutionPoller tracks for wave completion
    - All servers in wave share same job ID and are tracked together
    
    DRS API Response Structure:
    {
        'job': {
            'jobID': 'drsjob-xxxxx',
            'status': 'PENDING',  # Initial status
            'type': 'LAUNCH',
            'participatingServers': [
                {'sourceServerID': 's-xxx', 'launchStatus': 'PENDING'}
            ]
        }
    }
    
    Expected Job Status Progression:
    PENDING → STARTED → COMPLETED (or FAILED)
    
    Per-Server Launch Status:
    PENDING → LAUNCHED → (job completes)
    
    Args:
        server_ids: List of DRS source server IDs to launch
        region: AWS region for DRS API call
        is_drill: True for drill, False for actual recovery
        execution_id: Execution ID for tracking
        execution_type: 'DRILL' or 'RECOVERY'
    
    Returns:
        Dict with JobId (wave-level) and Servers array
    """
    try:
        drs_client = boto3.client('drs', region_name=region)
        
        print(f"[DRS API] Starting {execution_type} {'drill' if is_drill else 'recovery'}")
        print(f"[DRS API] Region: {region}, Servers: {len(server_ids)}")
        print(f"[DRS API] Server IDs: {server_ids}")
        
        # STEP 1: Fetch per-server launch configurations from DRS
        print(f"[DRS API] Fetching launch configurations for {len(server_ids)} servers...")
        launch_configs = get_server_launch_configurations(region, server_ids)

        # STEP 3: Build sourceServers array (simplified - DRS uses latest snapshot automatically)
        source_servers = [{'sourceServerID': sid} for sid in server_ids]
        print(f"[DRS API] Built sourceServers array for {len(server_ids)} servers")

        # CRITICAL FIX: Do NOT pass tags to start_recovery()
        # The reference implementation (drs-plan-automation) does NOT use tags
        # CLI without tags works, code with tags fails (conversion skipped)
        # Tags were causing DRS to skip the CONVERSION phase entirely
        
        # STEP 4: Start recovery for ALL servers in ONE API call WITHOUT TAGS
        print(f"[DRS API] Calling start_recovery() WITHOUT tags (reference implementation pattern)")
        print(f"[DRS API]   sourceServers: {len(source_servers)} servers")
        print(f"[DRS API]   isDrill: {is_drill}")
        print(f"[DRS API]   NOTE: Tags removed - they were causing conversion to be skipped!")
        
        response = drs_client.start_recovery(
            sourceServers=source_servers,
            isDrill=is_drill
            # NO TAGS - this is the fix!
        )
        
        # Validate response structure (defensive programming)
        if 'job' not in response:
            raise Exception("DRS API response missing 'job' field")
        
        job = response['job']
        job_id = job.get('jobID')
        
        if not job_id:
            raise Exception("DRS API response missing 'jobID' field")
        
        job_status = job.get('status', 'UNKNOWN')
        job_type = job.get('type', 'UNKNOWN')
        
        print(f"[DRS API] ✅ Job created successfully")
        print(f"[DRS API]   Job ID: {job_id}")
        print(f"[DRS API]   Status: {job_status}")
        print(f"[DRS API]   Type: {job_type}")
        print(f"[DRS API]   Servers: {len(server_ids)} (all share this job ID)")
        
        # Build server results array (all servers share same job ID)
        server_results = []
        for server_id in server_ids:
            server_results.append({
                'SourceServerId': server_id,
                'RecoveryJobId': job_id,  # Same job ID for all servers
                'Status': 'LAUNCHING',
                'InstanceId': None,
                'LaunchTime': int(time.time()),
                'Error': None
            })
        
        print(f"[DRS API] Wave initiation complete - ExecutionPoller will track job {job_id}")
        
        return {
            'JobId': job_id,  # Wave-level Job ID for poller
            'Servers': server_results
        }
        
    except Exception as e:
        error_msg = str(e)
        error_type = type(e).__name__
        
        print(f"[DRS API] ❌ Failed to start recovery for wave")
        print(f"[DRS API]   Error Type: {error_type}")
        print(f"[DRS API]   Error Message: {error_msg}")
        print(f"[DRS API]   Region: {region}")
        print(f"[DRS API]   Server Count: {len(server_ids)}")
        
        # Log full traceback for debugging
        import traceback
        traceback.print_exc()
        
        # Return failed results for all servers
        server_results = []
        for server_id in server_ids:
            server_results.append({
                'SourceServerId': server_id,
                'Status': 'FAILED',
                'Error': f"{error_type}: {error_msg}",
                'LaunchTime': int(time.time())
            })
        
        return {
            'JobId': None,
            'Servers': server_results
        }


def start_drs_recovery(server_id: str, region: str, is_drill: bool, execution_id: str, execution_type: str = 'DRILL') -> Dict:
    """Launch DRS recovery for a single source server"""
    try:
        drs_client = boto3.client('drs', region_name=region)
        
        print(f"Starting {execution_type} {'drill' if is_drill else 'recovery'} for server {server_id}")
        
        # Start recovery job
        # Omit recoverySnapshotID to use latest point-in-time snapshot (AWS default)
        response = drs_client.start_recovery(
            sourceServers=[{
                'sourceServerID': server_id
            }],
            isDrill=is_drill
        )
        
        job = response.get('job', {})
        job_id = job.get('jobID', 'unknown')
        
        print(f"Started recovery job {job_id} for server {server_id}")
        
        return {
            'SourceServerId': server_id,
            'RecoveryJobId': job_id,
            'Status': 'LAUNCHING',
            'InstanceId': None,  # Will be populated later when instance launches
            'LaunchTime': int(time.time()),
            'Error': None
        }
        
    except Exception as e:
        error_msg = str(e)
        print(f"Failed to start recovery for server {server_id}: {error_msg}")
        return {
            'SourceServerId': server_id,
            'Status': 'FAILED',
            'Error': error_msg,
            'LaunchTime': int(time.time())
        }


def start_drs_recovery_with_retry(server_id: str, region: str, is_drill: bool, execution_id: str) -> Dict:
    """Launch DRS recovery with ConflictException retry logic"""
    from botocore.exceptions import ClientError
    
    max_retries = 3
    base_delay = 30  # Base delay in seconds
    
    for attempt in range(max_retries):
        try:
            return start_drs_recovery(server_id, region, is_drill, execution_id)
        except ClientError as e:
            error_code = e.response['Error']['Code']
            
            # Only retry on ConflictException
            if error_code == 'ConflictException' and attempt < max_retries - 1:
                delay = base_delay * (2 ** attempt)  # Exponential backoff: 30s, 60s, 120s
                print(f"ConflictException for server {server_id} (attempt {attempt + 1}/{max_retries})")
                print(f"Server is being processed by another job, retrying in {delay}s...")
                time.sleep(delay)
                continue
            
            # Re-raise if not ConflictException or last attempt
            raise
        except Exception as e:
            # Re-raise non-ClientError exceptions immediately
            raise


def get_execution_status(execution_id: str) -> Dict:
    """Get current execution status"""
    try:
        # Get from DynamoDB using Query (table has composite key: ExecutionId + PlanId)
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )
        
        if not result.get('Items'):
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })
        
        execution = result['Items'][0]
        
        # Get current status from Step Functions if still running
        if execution['Status'] == 'RUNNING':
            try:
                # Build proper Step Functions execution ARN from execution ID
                state_machine_arn = execution.get('StateMachineArn')
                if state_machine_arn:
                    sf_response = stepfunctions.describe_execution(
                        executionArn=state_machine_arn
                    )
                    execution['StepFunctionsStatus'] = sf_response['status']
            except Exception as e:
                print(f"Error getting Step Functions status: {str(e)}")
        
        return response(200, execution)
        
    except Exception as e:
        print(f"Error getting execution status: {str(e)}")
        return response(500, {'error': str(e)})


def get_execution_history(plan_id: str) -> Dict:
    """Get execution history for a Recovery Plan"""
    try:
        result = execution_history_table.query(
            IndexName='PlanIdIndex',
            KeyConditionExpression=Key('PlanId').eq(plan_id),
            ScanIndexForward=False  # Sort by StartTime descending
        )
        
        executions = result.get('Items', [])
        
        return response(200, {
            'executions': executions,
            'count': len(executions)
        })
        
    except Exception as e:
        print(f"Error getting execution history: {str(e)}")
        return response(500, {'error': str(e)})


def list_executions(query_params: Dict) -> Dict:
    """List all executions with optional pagination and account filtering"""
    try:
        limit = int(query_params.get('limit', 50))
        next_token = query_params.get('nextToken')
        account_id = query_params.get('accountId')
        
        # Scan execution history table
        scan_args = {
            'Limit': min(limit, 100)  # Cap at 100
        }
        
        if next_token:
            scan_args['ExclusiveStartKey'] = json.loads(next_token)
        
        result = execution_history_table.scan(**scan_args)
        
        executions = result.get('Items', [])
        
        # Filter by account if specified
        if account_id:
            filtered_executions = []
            for execution in executions:
                # Check if execution has account info or matches current account
                exec_account = execution.get('AccountId')
                if exec_account == account_id or not exec_account:
                    # Include executions that match account or have no account specified (legacy)
                    filtered_executions.append(execution)
            executions = filtered_executions
        
        # Sort by StartTime descending (most recent first)
        executions.sort(key=lambda x: x.get('StartTime', 0), reverse=True)
        
        # Enrich with recovery plan names and transform to camelCase
        transformed_executions = []
        for execution in executions:
            try:
                # Use stored PlanName first (preserved even if plan deleted)
                # Fall back to lookup only if not stored (legacy executions)
                if execution.get('PlanName'):
                    execution['RecoveryPlanName'] = execution['PlanName']
                else:
                    plan_id = execution.get('PlanId')
                    if plan_id:
                        plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
                        if 'Item' in plan_result:
                            execution['RecoveryPlanName'] = plan_result['Item'].get('PlanName', 'Unknown')
                        else:
                            execution['RecoveryPlanName'] = 'Deleted Plan'
                    else:
                        execution['RecoveryPlanName'] = 'Unknown'
                
                # Determine selection mode from protection groups
                plan_id = execution.get('PlanId')
                selection_mode = 'PLAN'  # Default to plan-based
                if plan_id:
                    plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
                    if 'Item' in plan_result:
                        plan = plan_result['Item']
                        waves = plan.get('Waves', [])
                        pg_ids = set()
                        for wave in waves:
                            pg_id = wave.get('ProtectionGroupId')
                            if pg_id:
                                pg_ids.add(pg_id)
                        
                        # Check each protection group for ServerSelectionTags
                        for pg_id in pg_ids:
                            try:
                                pg_result = protection_groups_table.get_item(Key={'GroupId': pg_id})
                                if 'Item' in pg_result:
                                    pg = pg_result['Item']
                                    tags = pg.get('ServerSelectionTags', {})
                                    if tags and len(tags) > 0:
                                        selection_mode = 'TAGS'
                                        break  # Found tag-based, no need to check more
                            except Exception as pg_err:
                                print(f"Error checking PG {pg_id}: {str(pg_err)}")
                
                execution['SelectionMode'] = selection_mode
            except Exception as e:
                print(f"Error enriching execution {execution.get('ExecutionId')}: {str(e)}")
                if not execution.get('RecoveryPlanName'):
                    execution['RecoveryPlanName'] = 'Unknown'
                execution['SelectionMode'] = 'PLAN'
            
            # For CANCELLED/CANCELLING executions, check if any wave has active DRS jobs
            # This helps frontend show them in "Active" section instead of "History"
            exec_status = execution.get('Status', '').upper()
            print(f"Checking execution {execution.get('ExecutionId')} with status {exec_status}")
            if exec_status in ['CANCELLED', 'CANCELLING']:
                has_active_jobs = False
                waves = execution.get('Waves', [])
                print(f"  Found {len(waves)} waves to check for active jobs")
                for wave in waves:
                    job_id = wave.get('JobId')
                    print(f"  Wave JobId: {job_id}, Region: {wave.get('Region')}")
                    if job_id:
                        region = wave.get('Region', 'us-east-1')
                        try:
                            drs_client = create_drs_client(region)
                            job_response = drs_client.describe_jobs(filters={'jobIDs': [job_id]})
                            jobs = job_response.get('items', [])
                            job_status = jobs[0].get('status') if jobs else 'NOT_FOUND'
                            print(f"  DRS job {job_id} status: {job_status}")
                            if jobs and jobs[0].get('status') in ['PENDING', 'STARTED']:
                                has_active_jobs = True
                                print(f"  Found active DRS job!")
                                break
                        except Exception as job_err:
                            print(f"Error checking job {job_id}: {job_err}")
                execution['HasActiveDrsJobs'] = has_active_jobs
                print(f"  HasActiveDrsJobs set to: {has_active_jobs}")
            else:
                execution['HasActiveDrsJobs'] = False
            
            # Transform to camelCase for frontend
            transformed_executions.append(transform_execution_to_camelcase(execution))
        
        # Build response with pagination
        response_data = {
            'items': transformed_executions,
            'count': len(transformed_executions)
        }
        
        if 'LastEvaluatedKey' in result:
            response_data['nextToken'] = json.dumps(result['LastEvaluatedKey'])
        else:
            response_data['nextToken'] = None
        
        print(f"Listed {len(executions)} executions")
        return response(200, response_data)
        
    except Exception as e:
        print(f"Error listing executions: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def get_server_details_map(server_ids: List[str], region: str = 'us-east-1') -> Dict[str, Dict]:
    """
    Get DRS source server details for a list of server IDs.
    Returns a map of serverId -> {hostname, name, region, sourceInstanceId, sourceAccountId, ...}
    """
    server_map = {}
    if not server_ids:
        return server_map
    
    try:
        # Use regional DRS client if needed
        drs_client = boto3.client('drs', region_name=region)
        
        # Get source servers (DRS API doesn't support filtering by ID list, so get all and filter)
        paginator = drs_client.get_paginator('describe_source_servers')
        for page in paginator.paginate():
            for server in page.get('items', []):
                source_id = server.get('sourceServerID')
                if source_id in server_ids:
                    # Extract hostname and source instance ID from sourceProperties
                    source_props = server.get('sourceProperties', {})
                    hostname = source_props.get('identificationHints', {}).get('hostname', '')
                    
                    # Get source EC2 instance ID (the original instance being replicated)
                    source_instance_id = source_props.get('identificationHints', {}).get('awsInstanceID', '')
                    
                    # Get Name tag if available
                    tags = server.get('tags', {})
                    name_tag = tags.get('Name', '')
                    
                    # Get source account ID from staging area info or ARN
                    source_account_id = ''
                    staging_area = server.get('stagingArea', {})
                    if staging_area:
                        source_account_id = staging_area.get('stagingAccountID', '')
                    # Fallback: extract from ARN if available
                    if not source_account_id:
                        arn = server.get('arn', '')
                        if arn:
                            # ARN format: arn:aws:drs:region:account:source-server/id
                            arn_parts = arn.split(':')
                            if len(arn_parts) >= 5:
                                source_account_id = arn_parts[4]
                    
                    # Extract source IP from network interfaces
                    network_interfaces = source_props.get('networkInterfaces', [])
                    source_ip = ''
                    if network_interfaces:
                        # Get first private IP from first interface
                        first_iface = network_interfaces[0]
                        ips = first_iface.get('ips', [])
                        if ips:
                            source_ip = ips[0]
                    
                    # Extract source region from replication info
                    source_region = ''
                    data_rep_info = server.get('dataReplicationInfo', {})
                    replicated_disks = data_rep_info.get('replicatedDisks', [])
                    if replicated_disks:
                        # Extract region from device name or use staging area region
                        staging_area = server.get('stagingArea', {})
                        source_region = staging_area.get('stagingSourceServerArn', '').split(':')[3] if staging_area.get('stagingSourceServerArn') else ''
                    
                    # Fallback: get source region from sourceProperties
                    if not source_region:
                        source_region = source_props.get('identificationHints', {}).get('awsInstanceID', '').split(':')[3] if ':' in source_props.get('identificationHints', {}).get('awsInstanceID', '') else ''
                    
                    server_map[source_id] = {
                        'hostname': hostname,
                        'nameTag': name_tag,  # Will be updated from EC2 below
                        'region': region,
                        'sourceInstanceId': source_instance_id,
                        'sourceAccountId': source_account_id,
                        'sourceIp': source_ip,
                        'sourceRegion': source_region or region,  # Fallback to target region if not found
                        'replicationState': server.get('dataReplicationInfo', {}).get('dataReplicationState', 'UNKNOWN'),
                        'lastLaunchResult': server.get('lastLaunchResult', 'NOT_STARTED'),
                    }
        
        # Fetch EC2 Name tags from source instances
        source_instance_ids = [s['sourceInstanceId'] for s in server_map.values() if s.get('sourceInstanceId')]
        if source_instance_ids:
            try:
                ec2_client = boto3.client('ec2', region_name=region)
                ec2_response = ec2_client.describe_instances(InstanceIds=source_instance_ids)
                ec2_name_tags = {}
                for reservation in ec2_response.get('Reservations', []):
                    for instance in reservation.get('Instances', []):
                        instance_id = instance.get('InstanceId', '')
                        for tag in instance.get('Tags', []):
                            if tag.get('Key') == 'Name':
                                ec2_name_tags[instance_id] = tag.get('Value', '')
                                break
                
                # Update server_map with EC2 Name tags
                for source_id, details in server_map.items():
                    instance_id = details.get('sourceInstanceId')
                    if instance_id and instance_id in ec2_name_tags:
                        details['nameTag'] = ec2_name_tags[instance_id]
            except Exception as ec2_error:
                print(f"Error fetching EC2 Name tags: {ec2_error}")
                
    except Exception as e:
        print(f"Error getting server details: {e}")
    
    return server_map


def enrich_execution_with_server_details(execution: Dict) -> Dict:
    """
    Enrich execution waves with server details (hostname, name tag, region).
    """
    waves = execution.get('Waves', [])
    if not waves:
        return execution
    
    # Collect all server IDs and regions from waves
    all_server_ids = set()
    regions = set()
    for wave in waves:
        server_ids = wave.get('ServerIds', [])
        all_server_ids.update(server_ids)
        region = wave.get('Region', 'us-east-1')
        regions.add(region)
    
    if not all_server_ids:
        return execution
    
    # Get server details for each region
    server_details_map = {}
    for region in regions:
        region_servers = get_server_details_map(list(all_server_ids), region)
        server_details_map.update(region_servers)
    
    # Enrich waves with server details
    for wave in waves:
        server_ids = wave.get('ServerIds', [])
        region = wave.get('Region', 'us-east-1')
        
        # Build enriched server list
        enriched_servers = []
        for server_id in server_ids:
            details = server_details_map.get(server_id, {})
            enriched_servers.append({
                'SourceServerId': server_id,
                'Hostname': details.get('hostname', ''),
                'NameTag': details.get('nameTag', ''),
                'Region': region,
                'SourceInstanceId': details.get('sourceInstanceId', ''),
                'SourceAccountId': details.get('sourceAccountId', ''),
                'SourceIp': details.get('sourceIp', ''),
                'SourceRegion': details.get('sourceRegion', ''),
                'ReplicationState': details.get('replicationState', 'UNKNOWN'),
            })
        
        # Add enriched servers to wave
        wave['EnrichedServers'] = enriched_servers
    
    return execution


def get_execution_details(execution_id: str) -> Dict:
    """Get detailed information about a specific execution"""
    try:
        # Handle both UUID and ARN formats for backwards compatibility
        # ARN format: arn:aws:states:region:account:execution:state-machine-name:execution-uuid
        # Extract UUID from ARN if provided
        if execution_id.startswith('arn:'):
            # Extract the last segment which is the UUID
            execution_id = execution_id.split(':')[-1]
            print(f"Extracted UUID from ARN: {execution_id}")
        
        # Get from DynamoDB using query (table has composite key: ExecutionId + PlanId)
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )

        if 'Items' not in result or len(result['Items']) == 0:
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })

        execution = result['Items'][0]
        
        # Enrich with recovery plan details
        # Use stored PlanName first (preserved even if plan deleted)
        try:
            if execution.get('PlanName'):
                execution['RecoveryPlanName'] = execution['PlanName']
            
            plan_id = execution.get('PlanId')
            if plan_id:
                plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
                if 'Item' in plan_result:
                    plan = plan_result['Item']
                    # Only set from lookup if not already stored
                    if not execution.get('RecoveryPlanName'):
                        execution['RecoveryPlanName'] = plan.get('PlanName', 'Unknown')
                    execution['RecoveryPlanDescription'] = plan.get('Description', '')
                    execution['TotalWaves'] = len(plan.get('Waves', []))
                elif not execution.get('RecoveryPlanName'):
                    execution['RecoveryPlanName'] = 'Deleted Plan'
        except Exception as e:
            print(f"Error enriching execution with plan details: {str(e)}")
        
        # Enrich with server details (hostname, name tag, region)
        try:
            execution = enrich_execution_with_server_details(execution)
        except Exception as e:
            print(f"Error enriching execution with server details: {str(e)}")
        
        # Get current status from Step Functions if still running and has StateMachineArn
        if execution.get('Status') == 'RUNNING' and execution.get('StateMachineArn'):
            try:
                sf_response = stepfunctions.describe_execution(
                    executionArn=execution.get('StateMachineArn')
                )
                execution['StepFunctionsStatus'] = sf_response['status']
                
                # Update DynamoDB if Step Functions shows completion
                if sf_response['status'] in ['SUCCEEDED', 'FAILED', 'TIMED_OUT', 'ABORTED']:
                    new_status = 'COMPLETED' if sf_response['status'] == 'SUCCEEDED' else 'FAILED'
                    execution_history_table.update_item(
                        Key={'ExecutionId': execution_id, 'PlanId': execution.get('PlanId')},
                        UpdateExpression='SET #status = :status, EndTime = :endtime',
                        ExpressionAttributeNames={'#status': 'Status'},
                        ExpressionAttributeValues={
                            ':status': new_status,
                            ':endtime': int(time.time())
                        }
                    )
                    execution['Status'] = new_status
                    execution['EndTime'] = int(time.time())
            except Exception as e:
                print(f"Error getting Step Functions status: {str(e)}")
        
        # CONSISTENCY FIX: Transform to camelCase for frontend (same as list_executions)
        # This ensures ALL API endpoints return consistent camelCase format
        transformed_execution = transform_execution_to_camelcase(execution)
        return response(200, transformed_execution)
        
    except Exception as e:
        print(f"Error getting execution details: {str(e)}")
        return response(500, {'error': str(e)})


def cancel_execution(execution_id: str) -> Dict:
    """Cancel a running execution - cancels only pending waves, not completed or in-progress ones.
    
    Behavior:
    - COMPLETED waves: Preserved as-is
    - IN_PROGRESS/POLLING/LAUNCHING waves: Continue running (not interrupted)
    - PENDING/NOT_STARTED waves: Marked as CANCELLED
    - Waves not yet started (from plan): Added with CANCELLED status
    - Overall execution status: Set to CANCELLED only if no waves are still running
    """
    try:
        # FIX: Query by ExecutionId to get PlanId (composite key required)
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )
        
        if not result.get('Items'):
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })
        
        execution = result['Items'][0]
        plan_id = execution.get('PlanId')
        
        # Check if execution is still running
        current_status = execution.get('Status')
        cancellable_statuses = ['RUNNING', 'PAUSED', 'PAUSE_PENDING', 'CANCELLING', 'IN_PROGRESS', 'POLLING', 'INITIATED', 'PENDING']
        if current_status not in cancellable_statuses:
            return response(400, {
                'error': 'EXECUTION_NOT_CANCELLABLE',
                'message': f'Execution cannot be cancelled - status is {current_status}',
                'currentStatus': current_status,
                'cancellableStatuses': cancellable_statuses,
                'reason': 'Execution must be running, paused, or pending to cancel'
            })
        
        # Get waves from execution and plan
        waves = execution.get('Waves', [])
        timestamp = int(time.time())
        
        # Get recovery plan to find waves that haven't started yet
        plan_waves = []
        try:
            plan_result = recovery_plans_table.get_item(Key={'PlanId': plan_id})
            if 'Item' in plan_result:
                plan_waves = plan_result['Item'].get('Waves', [])
        except Exception as e:
            print(f"Error getting recovery plan: {e}")
        
        # Track wave states
        completed_waves = []
        in_progress_waves = []
        cancelled_waves = []
        
        # Statuses that indicate a wave is done
        completed_statuses = ['COMPLETED', 'FAILED', 'TIMEOUT']
        # Statuses that indicate a wave is currently running
        in_progress_statuses = ['IN_PROGRESS', 'POLLING', 'LAUNCHING', 'INITIATED', 'STARTED']
        
        # Track which wave numbers exist in execution
        existing_wave_numbers = set()
        
        for i, wave in enumerate(waves):
            wave_status = (wave.get('Status') or '').upper()
            wave_number = wave.get('WaveNumber', i)
            existing_wave_numbers.add(wave_number)
            
            if wave_status in completed_statuses:
                completed_waves.append(wave_number)
                # Leave completed waves unchanged
            elif wave_status in in_progress_statuses:
                in_progress_waves.append(wave_number)
                # Leave in-progress waves running - they will complete naturally
            else:
                # Pending/not started waves in execution - mark as CANCELLED
                waves[i]['Status'] = 'CANCELLED'
                waves[i]['EndTime'] = timestamp
                cancelled_waves.append(wave_number)
        
        # Add waves from plan that haven't started yet (not in execution's Waves array)
        for i, plan_wave in enumerate(plan_waves):
            wave_number = plan_wave.get('WaveNumber', i)
            if wave_number not in existing_wave_numbers:
                # This wave hasn't started - add it as CANCELLED
                cancelled_wave = {
                    'WaveNumber': wave_number,
                    'WaveName': plan_wave.get('WaveName', f'Wave {wave_number + 1}'),
                    'Status': 'CANCELLED',
                    'EndTime': timestamp,
                    'ProtectionGroupId': plan_wave.get('ProtectionGroupId'),
                    'ServerIds': plan_wave.get('ServerIds', [])
                }
                waves.append(cancelled_wave)
                cancelled_waves.append(wave_number)
        
        # Sort waves by wave number for consistent display
        waves.sort(key=lambda w: w.get('WaveNumber', 0))
        
        # Stop Step Functions execution only if no waves are in progress
        # If a wave is running, let it complete naturally
        if not in_progress_waves:
            try:
                # amazonq-ignore-next-line
                stepfunctions.stop_execution(
                    executionArn=execution_id,
                    error='UserCancelled',
                    cause='Execution cancelled by user'
                )
                print(f"Stopped Step Functions execution: {execution_id}")
            except Exception as e:
                print(f"Error stopping Step Functions execution: {str(e)}")
                # Continue to update DynamoDB even if Step Functions call fails
        
        # Determine final execution status
        # If waves are still in progress, mark as CANCELLING (will be finalized when wave completes)
        # If no waves in progress, mark as CANCELLED
        final_status = 'CANCELLING' if in_progress_waves else 'CANCELLED'
        
        # Update DynamoDB with updated waves and status
        update_expression = 'SET #status = :status, Waves = :waves'
        expression_values = {
            ':status': final_status,
            ':waves': waves
        }
        
        # Only set EndTime if fully cancelled (no in-progress waves)
        if not in_progress_waves:
            update_expression += ', EndTime = :endtime'
            expression_values[':endtime'] = timestamp
        
        execution_history_table.update_item(
            Key={'ExecutionId': execution_id, 'PlanId': plan_id},
            UpdateExpression=update_expression,
            ExpressionAttributeNames={'#status': 'Status'},
            ExpressionAttributeValues=expression_values
        )
        
        print(f"Cancel execution {execution_id}: completed={completed_waves}, in_progress={in_progress_waves}, cancelled={cancelled_waves}")
        
        return response(200, {
            'executionId': execution_id,
            'status': final_status,
            'message': f'Execution {"cancelling" if in_progress_waves else "cancelled"} successfully',
            'details': {
                'completedWaves': completed_waves,
                'inProgressWaves': in_progress_waves,
                'cancelledWaves': cancelled_waves
            }
        })
        
    except Exception as e:
        print(f"Error cancelling execution: {str(e)}")
        return response(500, {'error': str(e)})


def pause_execution(execution_id: str) -> Dict:
    """Pause execution - schedules pause after current wave completes.
    
    Behavior:
    - If wave is in progress AND pending waves exist: Mark as PAUSE_PENDING
      (current wave continues, pause takes effect before next wave)
    - If between waves AND pending waves exist: Mark as PAUSED immediately
    - If no pending waves: Error (nothing to pause)
    - Single wave executions cannot be paused
    """
    try:
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )
        
        if not result.get('Items'):
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })
        
        execution = result['Items'][0]
        plan_id = execution.get('PlanId')
        current_status = execution.get('Status', '')
        
        # Check if execution is in a pausable state
        pausable_statuses = ['RUNNING', 'IN_PROGRESS', 'POLLING']
        if current_status not in pausable_statuses:
            return response(400, {
                'error': 'EXECUTION_NOT_PAUSABLE',
                'message': f'Execution cannot be paused - status is {current_status}',
                'currentStatus': current_status,
                'pausableStatuses': pausable_statuses,
                'reason': 'Execution must be running to pause'
            })
        
        # Check wave states
        waves = execution.get('Waves', [])
        if not waves:
            return response(400, {
                'error': 'EXECUTION_NO_WAVES',
                'message': 'No waves found in execution - cannot pause',
                'executionId': execution_id,
                'currentStatus': current_status
            })
        
        # Single wave executions cannot be paused
        if len(waves) == 1:
            return response(400, {
                'error': 'SINGLE_WAVE_NOT_PAUSABLE',
                'message': 'Cannot pause single-wave execution - pause is only available for multi-wave recovery plans',
                'executionId': execution_id,
                'waveCount': 1,
                'reason': 'Pause is only available for multi-wave recovery plans'
            })
        
        # Find current wave state
        completed_statuses = ['COMPLETED', 'FAILED', 'TIMEOUT', 'CANCELLED']
        in_progress_statuses = ['IN_PROGRESS', 'POLLING', 'LAUNCHING', 'INITIATED', 'STARTED']
        
        has_in_progress_wave = False
        has_pending_wave = False
        current_wave_number = 0
        last_completed_wave = 0
        
        for i, wave in enumerate(waves):
            wave_status = (wave.get('Status') or '').upper()
            wave_number = wave.get('WaveNumber', i + 1)
            
            if wave_status in completed_statuses:
                last_completed_wave = wave_number
            elif wave_status in in_progress_statuses:
                has_in_progress_wave = True
                current_wave_number = wave_number
            else:
                # Pending wave (empty status, PENDING, NOT_STARTED)
                has_pending_wave = True
        
        # Must have pending waves to pause
        if not has_pending_wave:
            return response(400, {
                'error': 'NO_PENDING_WAVES',
                'message': 'Cannot pause - no pending waves remaining',
                'executionId': execution_id,
                'lastCompletedWave': last_completed_wave,
                'reason': 'All waves have already completed or failed'
            })
        
        # Determine pause type
        if has_in_progress_wave:
            # Wave is running - schedule pause for after it completes
            new_status = 'PAUSE_PENDING'
            message = f'Pause scheduled - will pause after wave {current_wave_number} completes'
        else:
            # Between waves - pause immediately
            new_status = 'PAUSED'
            message = 'Execution paused'
        
        execution_history_table.update_item(
            Key={'ExecutionId': execution_id, 'PlanId': plan_id},
            UpdateExpression='SET #status = :status',
            ExpressionAttributeNames={'#status': 'Status'},
            ExpressionAttributeValues={':status': new_status}
        )
        
        print(f"Pause execution {execution_id}: status={new_status}, current_wave={current_wave_number}")
        return response(200, {
            'executionId': execution_id,
            'status': new_status,
            'message': message,
            'lastCompletedWave': last_completed_wave
        })
        
    except Exception as e:
        print(f"Error pausing execution: {str(e)}")
        return response(500, {'error': str(e)})


def resume_execution(execution_id: str) -> Dict:
    """Resume a paused execution using Step Functions callback pattern.
    
    Resume is only valid when execution status is PAUSED and has a TaskToken.
    Uses SendTaskSuccess to signal Step Functions to continue from WaitForResume state.
    
    This function:
    1. Validates the execution is paused
    2. Gets the stored TaskToken from DynamoDB
    3. Calls SendTaskSuccess to resume the Step Functions execution
    """
    print(f"=== RESUME_EXECUTION CALLED === execution_id: {execution_id}")
    print(f"Table name: {EXECUTION_HISTORY_TABLE}")
    
    try:
        print(f"Querying DynamoDB for execution {execution_id}...")
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )
        print(f"Query result: {json.dumps(result, default=str)}")
        
        if not result.get('Items'):
            print(f"No items found for execution {execution_id}")
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })
        
        execution = result['Items'][0]
        plan_id = execution.get('PlanId')
        current_status = execution.get('Status', '')
        
        # Check if execution is paused
        if current_status != 'PAUSED':
            return response(400, {
                'error': 'Execution is not paused',
                'currentStatus': current_status,
                'reason': 'Only paused executions can be resumed'
            })
        
        # Get the stored task token
        task_token = execution.get('TaskToken')
        if not task_token:
            return response(400, {
                'error': 'No task token found',
                'reason': 'Execution is paused but has no task token for callback. This may be a legacy execution.'
            })
        
        # Get paused before wave info
        paused_before_wave = execution.get('PausedBeforeWave', 0)
        # Convert Decimal to int if needed
        if hasattr(paused_before_wave, '__int__'):
            paused_before_wave = int(paused_before_wave)
        
        print(f"Resuming execution {execution_id} from wave {paused_before_wave} using SendTaskSuccess")
        
        # Build the full application state that ResumeWavePlan expects
        # This must match the state structure from orchestration_stepfunctions.py
        # Get the original plan waves (execution history has different structure)
        try:
            plan_response = recovery_plans_table.get_item(Key={'PlanId': plan_id})
            plan_waves = plan_response.get('Item', {}).get('Waves', [])
            # Convert DynamoDB format to plain dicts (handles Decimal types)
            waves_data = json.loads(json.dumps(plan_waves, cls=DecimalEncoder))
            print(f"Loaded {len(waves_data)} waves from recovery plan")
        except Exception as plan_error:
            print(f"Error loading plan waves: {plan_error}")
            return response(500, {'error': f'Failed to load recovery plan: {str(plan_error)}'})
        
        # Get account context from execution record (stored when execution started)
        # This is needed for cross-account DRS operations on resume
        account_context = execution.get('AccountContext', {})
        print(f"Account context for resume: {account_context}")
        
        resume_state = {
            'plan_id': plan_id,
            'execution_id': execution_id,
            'is_drill': execution.get('ExecutionType', 'DRILL') == 'DRILL',
            'waves': waves_data,
            'current_wave_number': paused_before_wave,
            'all_waves_completed': False,
            'wave_completed': False,
            'current_wave_update_time': 30,
            'current_wave_total_wait_time': 0,
            'current_wave_max_wait_time': 1800,
            'status': 'running',
            'wave_results': [],
            'job_id': None,
            'region': None,
            'server_ids': [],
            'error': None,
            'paused_before_wave': paused_before_wave,
            'AccountContext': account_context  # PascalCase to match Step Functions expectations
        }
        
        print(f"Resume state: {json.dumps(resume_state, cls=DecimalEncoder)}")
        
        # Call SendTaskSuccess to resume the Step Functions execution
        # The output becomes the state for ResumeWavePlan (no Payload wrapper for callbacks)
        try:
            stepfunctions.send_task_success(
                taskToken=task_token,
                output=json.dumps(resume_state, cls=DecimalEncoder)
            )
            print(f"✅ SendTaskSuccess called for execution {execution_id}")
        except stepfunctions.exceptions.TaskTimedOut:
            return response(400, {
                'error': 'Task timed out',
                'reason': 'The Step Functions task has timed out. The execution may need to be restarted.'
            })
        except stepfunctions.exceptions.InvalidToken:
            return response(400, {
                'error': 'Invalid task token',
                'reason': 'The task token is no longer valid. The execution may have been cancelled or timed out.'
            })
        except Exception as sfn_error:
            print(f"ERROR calling SendTaskSuccess: {str(sfn_error)}")
            return response(500, {'error': f'Failed to resume Step Functions: {str(sfn_error)}'})
        
        # Note: The orchestration Lambda (resume_wave action) will update the status to RUNNING
        # and clear the TaskToken when it processes the resume
        
        wave_display = paused_before_wave + 1  # 0-indexed to 1-indexed for display
        print(f"Resumed execution {execution_id}, wave {wave_display} will start")
        return response(200, {
            'executionId': execution_id,
            'status': 'RESUMING',
            'message': f'Execution resumed - wave {wave_display} will start',
            'nextWave': paused_before_wave
        })
        
    except Exception as e:
        print(f"Error resuming execution: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def get_job_log_items(execution_id: str, job_id: str = None) -> Dict:
    """Get DRS job log items for an execution's wave.
    
    Returns detailed progress events like:
    - SNAPSHOT_START / SNAPSHOT_END
    - CONVERSION_START / CONVERSION_END  
    - LAUNCH_START / LAUNCH_END
    
    Args:
        execution_id: The execution ID
        job_id: Optional specific job ID. If not provided, returns logs for all waves.
    """
    try:
        # Get execution to find job IDs (use query since table has composite key)
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )
        if not result.get('Items'):
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })
        
        execution = result['Items'][0]
        waves = execution.get('Waves', [])
        
        # Get account context from execution (region is per-wave)
        account_context = execution.get('AccountContext', {})
        
        all_job_logs = []
        
        for wave in waves:
            wave_job_id = wave.get('JobId') or wave.get('jobId')
            wave_number = wave.get('WaveNumber', wave.get('waveNumber', 0))
            
            # Get region from wave first, then execution, then default
            wave_region = wave.get('Region') or wave.get('region') or execution.get('Region', 'us-east-1')
            
            # Skip if no job ID or if specific job requested and doesn't match
            if not wave_job_id:
                continue
            if job_id and wave_job_id != job_id:
                continue
            
            try:
                # Create regional DRS client with cross-account support
                # Use wave-specific region since DRS jobs are regional
                drs_client = create_drs_client(wave_region, account_context)
                
                # Get job log items from DRS
                log_response = drs_client.describe_job_log_items(jobID=wave_job_id)
                log_items = log_response.get('items', [])
                
                # Transform log items for frontend
                wave_logs = {
                    'waveNumber': wave_number,
                    'jobId': wave_job_id,
                    'events': []
                }
                
                for item in log_items:
                    event = {
                        'event': item.get('event', 'UNKNOWN'),
                        'eventData': item.get('eventData', {}),
                        'logDateTime': item.get('logDateTime', '')
                    }
                    
                    # Extract source server info if available
                    event_data = item.get('eventData', {})
                    if 'sourceServerID' in event_data:
                        event['sourceServerId'] = event_data['sourceServerID']
                    if 'rawError' in event_data:
                        event['error'] = event_data['rawError']
                    if 'conversionServerID' in event_data:
                        event['conversionServerId'] = event_data['conversionServerID']
                    
                    wave_logs['events'].append(event)
                
                # Sort events by timestamp (newest first for display)
                wave_logs['events'].sort(
                    key=lambda x: x.get('logDateTime', ''), 
                    reverse=True
                )
                
                all_job_logs.append(wave_logs)
                
            except Exception as e:
                print(f"Error getting job log items for job {wave_job_id}: {e}")
                all_job_logs.append({
                    'waveNumber': wave_number,
                    'jobId': wave_job_id,
                    'events': [],
                    'error': str(e)
                })
        
        return response(200, {
            'executionId': execution_id,
            'jobLogs': all_job_logs
        })
        
    except Exception as e:
        print(f"Error getting job log items: {str(e)}")
        return response(500, {'error': str(e)})


def terminate_recovery_instances(execution_id: str) -> Dict:
    """Terminate all recovery instances from an execution.
    
    This will:
    1. Find all recovery instances created by this execution (from DRS jobs)
    2. Disconnect them from DRS (if applicable)
    3. Terminate the EC2 instances
    
    Only works for executions that have launched recovery instances.
    """
    try:
        # Get execution details
        result = execution_history_table.query(
            KeyConditionExpression=Key('ExecutionId').eq(execution_id),
            Limit=1
        )
        
        if not result.get('Items'):
            return response(404, {
                'error': 'EXECUTION_NOT_FOUND',
                'message': f'Execution with ID {execution_id} not found',
                'executionId': execution_id
            })
        
        execution = result['Items'][0]
        waves = execution.get('Waves', [])
        
        if not waves:
            return response(400, {
                'error': 'No waves found in execution',
                'reason': 'This execution has no wave data'
            })
        
        # Collect all recovery instance IDs from all waves
        instances_to_terminate = []
        instances_by_region = {}
        
        print(f"Processing {len(waves)} waves for execution {execution_id}")
        
        # Collect source server IDs for alternative lookup
        source_server_ids_by_region = {}
        
        # First, try to get instance IDs from DRS jobs
        for wave in waves:
            wave_number = wave.get('WaveNumber', 0)
            job_id = wave.get('JobId')
            region = wave.get('Region', 'us-east-1')
            wave_status = wave.get('Status', '')
            
            print(f"Wave {wave_number}: status={wave_status}, job_id={job_id}, region={region}")
            
            # Collect source server IDs from wave for alternative lookup
            wave_servers = wave.get('Servers', [])
            for srv in wave_servers:
                srv_id = srv.get('SourceServerId') or srv.get('sourceServerId')
                if srv_id:
                    if region not in source_server_ids_by_region:
                        source_server_ids_by_region[region] = []
                    if srv_id not in source_server_ids_by_region[region]:
                        source_server_ids_by_region[region].append(srv_id)
            
            # Only process waves that have a job ID (were actually launched)
            # Include STARTED status since recovery instances may exist even if wave is still in progress
            if job_id and wave_status in ['COMPLETED', 'LAUNCHED', 'PARTIAL', 'STARTED', 'IN_PROGRESS', 'RUNNING']:
                try:
                    drs_client = boto3.client('drs', region_name=region)
                    
                    # Get recovery instances from DRS job
                    job_response = drs_client.describe_jobs(
                        filters={'jobIDs': [job_id]}
                    )
                    
                    print(f"DRS describe_jobs response for {job_id}: {len(job_response.get('items', []))} items")
                    
                    if job_response.get('items'):
                        job = job_response['items'][0]
                        participating_servers = job.get('participatingServers', [])
                        
                        print(f"Job {job_id} has {len(participating_servers)} participating servers")
                        
                        for server in participating_servers:
                            recovery_instance_id = server.get('recoveryInstanceID')
                            source_server_id = server.get('sourceServerID', 'unknown')
                            
                            print(f"Server {source_server_id}: recoveryInstanceID={recovery_instance_id}")
                            
                            # Collect source server ID for alternative lookup
                            if source_server_id and source_server_id != 'unknown':
                                if region not in source_server_ids_by_region:
                                    source_server_ids_by_region[region] = []
                                if source_server_id not in source_server_ids_by_region[region]:
                                    source_server_ids_by_region[region].append(source_server_id)
                            
                            if recovery_instance_id:
                                # Get EC2 instance ID from recovery instance
                                try:
                                    ri_response = drs_client.describe_recovery_instances(
                                        filters={'recoveryInstanceIDs': [recovery_instance_id]}
                                    )
                                    if ri_response.get('items'):
                                        ec2_instance_id = ri_response['items'][0].get('ec2InstanceID')
                                        if ec2_instance_id and ec2_instance_id.startswith('i-'):
                                            instances_to_terminate.append({
                                                'instanceId': ec2_instance_id,
                                                'recoveryInstanceId': recovery_instance_id,
                                                'region': region,
                                                'waveNumber': wave_number,
                                                'serverId': source_server_id,
                                                'jobId': job_id
                                            })
                                            
                                            if region not in instances_by_region:
                                                instances_by_region[region] = []
                                            instances_by_region[region].append(ec2_instance_id)
                                except Exception as ri_err:
                                    print(f"Could not get EC2 instance for recovery instance {recovery_instance_id}: {ri_err}")
                                    
                except Exception as drs_err:
                    print(f"Could not query DRS job {job_id} in {region}: {drs_err}")
        
        # Alternative approach: Query describe_recovery_instances by source server IDs
        # This works even when job's participatingServers doesn't have recoveryInstanceID
        if not instances_to_terminate and source_server_ids_by_region:
            print(f"Trying alternative approach: query recovery instances by source server IDs")
            
            for region, source_ids in source_server_ids_by_region.items():
                print(f"Querying recovery instances for {len(source_ids)} source servers in {region}: {source_ids}")
                
                try:
                    drs_client = boto3.client('drs', region_name=region)
                    
                    # Query recovery instances by source server IDs
                    ri_response = drs_client.describe_recovery_instances(
                        filters={'sourceServerIDs': source_ids}
                    )
                    
                    recovery_instances = ri_response.get('items', [])
                    print(f"Found {len(recovery_instances)} recovery instances for source servers")
                    
                    for ri in recovery_instances:
                        ec2_instance_id = ri.get('ec2InstanceID')
                        recovery_instance_id = ri.get('recoveryInstanceID')
                        source_server_id = ri.get('sourceServerID', 'unknown')
                        
                        print(f"Recovery instance: ec2={ec2_instance_id}, ri={recovery_instance_id}, source={source_server_id}")
                        
                        if ec2_instance_id and ec2_instance_id.startswith('i-'):
                            instances_to_terminate.append({
                                'instanceId': ec2_instance_id,
                                'recoveryInstanceId': recovery_instance_id,
                                'region': region,
                                'waveNumber': 0,  # Unknown wave
                                'serverId': source_server_id
                            })
                            
                            if region not in instances_by_region:
                                instances_by_region[region] = []
                            if ec2_instance_id not in instances_by_region[region]:
                                instances_by_region[region].append(ec2_instance_id)
                                
                except Exception as e:
                    print(f"Error querying recovery instances by source server IDs in {region}: {e}")
        
        # Fallback: check stored data in ServerStatuses or Servers
        if not instances_to_terminate:
            for wave in waves:
                wave_number = wave.get('WaveNumber', 0)
                region = wave.get('Region', 'us-east-1')
                
                # Check ServerStatuses (newer format)
                server_statuses = wave.get('ServerStatuses', [])
                for server in server_statuses:
                    instance_id = (
                        server.get('RecoveryInstanceID') or 
                        server.get('recoveryInstanceId') or
                        server.get('EC2InstanceId') or
                        server.get('ec2InstanceId')
                    )
                    if instance_id and isinstance(instance_id, str) and instance_id.startswith('i-'):
                        instances_to_terminate.append({
                            'instanceId': instance_id,
                            'region': region,
                            'waveNumber': wave_number,
                            'serverId': server.get('SourceServerId', 'unknown')
                        })
                        if region not in instances_by_region:
                            instances_by_region[region] = []
                        instances_by_region[region].append(instance_id)
                
                # Check Servers (older format)
                servers = wave.get('Servers', [])
                for server in servers:
                    instance_id = (
                        server.get('RecoveryInstanceId') or 
                        server.get('recoveryInstanceId') or
                        server.get('InstanceId') or
                        server.get('instanceId') or
                        server.get('ec2InstanceId') or
                        server.get('EC2InstanceId')
                    )
                    if instance_id and isinstance(instance_id, str) and instance_id.startswith('i-'):
                        server_region = server.get('Region', region)
                        instances_to_terminate.append({
                            'instanceId': instance_id,
                            'region': server_region,
                            'waveNumber': wave_number,
                            'serverId': server.get('SourceServerId', 'unknown')
                        })
                        if server_region not in instances_by_region:
                            instances_by_region[server_region] = []
                        instances_by_region[server_region].append(instance_id)
        
        if not instances_to_terminate:
            return response(400, {
                'error': 'No recovery instances found',
                'reason': 'This execution has no recovery instances to terminate. Instances may not have been launched yet, may have already been terminated, or the DRS job data is unavailable.'
            })
        
        print(f"Found {len(instances_to_terminate)} recovery instances to terminate")
        
        # Group recovery instance IDs by region for DRS API call
        recovery_instances_by_region = {}
        for instance_info in instances_to_terminate:
            region = instance_info.get('region', 'us-east-1')
            # The recovery instance ID is the same as the EC2 instance ID in DRS
            recovery_instance_id = instance_info.get('recoveryInstanceId') or instance_info.get('instanceId')
            if recovery_instance_id:
                if region not in recovery_instances_by_region:
                    recovery_instances_by_region[region] = []
                if recovery_instance_id not in recovery_instances_by_region[region]:
                    recovery_instances_by_region[region].append(recovery_instance_id)
        
        # Use DRS TerminateRecoveryInstances API - this properly terminates via DRS
        # and creates a TERMINATE job in DRS console
        terminated = []
        failed = []
        jobs_created = []
        
        for region, recovery_instance_ids in recovery_instances_by_region.items():
            try:
                drs_client = boto3.client('drs', region_name=region)
                
                print(f"Calling DRS TerminateRecoveryInstances for {len(recovery_instance_ids)} instances in {region}: {recovery_instance_ids}")
                
                # Call DRS TerminateRecoveryInstances API
                # This creates a TERMINATE job and properly cleans up in DRS
                terminate_response = drs_client.terminate_recovery_instances(
                    recoveryInstanceIDs=recovery_instance_ids
                )
                
                # Get the job info from response
                job = terminate_response.get('job', {})
                job_id = job.get('jobID')
                
                if job_id:
                    jobs_created.append({
                        'jobId': job_id,
                        'region': region,
                        'type': job.get('type', 'TERMINATE'),
                        'status': job.get('status', 'PENDING')
                    })
                    print(f"Created DRS terminate job: {job_id}")
                
                # Track terminated instances
                for ri_id in recovery_instance_ids:
                    terminated.append({
                        'recoveryInstanceId': ri_id,
                        'region': region,
                        'jobId': job_id
                    })
                    
            except drs_client.exceptions.ConflictException as e:
                # Instances already being terminated or don't exist
                error_msg = str(e)
                print(f"ConflictException terminating recovery instances in {region}: {error_msg}")
                for ri_id in recovery_instance_ids:
                    failed.append({
                        'recoveryInstanceId': ri_id,
                        'region': region,
                        'error': 'Already terminated or being processed',
                        'errorType': 'CONFLICT'
                    })
            except Exception as e:
                error_msg = str(e)
                print(f"Error terminating recovery instances in {region}: {error_msg}")
                for ri_id in recovery_instance_ids:
                    failed.append({
                        'recoveryInstanceId': ri_id,
                        'region': region,
                        'error': error_msg
                    })
        
        print(f"Terminated {len(terminated)} recovery instances via DRS API")
        
        # Update execution with termination info
        try:
            plan_id = execution.get('PlanId')
            execution_history_table.update_item(
                Key={'ExecutionId': execution_id, 'PlanId': plan_id},
                UpdateExpression='SET InstancesTerminated = :terminated, InstancesTerminatedAt = :timestamp, TerminateJobs = :jobs',
                ExpressionAttributeValues={
                    ':terminated': True,
                    ':timestamp': int(time.time()),
                    ':jobs': jobs_created
                }
            )
        except Exception as e:
            print(f"Warning: Could not update execution with termination status: {str(e)}")
        
        # Check if all failures are due to conflict (already terminated)
        all_conflict = len(failed) > 0 and all(f.get('errorType') == 'CONFLICT' for f in failed)
        
        if len(terminated) == 0 and all_conflict:
            # All instances already terminated or being processed
            return response(200, {
                'executionId': execution_id,
                'message': 'Recovery instances already terminated or being processed',
                'terminated': terminated,
                'failed': failed,
                'jobs': jobs_created,
                'totalFound': len(instances_to_terminate),
                'totalTerminated': len(terminated),
                'totalFailed': len(failed),
                'alreadyTerminated': True
            })
        
        return response(200, {
            'executionId': execution_id,
            'message': f'Initiated termination of {len(terminated)} recovery instances via DRS',
            'terminated': terminated,
            'failed': failed,
            'jobs': jobs_created,
            'totalFound': len(instances_to_terminate),
            'totalTerminated': len(terminated),
            'totalFailed': len(failed)
        })
        
    except Exception as e:
        print(f"Error terminating recovery instances: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def get_termination_job_status(execution_id: str, job_ids_str: str, region: str) -> Dict:
    """Get status of DRS termination jobs for progress tracking.
    
    Args:
        execution_id: The execution ID
        job_ids_str: Comma-separated list of DRS job IDs
        region: AWS region where DRS jobs are running
    
    Returns:
        Job status with progress information
    """
    try:
        if not job_ids_str:
            return response(400, {'error': 'jobIds parameter required'})
        
        job_ids = [j.strip() for j in job_ids_str.split(',') if j.strip()]
        if not job_ids:
            return response(400, {'error': 'No valid job IDs provided'})
        
        print(f"Getting termination job status for {len(job_ids)} jobs in {region}: {job_ids}")
        
        drs_client = boto3.client('drs', region_name=region)
        
        jobs_response = drs_client.describe_jobs(
            filters={'jobIDs': job_ids}
        )
        
        jobs = jobs_response.get('items', [])
        print(f"Found {len(jobs)} jobs")
        
        # Calculate overall progress
        total_servers = 0
        completed_servers = 0
        all_completed = True
        any_failed = False
        job_details = []
        
        for job in jobs:
            job_id = job.get('jobID', '')
            status = job.get('status', 'UNKNOWN')
            job_type = job.get('type', '')
            participating = job.get('participatingServers', [])
            
            print(f"Job {job_id}: status={status}, type={job_type}, servers={len(participating)}")
            
            job_total = len(participating)
            job_completed = 0
            job_failed = 0
            
            for server in participating:
                launch_status = server.get('launchStatus', '')
                # DRS launchStatus values: PENDING, IN_PROGRESS, LAUNCHED, FAILED, TERMINATED
                # For TERMINATE jobs: TERMINATED = success, FAILED = failure
                if launch_status == 'TERMINATED':
                    job_completed += 1
                elif launch_status == 'FAILED':
                    job_failed += 1
                    any_failed = True
                # Log for debugging
                print(f"  Server launchStatus: {launch_status}")
            
            total_servers += job_total
            completed_servers += job_completed
            
            # Job is complete if status is COMPLETED
            if status not in ['COMPLETED']:
                all_completed = False
            
            job_details.append({
                'jobId': job_id,
                'status': status,
                'type': job_type,
                'totalServers': job_total,
                'completedServers': job_completed,
                'failedServers': job_failed
            })
        
        # Calculate percentage
        progress_percent = 0
        if total_servers > 0:
            progress_percent = int((completed_servers / total_servers) * 100)
        
        # If all jobs completed, set to 100%
        if all_completed:
            progress_percent = 100
        
        result = {
            'executionId': execution_id,
            'jobs': job_details,
            'totalServers': total_servers,
            'completedServers': completed_servers,
            'progressPercent': progress_percent,
            'allCompleted': all_completed,
            'anyFailed': any_failed
        }
        
        print(f"Termination progress: {progress_percent}% ({completed_servers}/{total_servers})")
        
        return response(200, result)
        
    except Exception as e:
        print(f"Error getting termination job status: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def delete_completed_executions() -> Dict:
    """
    Delete all completed executions (terminal states only)
    
    Safe operation that only removes:
    - COMPLETED executions
    - PARTIAL executions (some servers failed)
    - FAILED executions
    - CANCELLED executions (only if no active DRS jobs)
    
    Active executions (PENDING, POLLING, INITIATED, LAUNCHING, IN_PROGRESS, RUNNING) are preserved.
    Cancelled executions with active DRS jobs are also preserved to prevent orphaned jobs.
    """
    try:
        print("Starting bulk delete of completed executions")
        
        # Define terminal states that are safe to delete
        # Only delete truly completed executions, NOT active ones
        terminal_states = ['COMPLETED', 'PARTIAL', 'FAILED', 'CANCELLED', 'TIMEOUT']
        # Active states to preserve (never delete)
        active_states = ['PENDING', 'POLLING', 'INITIATED', 'LAUNCHING', 'STARTED', 'IN_PROGRESS', 'RUNNING', 'PAUSED', 'CANCELLING']
        
        # Scan for all executions
        scan_result = execution_history_table.scan()
        all_executions = scan_result.get('Items', [])
        
        # Handle pagination if there are more results
        while 'LastEvaluatedKey' in scan_result:
            scan_result = execution_history_table.scan(
                ExclusiveStartKey=scan_result['LastEvaluatedKey']
            )
            all_executions.extend(scan_result.get('Items', []))
        
        print(f"Found {len(all_executions)} total executions")
        
        # Filter to only completed executions
        completed_executions = [
            ex for ex in all_executions 
            if ex.get('Status', '').upper() in terminal_states
        ]
        
        # For CANCELLED executions, check if they have active DRS jobs
        # This prevents deleting executions that still have running DRS jobs
        safe_to_delete = []
        skipped_with_active_jobs = []
        
        for ex in completed_executions:
            status = ex.get('Status', '').upper()
            if status == 'CANCELLED':
                # Check if any wave has an active DRS job
                has_active_job = False
                for wave in ex.get('Waves', []):
                    job_id = wave.get('JobId')
                    if job_id:
                        # Get region from wave or default
                        region = wave.get('Region', 'us-east-1')
                        try:
                            drs_client = create_drs_client(region)
                            job_response = drs_client.describe_jobs(filters={'jobIDs': [job_id]})
                            jobs = job_response.get('items', [])
                            if jobs:
                                job_status = jobs[0].get('status', '')
                                if job_status in ['PENDING', 'STARTED']:
                                    has_active_job = True
                                    print(f"Execution {ex.get('ExecutionId')} has active DRS job {job_id} (status: {job_status})")
                                    break
                        except Exception as e:
                            print(f"Error checking DRS job {job_id}: {e}")
                            # If we can't check, be safe and skip
                            has_active_job = True
                            break
                
                if has_active_job:
                    skipped_with_active_jobs.append(ex.get('ExecutionId'))
                else:
                    safe_to_delete.append(ex)
            else:
                safe_to_delete.append(ex)
        
        if skipped_with_active_jobs:
            print(f"Skipping {len(skipped_with_active_jobs)} cancelled executions with active DRS jobs: {skipped_with_active_jobs}")
        
        print(f"Found {len(safe_to_delete)} executions safe to delete")
        
        # Delete safe executions (DynamoDB requires ExecutionId + PlanId for delete)
        deleted_count = 0
        failed_deletes = []
        
        for execution in safe_to_delete:
            execution_id = execution.get('ExecutionId')
            plan_id = execution.get('PlanId')
            
            if not execution_id or not plan_id:
                print(f"Skipping execution with missing keys: {execution}")
                continue
            
            try:
                execution_history_table.delete_item(
                    Key={
                        'ExecutionId': execution_id,
                        'PlanId': plan_id
                    }
                )
                deleted_count += 1
                print(f"Deleted execution: {execution_id}")
            except Exception as delete_error:
                error_msg = str(delete_error)
                print(f"Failed to delete execution {execution_id}: {error_msg}")
                failed_deletes.append({
                    'executionId': execution_id,
                    'error': error_msg
                })
        
        # Build response
        result = {
            'message': 'Completed executions cleared successfully',
            'deletedCount': deleted_count,
            'totalScanned': len(all_executions),
            'completedFound': len(completed_executions),
            'safeToDelete': len(safe_to_delete),
            'skippedWithActiveJobs': len(skipped_with_active_jobs),
            'activePreserved': len(all_executions) - len(completed_executions)
        }
        
        if skipped_with_active_jobs:
            result['skippedExecutionIds'] = skipped_with_active_jobs
            result['warning'] = f'{len(skipped_with_active_jobs)} cancelled execution(s) skipped due to active DRS jobs'
        
        if failed_deletes:
            result['failedDeletes'] = failed_deletes
            if 'warning' in result:
                result['warning'] += f'; {len(failed_deletes)} execution(s) failed to delete'
            else:
                result['warning'] = f'{len(failed_deletes)} execution(s) failed to delete'
        
        print(f"Bulk delete completed: {deleted_count} deleted, {len(skipped_with_active_jobs)} skipped (active jobs), {len(failed_deletes)} failed")
        return response(200, result)
        
    except Exception as e:
        print(f"Error deleting completed executions: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {
            'error': 'DELETE_FAILED',
            'message': f'Failed to delete completed executions: {str(e)}'
        })


# ============================================================================
# DRS Source Servers Handler (AUTOMATIC DISCOVERY)
# ============================================================================

def handle_drs_source_servers(query_params: Dict) -> Dict:
    """Route DRS source servers discovery requests"""
    region = query_params.get('region')
    current_pg_id = query_params.get('currentProtectionGroupId')
    filter_by_pg = query_params.get('filterByProtectionGroup')  # NEW: Filter mode
    
    if not region:
        return response(400, {'error': 'region parameter is required'})
    
    # NEW: If filtering by PG, return only that PG's servers
    if filter_by_pg:
        return get_protection_group_servers(filter_by_pg, region)
    
    return list_source_servers(region, current_pg_id)


def list_source_servers(region: str, current_pg_id: Optional[str] = None) -> Dict:
    """
    Discover DRS source servers in a region and track assignments
    
    Returns:
    - All DRS source servers in region
    - Assignment status for each server
    - DRS initialization status
    """
    print(f"Listing source servers for region: {region}")
    
    try:
        # 1. Query DRS for source servers
        drs_client = boto3.client('drs', region_name=region)
        
        try:
            servers_response = drs_client.describe_source_servers(maxResults=200)
            drs_initialized = True
        except drs_client.exceptions.UninitializedAccountException:
            print(f"DRS not initialized in {region}")
            return response(400, {
                'error': 'DRS_NOT_INITIALIZED',
                'message': f'AWS Elastic Disaster Recovery (DRS) is not initialized in {region}. Go to the DRS Console in {region} and complete the initialization wizard before creating Protection Groups.',
                'region': region,
                'initialized': False
            })
        except Exception as e:
            print(f"Error querying DRS: {str(e)}")
            # Check if it's an uninitialized error by message
            if 'UninitializedAccountException' in str(e) or 'not initialized' in str(e).lower():
                return response(400, {
                    'error': 'DRS_NOT_INITIALIZED',
                    'message': f'AWS Elastic Disaster Recovery (DRS) is not initialized in {region}. Go to the DRS Console in {region} and complete the initialization wizard before creating Protection Groups.',
                    'region': region,
                    'initialized': False
                })
            raise
        
        # 2. Build server list from DRS response
        servers = []
        source_instance_ids = []  # Collect instance IDs for EC2 tag lookup
        
        for item in servers_response.get('items', []):
            server_id = item['sourceServerID']
            
            # Extract server metadata
            source_props = item.get('sourceProperties', {})
            ident_hints = source_props.get('identificationHints', {})
            hostname = ident_hints.get('hostname', 'Unknown')
            fqdn = ident_hints.get('fqdn', '')
            
            # Extract source instance details
            source_instance_id = ident_hints.get('awsInstanceID', '')
            if source_instance_id:
                source_instance_ids.append(source_instance_id)
            
            # Extract network interfaces (all of them)
            network_interfaces = source_props.get('networkInterfaces', [])
            source_ip = ''
            source_mac = ''
            all_network_interfaces = []
            if network_interfaces:
                # Primary interface
                primary_nic = network_interfaces[0]
                ips = primary_nic.get('ips', [])
                if ips:
                    source_ip = ips[0]
                source_mac = primary_nic.get('macAddress', '')
                
                # All interfaces for detailed view
                for nic in network_interfaces:
                    all_network_interfaces.append({
                        'ips': nic.get('ips', []),
                        'macAddress': nic.get('macAddress', ''),
                        'isPrimary': nic.get('isPrimary', False)
                    })
            
            # Extract hardware info - CPU
            cpus = source_props.get('cpus', [])
            cpu_info = []
            total_cores = 0
            for cpu in cpus:
                cpu_info.append({
                    'modelName': cpu.get('modelName', 'Unknown'),
                    'cores': cpu.get('cores', 0)
                })
                total_cores += cpu.get('cores', 0)
            
            # Extract hardware info - RAM
            ram_bytes = source_props.get('ramBytes', 0)
            ram_gib = round(ram_bytes / (1024 ** 3), 1) if ram_bytes else 0
            
            # Extract hardware info - Disks
            disks = source_props.get('disks', [])
            disk_info = []
            total_disk_bytes = 0
            for disk in disks:
                disk_bytes = disk.get('bytes', 0)
                total_disk_bytes += disk_bytes
                disk_info.append({
                    'deviceName': disk.get('deviceName', 'Unknown'),
                    'bytes': disk_bytes,
                    'sizeGiB': round(disk_bytes / (1024 ** 3), 1) if disk_bytes else 0
                })
            total_disk_gib = round(total_disk_bytes / (1024 ** 3), 1) if total_disk_bytes else 0
            
            # Extract OS info
            os_info = source_props.get('os', {})
            os_string = os_info.get('fullString', '')
            
            # Extract source region from sourceCloudProperties
            source_cloud_props = item.get('sourceCloudProperties', {})
            source_region = source_cloud_props.get('originRegion', '')
            source_account = source_cloud_props.get('originAccountID', '')
            
            # Extract replication info
            lifecycle = item.get('lifeCycle', {})
            
            data_rep_info = item.get('dataReplicationInfo', {})
            rep_state = data_rep_info.get('dataReplicationState', 'UNKNOWN')
            lag_duration = data_rep_info.get('lagDuration', 'UNKNOWN')
            
            # Map replication state to lifecycle state for display
            state_mapping = {
                'STOPPED': 'STOPPED',
                'INITIATING': 'INITIATING',
                'INITIAL_SYNC': 'SYNCING',
                'BACKLOG': 'SYNCING',
                'CREATING_SNAPSHOT': 'SYNCING',
                'CONTINUOUS': 'READY_FOR_RECOVERY',
                'PAUSED': 'PAUSED',
                'RESCAN': 'SYNCING',
                'STALLED': 'STALLED',
                'DISCONNECTED': 'DISCONNECTED'
            }
            display_state = state_mapping.get(rep_state, rep_state)
            
            # Extract DRS tags (for tag-based selection)
            drs_tags = item.get('tags', {})
            
            servers.append({
                'sourceServerID': server_id,
                'hostname': hostname,
                'fqdn': fqdn,
                'nameTag': '',  # Will be populated from EC2 below
                'sourceInstanceId': source_instance_id,
                'sourceIp': source_ip,
                'sourceMac': source_mac,
                'sourceRegion': source_region,
                'sourceAccount': source_account,
                'os': os_string,
                'state': display_state,
                'replicationState': rep_state,
                'lagDuration': lag_duration,
                'lastSeen': lifecycle.get('lastSeenByServiceDateTime', ''),
                # Hardware details
                'hardware': {
                    'cpus': cpu_info,
                    'totalCores': total_cores,
                    'ramBytes': ram_bytes,
                    'ramGiB': ram_gib,
                    'disks': disk_info,
                    'totalDiskGiB': total_disk_gib
                },
                'networkInterfaces': all_network_interfaces,
                'drsTags': drs_tags,  # DRS resource tags for tag-based selection
                'assignedToProtectionGroup': None,  # Will be populated below
                'selectable': True  # Will be updated below
            })
        
        # 2b. Fetch ALL tags from source EC2 instances (for tag-based selection)
        ec2_tags_map = {}  # instance_id -> {tag_key: tag_value}
        if source_instance_ids:
            try:
                ec2_client = boto3.client('ec2', region_name=region)
                # Batch in groups of 200
                for i in range(0, len(source_instance_ids), 200):
                    batch = source_instance_ids[i:i+200]
                    ec2_response = ec2_client.describe_instances(InstanceIds=batch)
                    for reservation in ec2_response.get('Reservations', []):
                        for instance in reservation.get('Instances', []):
                            instance_id = instance.get('InstanceId', '')
                            # Convert tag list to dict
                            tags_dict = {t['Key']: t['Value'] for t in instance.get('Tags', [])}
                            ec2_tags_map[instance_id] = tags_dict
            except Exception as e:
                print(f"Warning: Could not fetch EC2 tags: {str(e)}")
        
        # Update servers with EC2 tags (Name tag and all other tags for filtering)
        for server in servers:
            instance_id = server['sourceInstanceId']
            if instance_id in ec2_tags_map:
                ec2_tags = ec2_tags_map[instance_id]
                server['nameTag'] = ec2_tags.get('Name', '')
                # Replace drsTags with EC2 instance tags for tag-based selection
                server['drsTags'] = ec2_tags
        
        # 3. Query ALL Protection Groups to build assignment map
        # Exclude current PG if editing (allows deselection)
        pg_response = protection_groups_table.scan()
        
        assignment_map = {}
        tag_based_pgs = []  # Track tag-based PGs for later matching
        
        for pg in pg_response.get('Items', []):
            pg_id = pg.get('GroupId') or pg.get('protectionGroupId')
            
            # Skip current PG when editing - allows deselection
            if current_pg_id and pg_id == current_pg_id:
                continue
            
            pg_name = pg.get('GroupName') or pg.get('name')
            pg_servers = pg.get('SourceServerIds') or pg.get('sourceServerIds', [])
            pg_tags = pg.get('ServerSelectionTags', {})
            
            # Track explicit server assignments
            for server_id in pg_servers:
                assignment_map[server_id] = {
                    'protectionGroupId': pg_id,
                    'protectionGroupName': pg_name,
                    'assignmentType': 'explicit'
                }
            
            # Track tag-based PGs for matching
            if pg_tags:
                tag_based_pgs.append({
                    'id': pg_id,
                    'name': pg_name,
                    'tags': pg_tags
                })
        
        # 4. Update servers with assignment info (explicit + tag-based)
        for server in servers:
            server_id = server['sourceServerID']
            
            # Check explicit assignment first
            if server_id in assignment_map:
                server['assignedToProtectionGroup'] = assignment_map[server_id]
                server['selectable'] = False
                continue
            
            # Check tag-based assignments
            server_ec2_tags = server.get('drsTags', {})
            for tag_pg in tag_based_pgs:
                pg_tags = tag_pg['tags']
                # Check if server matches ALL tags (AND logic)
                matches_all = True
                for tag_key, tag_value in pg_tags.items():
                    if server_ec2_tags.get(tag_key) != tag_value:
                        matches_all = False
                        break
                
                if matches_all:
                    server['assignedToProtectionGroup'] = {
                        'protectionGroupId': tag_pg['id'],
                        'protectionGroupName': tag_pg['name'],
                        'assignmentType': 'tag-based'
                    }
                    server['selectable'] = False
                    break  # First matching tag-based PG wins
        
        # 5. Return enhanced server list
        from datetime import datetime
        return response(200, {
            'region': region,
            'initialized': True,
            'servers': servers,
            'totalCount': len(servers),
            'availableCount': sum(1 for s in servers if s['selectable']),
            'assignedCount': sum(1 for s in servers if not s['selectable']),
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'hardwareDataIncluded': len([s for s in servers if s.get('hardware')]) > 0
        })
        
    except Exception as e:
        print(f"Error listing source servers: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {
            'error': 'INTERNAL_ERROR',
            'message': f'Failed to list source servers: {str(e)}'
        })


def get_protection_group_servers(pg_id: str, region: str) -> Dict:
    """
    Get servers that belong to a specific Protection Group.
    
    For tag-based Protection Groups, this resolves the tags to actual servers.
    
    Args:
    - pg_id: Protection Group ID
    - region: AWS region
    
    Returns:
    - Response with servers from the Protection Group (resolved from tags)
    """
    print(f"Getting servers for Protection Group: {pg_id}")
    
    try:
        # 1. Get the Protection Group
        result = protection_groups_table.get_item(Key={'GroupId': pg_id})
        
        if 'Item' not in result:
            return response(404, {
                'error': 'PROTECTION_GROUP_NOT_FOUND',
                'message': f'Protection Group {pg_id} not found'
            })
        
        pg = result['Item']
        selection_tags = pg.get('ServerSelectionTags', {})
        
        if not selection_tags:
            return response(200, {
                'region': region,
                'protectionGroupId': pg_id,
                'protectionGroupName': pg.get('GroupName'),
                'initialized': True,
                'servers': [],
                'totalCount': 0,
                'message': 'No server selection tags defined'
            })
        
        # 2. Resolve servers by tags
        # Extract account context from Protection Group
        account_context = None
        if pg.get('AccountId'):
            account_context = {
                'AccountId': pg.get('AccountId'),
                'AssumeRoleName': pg.get('AssumeRoleName')
            }
        resolved_servers = query_drs_servers_by_tags(region, selection_tags, account_context)
        
        if not resolved_servers:
            return response(200, {
                'region': region,
                'protectionGroupId': pg_id,
                'protectionGroupName': pg.get('GroupName'),
                'initialized': True,
                'servers': [],
                'totalCount': 0,
                'tags': selection_tags,
                'message': 'No servers match the specified tags'
            })
        
        # Return resolved servers
        return response(200, {
            'region': region,
            'protectionGroupId': pg_id,
            'protectionGroupName': pg.get('GroupName'),
            'initialized': True,
            'servers': resolved_servers,
            'totalCount': len(resolved_servers),
            'tags': selection_tags,
            'resolvedAt': int(time.time())
        })
        
    except Exception as e:
        print(f"Error getting Protection Group servers: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {
            'error': 'INTERNAL_ERROR',
            'message': f'Failed to get Protection Group servers: {str(e)}'
        })

def validate_server_assignments(server_ids: List[str], current_pg_id: Optional[str] = None) -> List[Dict]:
    """
    Validate that servers are not already assigned to other Protection Groups
    
    Args:
    - server_ids: List of server IDs to validate
    - current_pg_id: Optional PG ID to exclude (for edit operations)
    
    Returns:
    - conflicts: List of {serverId, protectionGroupId, protectionGroupName}
    """
    pg_response = protection_groups_table.scan()
    
    conflicts = []
    for pg in pg_response.get('Items', []):
        pg_id = pg.get('GroupId') or pg.get('protectionGroupId')
        
        # Skip current PG when editing
        if current_pg_id and pg_id == current_pg_id:
            continue
        
        assigned_servers = pg.get('SourceServerIds') or pg.get('sourceServerIds', [])
        for server_id in server_ids:
            if server_id in assigned_servers:
                pg_name = pg.get('GroupName') or pg.get('name')
                conflicts.append({
                    'serverId': server_id,
                    'protectionGroupId': pg_id,
                    'protectionGroupName': pg_name
                })
    
    return conflicts


def validate_servers_exist_in_drs(region: str, server_ids: List[str]) -> List[str]:
    """
    Validate that server IDs actually exist in DRS
    
    Args:
    - region: AWS region to check
    - server_ids: List of server IDs to validate
    
    Returns:
    - List of invalid server IDs (empty list if all valid)
    """
    try:
        drs_client = boto3.client('drs', region_name=region)
        
        # Get all source servers in the region
        response = drs_client.describe_source_servers(maxResults=200)
        valid_server_ids = {s['sourceServerID'] for s in response.get('items', [])}
        
        # Find invalid servers
        invalid_servers = [sid for sid in server_ids if sid not in valid_server_ids]
        
        if invalid_servers:
            print(f"Invalid server IDs detected: {invalid_servers}")
        
        return invalid_servers
        
    except Exception as e:
        print(f"Error validating servers in DRS: {str(e)}")
        # On error, assume servers might be valid (fail open for now)
        # In production, might want to fail closed
        return []


def validate_unique_pg_name(name: str, current_pg_id: Optional[str] = None) -> bool:
    """
    Validate that Protection Group name is unique (case-insensitive)
    
    Args:
    - name: Protection Group name to validate
    - current_pg_id: Optional PG ID to exclude (for edit operations)
    
    Returns:
    - True if unique, False if duplicate exists
    """
    pg_response = protection_groups_table.scan()
    
    name_lower = name.lower()
    for pg in pg_response.get('Items', []):
        pg_id = pg.get('GroupId') or pg.get('protectionGroupId')
        
        # Skip current PG when editing
        if current_pg_id and pg_id == current_pg_id:
            continue
        
        existing_name = pg.get('GroupName') or pg.get('name', '')
        if existing_name.lower() == name_lower:
            return False
    
    return True


def validate_unique_rp_name(name: str, current_rp_id: Optional[str] = None) -> bool:
    """
    Validate that Recovery Plan name is unique (case-insensitive)
    
    Args:
    - name: Recovery Plan name to validate
    - current_rp_id: Optional RP ID to exclude (for edit operations)
    
    Returns:
    - True if unique, False if duplicate exists
    """
    rp_response = recovery_plans_table.scan()
    
    name_lower = name.lower()
    for rp in rp_response.get('Items', []):
        rp_id = rp.get('PlanId')
        
        # Skip current RP when editing
        if current_rp_id and rp_id == current_rp_id:
            continue
        
        existing_name = rp.get('PlanName', '')
        if existing_name.lower() == name_lower:
            return False
    
    return True


# ============================================================================
# Helper Functions
# ============================================================================

def check_server_conflicts_for_create(server_ids: List[str]) -> List[Dict]:
    """Check if any servers are already assigned to other Protection Groups"""
    conflicts = []
    
    # Scan all PGs
    pg_response = protection_groups_table.scan()
    all_pgs = pg_response.get('Items', [])
    
    while 'LastEvaluatedKey' in pg_response:
        pg_response = protection_groups_table.scan(
            ExclusiveStartKey=pg_response['LastEvaluatedKey']
        )
        all_pgs.extend(pg_response.get('Items', []))
    
    for pg in all_pgs:
        existing_servers = pg.get('SourceServerIds', [])
        if not existing_servers:
            continue
        
        for server_id in server_ids:
            if server_id in existing_servers:
                conflicts.append({
                    'serverId': server_id,
                    'protectionGroupId': pg.get('GroupId'),
                    'protectionGroupName': pg.get('GroupName')
                })
    
    return conflicts


def check_server_conflicts_for_update(server_ids: List[str], current_pg_id: str) -> List[Dict]:
    """Check if any servers are already assigned to other Protection Groups (excluding current)"""
    conflicts = []
    
    # Scan all PGs
    pg_response = protection_groups_table.scan()
    all_pgs = pg_response.get('Items', [])
    
    while 'LastEvaluatedKey' in pg_response:
        pg_response = protection_groups_table.scan(
            ExclusiveStartKey=pg_response['LastEvaluatedKey']
        )
        all_pgs.extend(pg_response.get('Items', []))
    
    for pg in all_pgs:
        # Skip current PG
        if pg.get('GroupId') == current_pg_id:
            continue
        
        existing_servers = pg.get('SourceServerIds', [])
        if not existing_servers:
            continue
        
        for server_id in server_ids:
            if server_id in existing_servers:
                conflicts.append({
                    'serverId': server_id,
                    'protectionGroupId': pg.get('GroupId'),
                    'protectionGroupName': pg.get('GroupName')
                })
    
    return conflicts


def check_tag_conflicts_for_create(tags: Dict[str, str], region: str) -> List[Dict]:
    """
    Check if the specified tags would conflict with existing tag-based Protection Groups.
    A conflict occurs if another PG has the EXACT SAME tags (all keys and values match).
    """
    if not tags:
        return []
    
    conflicts = []
    
    # Scan all PGs
    pg_response = protection_groups_table.scan()
    all_pgs = pg_response.get('Items', [])
    
    while 'LastEvaluatedKey' in pg_response:
        pg_response = protection_groups_table.scan(
            ExclusiveStartKey=pg_response['LastEvaluatedKey']
        )
        all_pgs.extend(pg_response.get('Items', []))
    
    for pg in all_pgs:
        existing_tags = pg.get('ServerSelectionTags', {})
        if not existing_tags:
            continue
        
        # Check if tags are identical (exact match)
        if existing_tags == tags:
            conflicts.append({
                'protectionGroupId': pg.get('GroupId'),
                'protectionGroupName': pg.get('GroupName'),
                'conflictingTags': existing_tags,
                'conflictType': 'exact_match'
            })
    
    return conflicts


def check_tag_conflicts_for_update(tags: Dict[str, str], region: str, current_pg_id: str) -> List[Dict]:
    """
    Check if the specified tags would conflict with existing tag-based Protection Groups (excluding current).
    """
    if not tags:
        return []
    
    conflicts = []
    
    # Scan all PGs
    pg_response = protection_groups_table.scan()
    all_pgs = pg_response.get('Items', [])
    
    while 'LastEvaluatedKey' in pg_response:
        pg_response = protection_groups_table.scan(
            ExclusiveStartKey=pg_response['LastEvaluatedKey']
        )
        all_pgs.extend(pg_response.get('Items', []))
    
    for pg in all_pgs:
        # Skip current PG
        if pg.get('GroupId') == current_pg_id:
            continue
        
        existing_tags = pg.get('ServerSelectionTags', {})
        if not existing_tags:
            continue
        
        # Check if tags are identical (exact match)
        if existing_tags == tags:
            conflicts.append({
                'protectionGroupId': pg.get('GroupId'),
                'protectionGroupName': pg.get('GroupName'),
                'conflictingTags': existing_tags,
                'conflictType': 'exact_match'
            })
    
    return conflicts


def transform_pg_to_camelcase(pg: Dict) -> Dict:
    """Transform Protection Group from DynamoDB PascalCase to frontend camelCase"""
    # Convert timestamps from seconds to milliseconds for JavaScript Date()
    created_at = pg.get('CreatedDate')
    updated_at = pg.get('LastModifiedDate')
    
    # Get version for optimistic locking (default to 1 for legacy items)
    version = pg.get('Version', 1)
    if hasattr(version, '__int__'):
        version = int(version)
    
    return {
        'id': pg.get('GroupId'),
        'protectionGroupId': pg.get('GroupId'),
        'name': pg.get('GroupName'),
        'description': pg.get('Description', ''),
        'region': pg.get('Region'),
        'serverSelectionTags': pg.get('ServerSelectionTags', {}),
        'sourceServerIds': pg.get('SourceServerIds', []),  # Legacy explicit server selection
        'accountId': pg.get('AccountId', ''),
        'owner': pg.get('Owner', ''),
        'createdAt': int(created_at * 1000) if created_at else None,
        'updatedAt': int(updated_at * 1000) if updated_at else None,
        'resolvedServers': pg.get('ResolvedServers', []),
        'resolvedServerCount': pg.get('ResolvedServerCount', 0),
        'version': version,  # Optimistic locking version
        'launchConfig': pg.get('LaunchConfig')  # EC2 launch settings
    }


def transform_rp_to_camelcase(rp: Dict) -> Dict:
    """Transform Recovery Plan from DynamoDB PascalCase to frontend camelCase"""
    
    # Determine plan status based on execution history
    # - 'draft' if never executed (no LastExecutedDate)
    # - 'active' if has been executed
    status = 'active' if rp.get('LastExecutedDate') else 'draft'
    
    # Transform waves array from backend PascalCase to frontend camelCase
    waves = []
    for idx, wave in enumerate(rp.get('Waves', [])):
        # CRITICAL FIX: Defensive ServerIds extraction with recovery logic
        server_ids = wave.get('ServerIds', [])
        
        # DEFENSIVE: Ensure we have a list (boto3 deserialization issue)
        if not isinstance(server_ids, list):
            print(f"ERROR: ServerIds is not a list for wave {idx}, got type {type(server_ids)}: {server_ids}")
            # Attempt recovery: wrap in list if string, empty list otherwise
            if isinstance(server_ids, str):
                server_ids = [server_ids]
            else:
                server_ids = []
        
        # Extract dependency wave numbers from WaveId format
        depends_on_waves = []
        for dep in wave.get('Dependencies', []):
            wave_id = dep.get('DependsOnWaveId', '')
            if wave_id and '-' in wave_id:
                try:
                    wave_num = int(wave_id.split('-')[-1])
                    depends_on_waves.append(wave_num)
                except (ValueError, IndexError) as e:
                    print(f"WARNING: Failed to parse dependency wave ID '{wave_id}': {e}")
        
        waves.append({
            'waveNumber': idx,
            'name': wave.get('WaveName', ''),
            'description': wave.get('WaveDescription', ''),
            'serverIds': server_ids,  # Now guaranteed to be a list
            'executionType': wave.get('ExecutionType', 'sequential'),
            'dependsOnWaves': depends_on_waves,
            'protectionGroupId': wave.get('ProtectionGroupId'),  # camelCase for frontend
            'protectionGroupIds': [wave.get('ProtectionGroupId')] if wave.get('ProtectionGroupId') else [],  # Array format
            'pauseBeforeWave': wave.get('PauseBeforeWave', False)  # Pause before starting this wave
        })
    
    # Convert timestamps from seconds to milliseconds for JavaScript Date()
    created_at = rp.get('CreatedDate')
    updated_at = rp.get('LastModifiedDate')
    last_executed_at = rp.get('LastExecutedDate')
    last_start_time = rp.get('LastStartTime')
    last_end_time = rp.get('LastEndTime')
    
    # Get version for optimistic locking (default to 1 for legacy items)
    version = rp.get('Version', 1)
    if hasattr(version, '__int__'):
        version = int(version)
    
    # Transform conflict info if present
    conflict_info = rp.get('ConflictInfo')
    transformed_conflict = None
    if conflict_info:
        transformed_conflict = {
            'hasConflict': conflict_info.get('hasConflict', False),
            'conflictingServers': conflict_info.get('conflictingServers', []),
            'conflictingExecutionId': conflict_info.get('conflictingExecutionId'),
            'conflictingPlanId': conflict_info.get('conflictingPlanId'),
            'conflictingStatus': conflict_info.get('conflictingStatus'),
            'reason': conflict_info.get('reason')
        }
    
    return {
        'id': rp.get('PlanId'),
        'name': rp.get('PlanName'),
        'description': rp.get('Description', ''),
        'status': status,  # NEW: Draft if never executed, Active if executed
        'accountId': rp.get('AccountId'),
        'region': rp.get('Region'),
        'owner': rp.get('Owner'),
        'rpo': rp.get('RPO'),
        'rto': rp.get('RTO'),
        'waves': waves,  # Now properly transformed
        'createdAt': int(created_at * 1000) if created_at else None,
        'updatedAt': int(updated_at * 1000) if updated_at else None,
        'lastExecutedAt': int(last_executed_at * 1000) if last_executed_at else None,
        'lastExecutionStatus': rp.get('LastExecutionStatus'),  # NEW: Execution status
        'lastStartTime': last_start_time,  # NEW: Unix timestamp (seconds) - no conversion needed
        'lastEndTime': last_end_time,  # NEW: Unix timestamp (seconds) - no conversion needed
        'waveCount': len(waves),
        'hasServerConflict': rp.get('HasServerConflict', False),  # NEW: Server conflict with other executions
        'conflictInfo': transformed_conflict,  # NEW: Details about the conflict
        'version': version  # Optimistic locking version
    }


def transform_execution_to_camelcase(execution: Dict) -> Dict:
    """Transform Execution from DynamoDB PascalCase to frontend camelCase"""
    
    # Helper function to safely convert timestamp (string or int) to int
    def safe_timestamp_to_int(value):
        if value is None:
            return None
        try:
            # Handle both string and int types
            return int(value) if value else None
        except (ValueError, TypeError):
            print(f"WARNING: Invalid timestamp value: {value}")
            return None
    
    # Helper function to map execution status
    def map_execution_status(status):
        """Map backend status to frontend display status"""
        if not status:
            return 'unknown'
        
        status_upper = status.upper()
        
        # Map status for frontend display - PRESERVES DRS TERMINOLOGY
        status_mapping = {
            # Orchestration states
            'PENDING': 'pending',
            'POLLING': 'polling',
            'INITIATED': 'initiated',  # FIXED: Preserve DRS status name
            'LAUNCHING': 'launching',  # FIXED: Preserve DRS status name
            
            # DRS job states
            'STARTED': 'started',  # NEW: DRS job active status
            'IN_PROGRESS': 'in_progress',
            'RUNNING': 'running',
            
            # Terminal states
            'COMPLETED': 'completed',
            'PARTIAL': 'partial',  # Some servers failed
            'FAILED': 'failed',
            'CANCELLED': 'cancelled',
            'PAUSED': 'paused'
        }

        return status_mapping.get(status_upper, status.lower())
    
    # Transform waves array to camelCase
    waves = []
    for i, wave in enumerate(execution.get('Waves', [])):
        # Transform servers array to camelCase
        # FIX: DynamoDB stores ServerStatuses (from Step Functions) or ServerIds (legacy)
        servers = []
        
        # Build enriched server lookup map from EnrichedServers (added by enrich_execution_with_server_details)
        enriched_map = {}
        for enriched in wave.get('EnrichedServers', []):
            enriched_map[enriched.get('SourceServerId')] = enriched
        
        # First try ServerStatuses (new format from Step Functions orchestration)
        server_statuses = wave.get('ServerStatuses', [])
        if server_statuses:
            for server in server_statuses:
                server_id = server.get('SourceServerId')
                enriched = enriched_map.get(server_id, {})
                servers.append({
                    'sourceServerId': server_id,
                    'recoveryJobId': wave.get('JobId'),  # JobId is at wave level
                    'instanceId': server.get('RecoveryInstanceID'),
                    'status': server.get('LaunchStatus', 'UNKNOWN'),
                    'launchTime': safe_timestamp_to_int(wave.get('StartTime')),
                    'error': server.get('Error'),
                    # Enriched fields from DRS source server
                    'hostname': enriched.get('Hostname', ''),
                    'serverName': enriched.get('NameTag', ''),
                    'region': enriched.get('Region', wave.get('Region', '')),
                    'sourceInstanceId': enriched.get('SourceInstanceId', ''),
                    'sourceAccountId': enriched.get('SourceAccountId', ''),
                    'sourceIp': enriched.get('SourceIp', ''),
                    'sourceRegion': enriched.get('SourceRegion', ''),
                    'replicationState': enriched.get('ReplicationState', ''),
                })
        else:
            # Fallback to ServerIds (legacy format) or Servers array
            server_ids = wave.get('ServerIds', [])
            legacy_servers = wave.get('Servers', [])
            
            if legacy_servers:
                # Use legacy Servers array format
                for server in legacy_servers:
                    server_id = server.get('SourceServerId')
                    enriched = enriched_map.get(server_id, {})
                    servers.append({
                        'sourceServerId': server_id,
                        'recoveryJobId': server.get('RecoveryJobId'),
                        'instanceId': server.get('InstanceId'),
                        'status': server.get('Status', 'UNKNOWN'),
                        'launchTime': safe_timestamp_to_int(server.get('LaunchTime')),
                        'error': server.get('Error'),
                        # Enriched fields from DRS source server
                        'hostname': enriched.get('Hostname', ''),
                        'serverName': enriched.get('NameTag', ''),
                        'region': enriched.get('Region', wave.get('Region', '')),
                        'sourceInstanceId': enriched.get('SourceInstanceId', ''),
                        'sourceAccountId': enriched.get('SourceAccountId', ''),
                        'sourceIp': enriched.get('SourceIp', ''),
                        'sourceRegion': enriched.get('SourceRegion', ''),
                        'replicationState': enriched.get('ReplicationState', ''),
                    })
            elif server_ids:
                # Build servers from ServerIds list (minimal info)
                for server_id in server_ids:
                    enriched = enriched_map.get(server_id, {})
                    servers.append({
                        'sourceServerId': server_id,
                        'recoveryJobId': wave.get('JobId'),
                        'instanceId': None,
                        'status': wave.get('Status', 'UNKNOWN'),  # Use wave status
                        'launchTime': safe_timestamp_to_int(wave.get('StartTime')),
                        'error': None,
                        # Enriched fields from DRS source server
                        'hostname': enriched.get('Hostname', ''),
                        'serverName': enriched.get('NameTag', ''),
                        'region': enriched.get('Region', wave.get('Region', '')),
                        'sourceInstanceId': enriched.get('SourceInstanceId', ''),
                        'sourceAccountId': enriched.get('SourceAccountId', ''),
                        'sourceIp': enriched.get('SourceIp', ''),
                        'sourceRegion': enriched.get('SourceRegion', ''),
                        'replicationState': enriched.get('ReplicationState', ''),
                    })
        
        waves.append({
            'waveNumber': wave.get('WaveNumber', i),  # Include wave number for frontend
            'waveName': wave.get('WaveName'),
            'protectionGroupId': wave.get('ProtectionGroupId'),
            'region': wave.get('Region'),
            'status': map_execution_status(wave.get('Status')),  # Use status mapping
            'servers': servers,
            'startTime': safe_timestamp_to_int(wave.get('StartTime')),
            'endTime': safe_timestamp_to_int(wave.get('EndTime')),
            'jobId': wave.get('JobId'),  # DRS job ID for display
        })
    
    # CRITICAL FIX: Convert string timestamps to integers for JavaScript Date()
    start_time = safe_timestamp_to_int(execution.get('StartTime'))
    end_time = safe_timestamp_to_int(execution.get('EndTime'))
    
    # Calculate current wave progress
    # Use stored TotalWaves if available (set at execution creation), otherwise calculate from waves array
    total_waves = execution.get('TotalWaves') or len(waves) or 1
    current_wave = 0
    
    # Find the first wave that's not completed
    for i, wave in enumerate(waves, 1):
        wave_status = wave.get('status', '').lower()
        if wave_status in ['polling', 'initiated', 'launching', 'in_progress', 'started', 'pending']:
            current_wave = i
            break
        elif wave_status == 'completed':
            current_wave = i  # Last completed wave
    
    # If all completed or no waves, current = total
    if current_wave == 0:
        current_wave = max(1, len(waves))  # At least 1 if waves exist
    
    return {
        'executionId': execution.get('ExecutionId'),
        'recoveryPlanId': execution.get('PlanId'),
        'recoveryPlanName': execution.get('RecoveryPlanName', 'Unknown'),
        'executionType': execution.get('ExecutionType'),
        'status': map_execution_status(execution.get('Status')),  # CRITICAL FIX: Map PARTIAL → failed
        'startTime': start_time,  # Now properly converted to int
        'endTime': end_time,  # Now properly converted to int
        'initiatedBy': execution.get('InitiatedBy'),
        'waves': waves,  # Now properly transformed with fixed timestamps and status
        'currentWave': current_wave,  # FIXED: Proper wave progress calculation
        'totalWaves': total_waves,  # Use stored value from execution creation
        'errorMessage': execution.get('ErrorMessage'),
        'pausedBeforeWave': execution.get('PausedBeforeWave'),  # Wave number paused before (0-indexed)
        'selectionMode': execution.get('SelectionMode', 'PLAN'),  # TAGS or PLAN based on protection group config
        'hasActiveDrsJobs': execution.get('HasActiveDrsJobs', False)  # True if cancelled execution has active DRS jobs
    }


def validate_and_get_source_servers(account_id: str, region: str, tags: Dict) -> List[str]:
    """Validate source servers exist with specified tags and return their IDs"""
    try:
        # For now, use current account credentials
        # In production, would assume cross-account role
        drs_client = boto3.client('drs', region_name=region)
        
        # Get all source servers
        servers_response = drs_client.describe_source_servers()
        servers = servers_response.get('items', [])
        
        # Filter by tags
        matching_servers = []
        key_name = tags.get('KeyName', '')
        key_value = tags.get('KeyValue', '')
        
        for server in servers:
            server_tags = server.get('tags', {})
            if key_name in server_tags and server_tags[key_name] == key_value:
                matching_servers.append(server['sourceServerID'])
        
        return matching_servers
        
    except Exception as e:
        print(f"Error validating source servers: {str(e)}")
        raise


def get_drs_source_server_details(account_id: str, region: str, server_ids: List[str]) -> List[Dict]:
    """Get detailed information about DRS source servers"""
    try:
        drs_client = boto3.client('drs', region_name=region)
        
        servers_response = drs_client.describe_source_servers()
        all_servers = servers_response.get('items', [])
        
        # Filter to requested servers
        details = []
        for server in all_servers:
            if server['sourceServerID'] in server_ids:
                details.append({
                    'SourceServerId': server['sourceServerID'],
                    'Hostname': server.get('sourceProperties', {}).get('identificationHints', {}).get('hostname', 'Unknown'),
                    'ReplicationStatus': server.get('dataReplicationInfo', {}).get('dataReplicationState', 'Unknown'),
                    'LastSeenTime': server.get('sourceProperties', {}).get('lastUpdatedDateTime', ''),
                    'LifeCycleState': server.get('lifeCycle', {}).get('state', 'Unknown')
                })
        
        return details
        
    except Exception as e:
        print(f"Error getting server details: {str(e)}")
        return []


def validate_waves(waves: List[Dict]) -> Optional[str]:
    """Validate wave configuration - supports both single and multi-PG formats"""
    try:
        if not waves:
            return "Waves array cannot be empty"
        
        # Check for duplicate wave IDs (if present)
        wave_ids = [w.get('WaveId') for w in waves if w.get('WaveId')]
        if wave_ids and len(wave_ids) != len(set(wave_ids)):
            return "Duplicate WaveId found in waves"
        
        # Check for duplicate execution orders (if present)
        exec_orders = [w.get('ExecutionOrder') for w in waves if w.get('ExecutionOrder') is not None]
        if exec_orders and len(exec_orders) != len(set(exec_orders)):
            return "Duplicate ExecutionOrder found in waves"
        
        # Check for circular dependencies (if present)
        dependency_graph = {}
        for wave in waves:
            wave_id = wave.get('WaveId')
            if wave_id:
                dependencies = [d.get('DependsOnWaveId') for d in wave.get('Dependencies', [])]
                dependency_graph[wave_id] = dependencies
        
        if dependency_graph and has_circular_dependencies(dependency_graph):
            return "Circular dependency detected in wave configuration"
        
        # Validate each wave has required fields
        # NEW: Support both old (single PG) and new (multi-PG) formats
        for wave in waves:
            # Accept both backend (WaveId, WaveName) and frontend (waveNumber, name) formats
            if 'WaveId' not in wave and 'waveNumber' not in wave:
                return "Wave missing required field: WaveId or waveNumber"
            
            if 'WaveName' not in wave and 'name' not in wave:
                return "Wave missing required field: WaveName or name"
            
            # NEW: Accept either protectionGroupId (single) OR protectionGroupIds (multi)
            has_single_pg = 'ProtectionGroupId' in wave or 'protectionGroupId' in wave
            has_multi_pg = 'ProtectionGroupIds' in wave or 'protectionGroupIds' in wave
            
            if not has_single_pg and not has_multi_pg:
                return "Wave missing Protection Group assignment (protectionGroupId or protectionGroupIds required)"
            
            # Validate protectionGroupIds is an array if present
            pg_ids = wave.get('protectionGroupIds') or wave.get('ProtectionGroupIds')
            if pg_ids is not None:
                if not isinstance(pg_ids, list):
                    return f"protectionGroupIds must be an array, got {type(pg_ids)}"
                if len(pg_ids) == 0:
                    return "protectionGroupIds array cannot be empty"
        
        return None  # No errors
        
    except Exception as e:
        return f"Error validating waves: {str(e)}"


def has_circular_dependencies(graph: Dict[str, List[str]]) -> bool:
    """Check for circular dependencies using DFS"""
    visited = set()
    rec_stack = set()
    
    def dfs(node):
        visited.add(node)
        rec_stack.add(node)
        
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                if dfs(neighbor):
                    return True
            elif neighbor in rec_stack:
                return True
        
        rec_stack.remove(node)
        return False
    
    for node in graph:
        if node not in visited:
            if dfs(node):
                return True
    
    return False


# ============================================================================
# DRS Quotas Handler
# ============================================================================

def handle_drs_quotas(query_params: Dict) -> Dict:
    """Get DRS account quotas and current usage for an account"""
    try:
        account_id = query_params.get('accountId')
        if not account_id:
            return response(400, {'error': 'MISSING_FIELD', 'message': 'accountId query parameter is required'})
        
        # For now, we only support current account
        current_account_id = get_current_account_id()
        if account_id != current_account_id:
            return response(400, {'error': 'INVALID_ACCOUNT', 'message': f'Account {account_id} not accessible. Only current account {current_account_id} is supported.'})
        
        # Use provided region for regional operations (jobs, etc.)
        region = query_params.get('region', os.environ.get('AWS_REGION', 'us-east-1'))
        
        # Get account capacity for the specified region
        capacity = get_drs_account_capacity(region)
        
        # Get concurrent jobs info
        jobs_info = validate_concurrent_jobs(region)
        
        # Get servers in active jobs
        servers_in_jobs = validate_servers_in_all_jobs(region, 0)
        
        # Get account name (optional)
        account_name = get_account_name(account_id)
        
        return response(200, {
            'accountId': account_id,
            'accountName': account_name,
            'region': region,  # Region queried for current usage
            'limits': DRS_LIMITS,
            'capacity': capacity,  # Regional DRS capacity for selected region
            'concurrentJobs': {
                'current': jobs_info.get('currentJobs'),
                'max': jobs_info.get('maxJobs'),
                'available': jobs_info.get('availableSlots')
            },
            'serversInJobs': {
                'current': servers_in_jobs.get('currentServersInJobs'),
                'max': servers_in_jobs.get('maxServers')
            }
        })
        
    except Exception as e:
        print(f"Error getting DRS quotas: {e}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def handle_drs_accounts(query_params: Dict) -> Dict:
    """Get available DRS accounts"""
    print(f"DEBUG: handle_drs_accounts called with query_params: {query_params}")
    try:
        # For now, only return current account
        # In future, this will query cross-account roles
        current_account_id = get_current_account_id()
        print(f"DEBUG: Current account ID: {current_account_id}")
        account_name = get_account_name(current_account_id)
        print(f"DEBUG: Account name: {account_name}")
        
        accounts = [{
            'accountId': current_account_id,
            'accountName': account_name or current_account_id,
            'isCurrentAccount': True
        }]
        
        print(f"DEBUG: Returning accounts: {accounts}")
        return response(200, accounts)
        
    except Exception as e:
        print(f"ERROR: handle_drs_accounts failed: {e}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def get_current_account_id() -> str:
    """Get current AWS account ID"""
    try:
        sts_client = boto3.client('sts')
        return sts_client.get_caller_identity()['Account']
    except Exception as e:
        print(f"Error getting account ID: {e}")
        return "unknown"


def get_account_name(account_id: str) -> str:
    """Get account name/alias if available"""
    try:
        # Try to get account alias
        iam_client = boto3.client('iam')
        aliases = iam_client.list_account_aliases()['AccountAliases']
        if aliases:
            return aliases[0]
        
        # Try to get account name from Organizations (if available)
        try:
            org_client = boto3.client('organizations')
            account = org_client.describe_account(AccountId=account_id)
            return account['Account']['Name']
        except:
            # Organizations not available or no permissions
            pass
        
        # Fallback to account ID
        return None
        
    except Exception as e:
        print(f"Error getting account name: {e}")
        return None


def transform_target_account_to_camelcase(account: Dict) -> Dict:
    """Transform Target Account from DynamoDB PascalCase to frontend camelCase"""
    current_account_id = get_current_account_id()
    
    return {
        'accountId': account.get('AccountId') or account.get('accountId'),
        'accountName': account.get('AccountName') or account.get('accountName'),
        'isCurrentAccount': account.get('AccountId', account.get('accountId')) == current_account_id,
        'status': account.get('Status') or account.get('status', 'active'),
        'stagingAccountId': account.get('StagingAccountId') or account.get('stagingAccountId'),
        'crossAccountRoleArn': account.get('CrossAccountRoleArn') or account.get('crossAccountRoleArn'),
        'createdAt': account.get('CreatedAt') or account.get('createdAt'),
        'lastValidated': account.get('LastValidated') or account.get('lastValidated')
    }


def transform_target_account_from_camelcase(camel_account: Dict) -> Dict:
    """Transform Target Account from frontend camelCase to DynamoDB PascalCase"""
    pascal_account = {}
    
    if camel_account.get('accountId'):
        pascal_account['AccountId'] = camel_account['accountId']
    if camel_account.get('accountName'):
        pascal_account['AccountName'] = camel_account['accountName']
    if camel_account.get('status'):
        pascal_account['Status'] = camel_account['status']
    if camel_account.get('stagingAccountId'):
        pascal_account['StagingAccountId'] = camel_account['stagingAccountId']
    if camel_account.get('crossAccountRoleArn'):
        pascal_account['CrossAccountRoleArn'] = camel_account['crossAccountRoleArn']
    if camel_account.get('createdAt'):
        pascal_account['CreatedAt'] = camel_account['createdAt']
    if camel_account.get('lastValidated'):
        pascal_account['LastValidated'] = camel_account['lastValidated']
    
    return pascal_account


def handle_target_accounts(path: str, http_method: str, body: Dict = None, query_params: Dict = None) -> Dict:
    """Handle target account management operations"""
    try:
        # Parse path to get account ID if present
        path_parts = path.split('/')
        print(f"Target accounts handler - path: '{path}', parts: {path_parts}, method: {http_method}")
        account_id = None
        action = None
        
        if len(path_parts) >= 4:  # /accounts/targets/{accountId}
            account_id = path_parts[3]
            if len(path_parts) >= 5:  # /accounts/targets/{accountId}/{action}
                action = path_parts[4]
        
        if http_method == 'GET' and not account_id:
            # GET /accounts/targets - List all target accounts
            return get_target_accounts()
        elif http_method == 'POST' and not account_id:
            # POST /accounts/targets - Create new target account
            return create_target_account(body)
        elif http_method == 'PUT' and account_id:
            # PUT /accounts/targets/{accountId} - Update target account
            return update_target_account(account_id, body)
        elif http_method == 'DELETE' and account_id:
            # DELETE /accounts/targets/{accountId} - Delete target account
            return delete_target_account(account_id)
        elif http_method == 'POST' and account_id and action == 'validate':
            # POST /accounts/targets/{accountId}/validate - Validate target account
            return validate_target_account(account_id)
        else:
            return response(404, {'error': 'NOT_FOUND', 'message': 'Endpoint not found'})
            
    except Exception as e:
        print(f"Error in target accounts handler: {e}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def get_target_accounts() -> Dict:
    """Get all configured target accounts"""
    try:
        # Get current account info
        current_account_id = get_current_account_id()
        current_account_name = get_account_name(current_account_id)
        
        # Use account ID as fallback if name is not available
        if current_account_name is None:
            current_account_name = current_account_id
        
        # Scan target accounts table
        result = target_accounts_table.scan()
        accounts = result.get('Items', [])
        
        # Handle pagination
        while 'LastEvaluatedKey' in result:
            result = target_accounts_table.scan(
                ExclusiveStartKey=result['LastEvaluatedKey']
            )
            accounts.extend(result.get('Items', []))
        
        # Return empty list if no accounts configured
        # Users must explicitly add target accounts (including current account if it has DRS)
        # This supports deployment in shared services accounts that don't have DRS
        
        # Transform all accounts to camelCase for frontend
        camel_accounts = []
        for account in accounts:
            camel_account = transform_target_account_to_camelcase(account)
            camel_accounts.append(camel_account)
        
        return response(200, camel_accounts)
        
    except Exception as e:
        print(f"Error getting target accounts: {e}")
        return response(500, {'error': str(e)})


def create_target_account(body: Dict) -> Dict:
    """Create a new target account configuration"""
    try:
        if not body:
            return response(400, {'error': 'MISSING_BODY', 'message': 'Request body is required'})
        
        account_id = body.get('accountId')
        if not account_id:
            return response(400, {'error': 'MISSING_FIELD', 'message': 'accountId is required'})
        
        # Validate account ID format
        if not re.match(r'^\d{12}$', account_id):
            return response(400, {'error': 'INVALID_FORMAT', 'message': 'accountId must be 12 digits'})
        
        # Check if account already exists (use PascalCase for DynamoDB key)
        try:
            existing = target_accounts_table.get_item(Key={'AccountId': account_id})
            if 'Item' in existing:
                return response(400, {
                    'error': 'ACCOUNT_EXISTS', 
                    'message': f'Target account {account_id} already exists'
                })
        except Exception as e:
            print(f"Error checking existing account: {e}")
        
        # Get current account info
        current_account_id = get_current_account_id()
        account_name = body.get('accountName', '')
        
        # If no name provided, try to get account name
        if not account_name:
            if account_id == current_account_id:
                account_name = get_account_name(account_id)
            else:
                account_name = f"Account {account_id}"
        
        # Validate staging account ID if provided
        if body.get('stagingAccountId'):
            staging_account_id = body.get('stagingAccountId')
            if not re.match(r'^\d{12}$', staging_account_id):
                return response(400, {'error': 'INVALID_FORMAT', 'message': 'stagingAccountId must be 12 digits'})
        
        # Transform from camelCase to PascalCase for DynamoDB
        now = datetime.utcnow().isoformat() + 'Z'
        body_with_timestamps = {
            **body,
            'createdAt': now,
            'lastValidated': now,
            'status': 'active'
        }
        
        account_item = transform_target_account_from_camelcase(body_with_timestamps)
        
        # Store in DynamoDB
        target_accounts_table.put_item(Item=account_item)
        
        # Transform back to camelCase for response
        camel_account = transform_target_account_to_camelcase(account_item)
        
        print(f"Created target account: {account_id}")
        return response(201, camel_account)
        
    except Exception as e:
        print(f"Error creating target account: {e}")
        return response(500, {'error': str(e)})


def update_target_account(account_id: str, body: Dict) -> Dict:
    """Update target account configuration"""
    try:
        if not body:
            return response(400, {'error': 'MISSING_BODY', 'message': 'Request body is required'})
        
        # Check if account exists (use PascalCase for DynamoDB key)
        result = target_accounts_table.get_item(Key={'AccountId': account_id})
        if 'Item' not in result:
            return response(404, {'error': 'NOT_FOUND', 'message': f'Target account {account_id} not found'})
        
        existing_account = result['Item']
        
        # Validate staging account ID if provided
        if 'stagingAccountId' in body and body['stagingAccountId']:
            staging_account_id = body['stagingAccountId']
            if not re.match(r'^\d{12}$', staging_account_id):
                return response(400, {'error': 'INVALID_FORMAT', 'message': 'stagingAccountId must be 12 digits'})
        
        # Build update expression (using PascalCase for DynamoDB)
        update_expression = "SET LastValidated = :lastValidated"
        expression_values = {
            ':lastValidated': datetime.utcnow().isoformat() + 'Z'
        }
        expression_names = {}
        
        # Update account name if provided
        if 'accountName' in body:
            update_expression += ", AccountName = :accountName"
            expression_values[':accountName'] = body['accountName']
        
        # Update status if provided
        if 'status' in body and body['status'] in ['active', 'inactive']:
            update_expression += ", #status = :status"
            expression_values[':status'] = body['status']
            expression_names['#status'] = 'Status'
        
        # Update staging account if provided
        if 'stagingAccountId' in body:
            staging_account_id = body['stagingAccountId']
            if staging_account_id:
                update_expression += ", StagingAccountId = :stagingAccountId"
                expression_values[':stagingAccountId'] = staging_account_id
            else:
                # Remove staging account
                update_expression += " REMOVE StagingAccountId"
        
        # Update cross-account role ARN if provided
        if 'crossAccountRoleArn' in body:
            cross_account_role = body['crossAccountRoleArn']
            if cross_account_role:
                update_expression += ", CrossAccountRoleArn = :crossAccountRoleArn"
                expression_values[':crossAccountRoleArn'] = cross_account_role
            else:
                # Remove cross-account role
                update_expression += " REMOVE CrossAccountRoleArn"
        
        # Perform update
        update_args = {
            'Key': {'AccountId': account_id},  # Use PascalCase for DynamoDB key
            'UpdateExpression': update_expression,
            'ExpressionAttributeValues': expression_values,
            'ReturnValues': 'ALL_NEW'
        }
        
        if expression_names:
            update_args['ExpressionAttributeNames'] = expression_names
        
        result = target_accounts_table.update_item(**update_args)
        updated_account = result['Attributes']
        
        # Transform to camelCase for response
        camel_account = transform_target_account_to_camelcase(updated_account)
        
        print(f"Updated target account: {account_id}")
        return response(200, camel_account)
        
    except Exception as e:
        print(f"Error updating target account: {e}")
        return response(500, {'error': str(e)})


def delete_target_account(account_id: str) -> Dict:
    """Delete target account configuration"""
    try:
        # Check if account exists (use PascalCase for DynamoDB key)
        result = target_accounts_table.get_item(Key={'AccountId': account_id})
        if 'Item' not in result:
            return response(404, {
                'error': 'NOT_FOUND', 
                'message': f'Target account {account_id} not found'
            })
        
        # TODO: Check if account is being used in any protection groups or recovery plans
        # For now, we'll allow deletion of any account (including current account)
        # This is useful for shared services deployments where the orchestration account
        # doesn't have DRS and users need to start fresh with target accounts
        
        # Delete the account (use PascalCase for DynamoDB key)
        target_accounts_table.delete_item(Key={'AccountId': account_id})
        
        current_account_id = get_current_account_id()
        is_current = account_id == current_account_id
        account_type = "current account" if is_current else "target account"
        
        print(f"Deleted {account_type}: {account_id}")
        return response(200, {'message': f'Target account {account_id} deleted successfully'})
        
    except Exception as e:
        print(f"Error deleting target account: {e}")
        return response(500, {'error': str(e)})


def validate_target_account(account_id: str) -> Dict:
    """Validate target account access and permissions"""
    try:
        current_account_id = get_current_account_id()
        
        # Check if account exists in our configuration (use PascalCase for DynamoDB key)
        result = target_accounts_table.get_item(Key={'AccountId': account_id})
        if 'Item' not in result:
            return response(404, {
                'error': 'NOT_FOUND', 
                'message': f'Target account {account_id} not found'
            })
        
        account_config = result['Item']
        validation_results = {
            'accountId': account_id,
            'validationResults': [],
            'overallStatus': 'active',
            'lastValidated': datetime.utcnow().isoformat() + 'Z'
        }
        
        if account_id == current_account_id:
            # Validate current account by checking DRS access
            try:
                # Test DRS access in multiple regions
                test_regions = ['us-east-1', 'us-west-2', 'eu-west-1']
                for region in test_regions:
                    try:
                        drs_client = boto3.client('drs', region_name=region)
                        drs_client.describe_source_servers(maxResults=1)
                        validation_results['validationResults'].append({
                            'region': region,
                            'service': 'DRS',
                            'status': 'success',
                            'message': 'DRS access validated'
                        })
                    except Exception as region_error:
                        validation_results['validationResults'].append({
                            'region': region,
                            'service': 'DRS',
                            'status': 'warning',
                            'message': f'DRS access issue: {str(region_error)}'
                        })
                
            except Exception as drs_error:
                validation_results['overallStatus'] = 'error'
                validation_results['validationResults'].append({
                    'service': 'DRS',
                    'status': 'error',
                    'message': f'DRS validation failed: {str(drs_error)}'
                })
        else:
            # Cross-account validation
            cross_account_role = account_config.get('CrossAccountRoleArn')
            if not cross_account_role:
                validation_results['overallStatus'] = 'error'
                validation_results['validationResults'].append({
                    'service': 'IAM',
                    'status': 'error',
                    'message': 'Cross-account role ARN not configured'
                })
            else:
                # TODO: Implement cross-account role assumption and validation
                validation_results['validationResults'].append({
                    'service': 'IAM',
                    'status': 'warning',
                    'message': 'Cross-account validation not yet implemented'
                })
        
        # Update last validated timestamp in DynamoDB (use PascalCase for DynamoDB)
        try:
            target_accounts_table.update_item(
                Key={'AccountId': account_id},
                UpdateExpression='SET LastValidated = :lastValidated',
                ExpressionAttributeValues={
                    ':lastValidated': validation_results['lastValidated']
                }
            )
        except Exception as update_error:
            print(f"Warning: Could not update lastValidated timestamp: {update_error}")
        
        return response(200, validation_results)
        
    except Exception as e:
        print(f"Error validating target account: {e}")
        return response(500, {'error': str(e)})


def handle_drs_tag_sync(body: Dict = None) -> Dict:
    """Sync EC2 instance tags to DRS source servers across all regions.
    
    Runs synchronously - syncs tags from EC2 instances to their DRS source servers.
    Supports account-based operations for future multi-account support.
    """
    try:
        # Get account ID from request body (for future multi-account support)
        target_account_id = None
        if body and isinstance(body, dict):
            target_account_id = body.get('accountId')
        
        # For now, validate that we can only sync current account
        current_account_id = get_current_account_id()
        if target_account_id and target_account_id != current_account_id:
            return response(400, {
                'error': 'INVALID_ACCOUNT', 
                'message': f'Cannot sync tags for account {target_account_id}. Only current account {current_account_id} is supported.'
            })
        
        # Use current account if no account specified
        account_id = target_account_id or current_account_id
        account_name = get_account_name(account_id)
        
        total_synced = 0
        total_servers = 0
        total_failed = 0
        regions_with_servers = []
        
        print(f"Starting tag sync for account {account_id} ({account_name or 'Unknown'})")
        
        for region in DRS_REGIONS:
            try:
                result = sync_tags_in_region(region, account_id)
                if result['total'] > 0:
                    regions_with_servers.append(region)
                    total_servers += result['total']
                    total_synced += result['synced']
                    total_failed += result['failed']
                    print(f"Tag sync {region}: {result['synced']}/{result['total']} synced")
            except Exception as e:
                # Log but continue - don't fail entire sync for one region
                print(f"Tag sync {region}: skipped - {e}")
        
        summary = {
            'message': f'Tag sync complete for account {account_id}',
            'accountId': account_id,
            'accountName': account_name,
            'total_regions': len(DRS_REGIONS),
            'regions_with_servers': len(regions_with_servers),
            'total_servers': total_servers,
            'total_synced': total_synced,
            'total_failed': total_failed,
            'regions': regions_with_servers
        }
        
        print(f"Tag sync complete: {total_synced}/{total_servers} servers synced across {len(regions_with_servers)} regions")
        
        return response(200, summary)
        
    except Exception as e:
        print(f"Error in tag sync: {e}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': str(e)})


def sync_tags_in_region(drs_region: str, account_id: str = None) -> dict:
    """Sync EC2 tags to all DRS source servers in a single region.
    
    Args:
        drs_region: AWS region to sync tags in
        account_id: AWS account ID (for future multi-account support)
    """
    drs_client = boto3.client('drs', region_name=drs_region)
    ec2_clients = {}
    
    # Get all DRS source servers
    source_servers = []
    paginator = drs_client.get_paginator('describe_source_servers')
    for page in paginator.paginate(filters={}, maxResults=200):
        source_servers.extend(page.get('items', []))
    
    synced = 0
    failed = 0
    
    for server in source_servers:
        try:
            instance_id = server.get('sourceProperties', {}).get('identificationHints', {}).get('awsInstanceID')
            source_server_id = server['sourceServerID']
            server_arn = server['arn']
            source_region = server.get('sourceCloudProperties', {}).get('originRegion', drs_region)
            
            if not instance_id:
                continue
            
            # Skip disconnected servers
            replication_state = server.get('dataReplicationInfo', {}).get('dataReplicationState', '')
            if replication_state == 'DISCONNECTED':
                continue
            
            # Get or create EC2 client for source region
            if source_region not in ec2_clients:
                ec2_clients[source_region] = boto3.client('ec2', region_name=source_region)
            ec2_client = ec2_clients[source_region]
            
            # Get EC2 instance tags
            try:
                ec2_response = ec2_client.describe_instances(InstanceIds=[instance_id])
                if not ec2_response['Reservations']:
                    continue
                instance = ec2_response['Reservations'][0]['Instances'][0]
                ec2_tags = {tag['Key']: tag['Value'] for tag in instance.get('Tags', []) if not tag['Key'].startswith('aws:')}
            except Exception:
                continue
            
            if not ec2_tags:
                continue
            
            # Sync tags to DRS source server
            drs_client.tag_resource(resourceArn=server_arn, tags=ec2_tags)
            
            # Enable copyTags in launch configuration
            try:
                drs_client.update_launch_configuration(sourceServerID=source_server_id, copyTags=True)
            except Exception:
                pass
            
            synced += 1
            
        except Exception as e:
            failed += 1
            print(f"Failed to sync server {server.get('sourceServerID', 'unknown')}: {e}")
    
    return {'total': len(source_servers), 'synced': synced, 'failed': failed, 'region': drs_region}


# ============================================================================
# Launch Config Application Functions
# ============================================================================

def apply_launch_config_to_servers(server_ids: List[str], launch_config: Dict, region: str, 
                                    protection_group_id: str = None, protection_group_name: str = None) -> Dict:
    """Apply LaunchConfig to all servers' EC2 launch templates and DRS settings.
    
    Called immediately when Protection Group is saved.
    Returns summary of results for each server.
    
    Args:
        server_ids: List of DRS source server IDs
        launch_config: Dict with SubnetId, SecurityGroupIds, InstanceProfileName, etc.
        region: AWS region
        protection_group_id: Optional PG ID for version tracking
        protection_group_name: Optional PG name for version tracking
    
    Returns:
        Dict with applied, skipped, failed counts and details array
    """
    if not launch_config or not server_ids:
        return {'applied': 0, 'skipped': 0, 'failed': 0, 'details': []}
    
    regional_drs = boto3.client('drs', region_name=region)
    ec2 = boto3.client('ec2', region_name=region)
    
    results = {'applied': 0, 'skipped': 0, 'failed': 0, 'details': []}
    
    for server_id in server_ids:
        try:
            # Get DRS launch configuration to find template ID
            drs_config = regional_drs.get_launch_configuration(sourceServerID=server_id)
            template_id = drs_config.get('ec2LaunchTemplateID')
            
            if not template_id:
                results['skipped'] += 1
                results['details'].append({
                    'serverId': server_id,
                    'status': 'skipped',
                    'reason': 'No EC2 launch template found'
                })
                continue
            
            # Build EC2 template data for the new version
            template_data = {}
            
            if launch_config.get('InstanceType'):
                template_data['InstanceType'] = launch_config['InstanceType']
            
            # Network interface settings (subnet and security groups)
            if launch_config.get('SubnetId') or launch_config.get('SecurityGroupIds'):
                network_interface = {'DeviceIndex': 0}
                if launch_config.get('SubnetId'):
                    network_interface['SubnetId'] = launch_config['SubnetId']
                if launch_config.get('SecurityGroupIds'):
                    network_interface['Groups'] = launch_config['SecurityGroupIds']
                template_data['NetworkInterfaces'] = [network_interface]
            
            if launch_config.get('InstanceProfileName'):
                template_data['IamInstanceProfile'] = {'Name': launch_config['InstanceProfileName']}
            
            # IMPORTANT: Update DRS launch configuration FIRST
            # DRS update_launch_configuration creates a new EC2 launch template version,
            # so we must call it before our EC2 template updates to avoid being overwritten
            drs_update = {'sourceServerID': server_id}
            if 'CopyPrivateIp' in launch_config:
                drs_update['copyPrivateIp'] = launch_config['CopyPrivateIp']
            if 'CopyTags' in launch_config:
                drs_update['copyTags'] = launch_config['CopyTags']
            if 'Licensing' in launch_config:
                drs_update['licensing'] = launch_config['Licensing']
            if 'TargetInstanceTypeRightSizingMethod' in launch_config:
                drs_update['targetInstanceTypeRightSizingMethod'] = launch_config['TargetInstanceTypeRightSizingMethod']
            if 'LaunchDisposition' in launch_config:
                drs_update['launchDisposition'] = launch_config['LaunchDisposition']
            
            if len(drs_update) > 1:  # More than just sourceServerID
                regional_drs.update_launch_configuration(**drs_update)
            
            # THEN update EC2 launch template (after DRS, so our changes stick)
            if template_data:
                # Build detailed version description for tracking/reuse
                from datetime import datetime
                timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
                desc_parts = [f'DRS Orchestration | {timestamp}']
                if protection_group_name:
                    desc_parts.append(f'PG: {protection_group_name}')
                if protection_group_id:
                    desc_parts.append(f'ID: {protection_group_id[:8]}')
                # Add config details
                config_details = []
                if launch_config.get('InstanceType'):
                    config_details.append(f"Type:{launch_config['InstanceType']}")
                if launch_config.get('SubnetId'):
                    config_details.append(f"Subnet:{launch_config['SubnetId'][-8:]}")
                if launch_config.get('SecurityGroupIds'):
                    sg_count = len(launch_config['SecurityGroupIds'])
                    config_details.append(f"SGs:{sg_count}")
                if launch_config.get('InstanceProfileName'):
                    profile = launch_config['InstanceProfileName']
                    # Truncate long profile names
                    if len(profile) > 20:
                        profile = profile[:17] + '...'
                    config_details.append(f"Profile:{profile}")
                if launch_config.get('CopyPrivateIp'):
                    config_details.append('CopyIP')
                if launch_config.get('CopyTags'):
                    config_details.append('CopyTags')
                if launch_config.get('TargetInstanceTypeRightSizingMethod'):
                    config_details.append(f"RightSize:{launch_config['TargetInstanceTypeRightSizingMethod']}")
                if launch_config.get('LaunchDisposition'):
                    config_details.append(f"Launch:{launch_config['LaunchDisposition']}")
                if config_details:
                    desc_parts.append(' | '.join(config_details))
                # EC2 version description max 255 chars
                version_desc = ' | '.join(desc_parts)[:255]
                
                ec2.create_launch_template_version(
                    LaunchTemplateId=template_id,
                    LaunchTemplateData=template_data,
                    VersionDescription=version_desc
                )
                ec2.modify_launch_template(
                    LaunchTemplateId=template_id,
                    DefaultVersion='$Latest'
                )
            
            results['applied'] += 1
            results['details'].append({
                'serverId': server_id,
                'status': 'applied',
                'templateId': template_id
            })
            
        except Exception as e:
            print(f'Error applying LaunchConfig to {server_id}: {e}')
            results['failed'] += 1
            results['details'].append({
                'serverId': server_id,
                'status': 'failed',
                'error': str(e)
            })
    
    return results


# ============================================================================
# EC2 Resource Handlers (for Launch Config dropdowns)
# ============================================================================

def handle_ec2_resources(path: str, query_params: Dict) -> Dict:
    """Route EC2 resource requests for Launch Config dropdowns"""
    if path == '/ec2/subnets':
        return get_ec2_subnets(query_params)
    elif path == '/ec2/security-groups':
        return get_ec2_security_groups(query_params)
    elif path == '/ec2/instance-profiles':
        return get_ec2_instance_profiles(query_params)
    elif path == '/ec2/instance-types':
        return get_ec2_instance_types(query_params)
    else:
        return response(404, {'error': 'Not Found', 'path': path})


def get_ec2_subnets(query_params: Dict) -> Dict:
    """Get VPC subnets for dropdown selection."""
    region = query_params.get('region')
    
    if not region:
        return response(400, {'error': 'region is required', 'code': 'MISSING_REGION'})
    
    try:
        ec2 = boto3.client('ec2', region_name=region)
        result = ec2.describe_subnets()
        
        subnets = []
        for subnet in result['Subnets']:
            name = next(
                (t['Value'] for t in subnet.get('Tags', []) if t['Key'] == 'Name'),
                None
            )
            label = f"{subnet['SubnetId']}"
            if name:
                label = f"{name} ({subnet['SubnetId']})"
            label += f" - {subnet['CidrBlock']} - {subnet['AvailabilityZone']}"
            
            subnets.append({
                'value': subnet['SubnetId'],
                'label': label,
                'vpcId': subnet['VpcId'],
                'az': subnet['AvailabilityZone'],
                'cidr': subnet['CidrBlock']
            })
        
        subnets.sort(key=lambda x: x['label'])
        return response(200, {'subnets': subnets})
    except Exception as e:
        print(f'Error getting subnets: {e}')
        return response(500, {'error': str(e)})


def get_ec2_security_groups(query_params: Dict) -> Dict:
    """Get security groups for dropdown selection."""
    region = query_params.get('region')
    vpc_id = query_params.get('vpcId')  # Optional filter
    
    if not region:
        return response(400, {'error': 'region is required', 'code': 'MISSING_REGION'})
    
    try:
        ec2 = boto3.client('ec2', region_name=region)
        filters = [{'Name': 'vpc-id', 'Values': [vpc_id]}] if vpc_id else []
        result = ec2.describe_security_groups(Filters=filters) if filters else ec2.describe_security_groups()
        
        groups = []
        for sg in result['SecurityGroups']:
            label = f"{sg['GroupName']} ({sg['GroupId']})"
            groups.append({
                'value': sg['GroupId'],
                'label': label,
                'name': sg['GroupName'],
                'vpcId': sg['VpcId'],
                'description': sg.get('Description', '')[:100]
            })
        
        groups.sort(key=lambda x: x['name'])
        return response(200, {'securityGroups': groups})
    except Exception as e:
        print(f'Error getting security groups: {e}')
        return response(500, {'error': str(e)})


def get_ec2_instance_profiles(query_params: Dict) -> Dict:
    """Get IAM instance profiles for dropdown selection."""
    region = query_params.get('region')
    
    if not region:
        return response(400, {'error': 'region is required', 'code': 'MISSING_REGION'})
    
    try:
        # IAM is global but we accept region for consistency
        iam = boto3.client('iam')
        profiles = []
        paginator = iam.get_paginator('list_instance_profiles')
        
        for page in paginator.paginate():
            for profile in page['InstanceProfiles']:
                profiles.append({
                    'value': profile['InstanceProfileName'],
                    'label': profile['InstanceProfileName'],
                    'arn': profile['Arn']
                })
        
        profiles.sort(key=lambda x: x['label'])
        return response(200, {'instanceProfiles': profiles})
    except Exception as e:
        print(f'Error getting instance profiles: {e}')
        return response(500, {'error': str(e)})


def get_ec2_instance_types(query_params: Dict) -> Dict:
    """Get ALL EC2 instance types available in the specified region for DRS launch settings."""
    region = query_params.get('region')
    
    if not region:
        return response(400, {'error': 'region is required', 'code': 'MISSING_REGION'})
    
    try:
        ec2 = boto3.client('ec2', region_name=region)
        
        types = []
        paginator = ec2.get_paginator('describe_instance_types')
        
        # Get ALL instance types available in the region (no filtering)
        # DRS can use any instance type that's available in the target region
        for page in paginator.paginate():
            for it in page['InstanceTypes']:
                instance_type = it['InstanceType']
                vcpus = it['VCpuInfo']['DefaultVCpus']
                mem_gb = round(it['MemoryInfo']['SizeInMiB'] / 1024)
                
                # Skip bare metal instances as they're typically not used for DRS recovery
                # and can cause confusion in the dropdown
                if '.metal' in instance_type:
                    continue
                
                types.append({
                    'value': instance_type,
                    'label': f"{instance_type} ({vcpus} vCPU, {mem_gb} GB)",
                    'vcpus': vcpus,
                    'memoryGb': mem_gb
                })
        
        # Sort by family then by vcpus for better organization
        types.sort(key=lambda x: (x['value'].split('.')[0], x['vcpus']))
        
        print(f"Retrieved {len(types)} instance types for region {region}")
        return response(200, {'instanceTypes': types})
        
    except Exception as e:
        print(f'Error getting instance types for region {region}: {e}')
        return response(500, {'error': str(e)})


# ============================================================================
# Configuration Export/Import Handlers
# ============================================================================

SCHEMA_VERSION = "1.0"
SUPPORTED_SCHEMA_VERSIONS = ["1.0"]


def handle_config(method: str, path: str, body: Dict, query_params: Dict) -> Dict:
    """Route configuration export/import requests"""
    if path == '/config/export' and method == 'GET':
        return export_configuration(query_params)
    elif path == '/config/import' and method == 'POST':
        return import_configuration(body)
    else:
        return response(405, {'error': 'Method Not Allowed'})


def export_configuration(query_params: Dict) -> Dict:
    """
    Export all Protection Groups and Recovery Plans to JSON format.
    
    Returns complete configuration with metadata for backup/migration.
    """
    try:
        import datetime
        
        # Get source region from environment or default
        source_region = os.environ.get('AWS_REGION', 'us-east-1')
        
        # Scan all Protection Groups
        pg_result = protection_groups_table.scan()
        protection_groups = pg_result.get('Items', [])
        while 'LastEvaluatedKey' in pg_result:
            pg_result = protection_groups_table.scan(
                ExclusiveStartKey=pg_result['LastEvaluatedKey']
            )
            protection_groups.extend(pg_result.get('Items', []))
        
        # Scan all Recovery Plans
        rp_result = recovery_plans_table.scan()
        recovery_plans = rp_result.get('Items', [])
        while 'LastEvaluatedKey' in rp_result:
            rp_result = recovery_plans_table.scan(
                ExclusiveStartKey=rp_result['LastEvaluatedKey']
            )
            recovery_plans.extend(rp_result.get('Items', []))
        
        # Build PG ID -> Name mapping for wave export
        pg_id_to_name = {
            pg.get('GroupId', ''): pg.get('GroupName', '')
            for pg in protection_groups
        }
        
        # Transform Protection Groups for export (exclude internal fields)
        exported_pgs = []
        for pg in protection_groups:
            exported_pg = {
                'GroupName': pg.get('GroupName', ''),
                'Description': pg.get('Description', ''),
                'Region': pg.get('Region', ''),
                'AccountId': pg.get('AccountId', ''),
                'Owner': pg.get('Owner', ''),
            }
            # Include server selection method (mutually exclusive)
            if pg.get('SourceServerIds'):
                exported_pg['SourceServerIds'] = pg['SourceServerIds']
            if pg.get('ServerSelectionTags'):
                exported_pg['ServerSelectionTags'] = pg['ServerSelectionTags']
            # Include LaunchConfig if present
            if pg.get('LaunchConfig'):
                exported_pg['LaunchConfig'] = pg['LaunchConfig']
            exported_pgs.append(exported_pg)
        
        # Transform Recovery Plans for export (resolve PG IDs to names)
        exported_rps = []
        orphaned_pg_ids = []
        for rp in recovery_plans:
            # Transform waves to include ProtectionGroupName
            exported_waves = []
            for wave in rp.get('Waves', []):
                exported_wave = dict(wave)
                pg_id = wave.get('ProtectionGroupId', '')
                if pg_id:
                    if pg_id in pg_id_to_name:
                        exported_wave['ProtectionGroupName'] = pg_id_to_name[pg_id]
                        # Remove ID - use name only for portability
                        exported_wave.pop('ProtectionGroupId', None)
                    else:
                        # Keep ID if name can't be resolved (orphaned reference)
                        orphaned_pg_ids.append(pg_id)
                        print(f"Warning: PG ID '{pg_id}' not found - keeping ID in export")
                exported_waves.append(exported_wave)
            
            exported_rp = {
                'PlanName': rp.get('PlanName', ''),
                'Description': rp.get('Description', ''),
                'Waves': exported_waves,
            }
            exported_rps.append(exported_rp)
        
        if orphaned_pg_ids:
            print(f"Export contains {len(orphaned_pg_ids)} orphaned PG references")
        
        # Build export payload
        export_data = {
            'metadata': {
                'schemaVersion': SCHEMA_VERSION,
                'exportedAt': datetime.datetime.utcnow().isoformat() + 'Z',
                'sourceRegion': source_region,
                'exportedBy': 'api',
            },
            'protectionGroups': exported_pgs,
            'recoveryPlans': exported_rps,
        }
        
        return response(200, export_data)
        
    except Exception as e:
        print(f"Error exporting configuration: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': 'Failed to export configuration', 'details': str(e)})


def import_configuration(body: Dict) -> Dict:
    """
    Import Protection Groups and Recovery Plans from JSON configuration.
    
    Non-destructive, additive-only operation:
    - Skips resources that already exist (by name)
    - Validates server existence and conflicts
    - Supports dry_run mode for validation without changes
    
    Returns detailed results with created, skipped, and failed resources.
    """
    try:
        import datetime
        
        correlation_id = str(uuid.uuid4())
        print(f"[{correlation_id}] Starting configuration import")
        
        # Extract parameters
        dry_run = body.get('dryRun', False)
        config = body.get('config', body)  # Support both wrapped and direct format
        
        # Validate schema version
        metadata = config.get('metadata', {})
        schema_version = metadata.get('schemaVersion', '')
        
        if not schema_version:
            return response(400, {
                'error': 'Missing schemaVersion in metadata',
                'supportedVersions': SUPPORTED_SCHEMA_VERSIONS
            })
        
        if schema_version not in SUPPORTED_SCHEMA_VERSIONS:
            return response(400, {
                'error': f'Unsupported schema version: {schema_version}',
                'supportedVersions': SUPPORTED_SCHEMA_VERSIONS
            })
        
        # Get import data
        import_pgs = config.get('protectionGroups', [])
        import_rps = config.get('recoveryPlans', [])
        
        # Load existing data for conflict detection
        existing_pgs = _get_existing_protection_groups()
        existing_rps = _get_existing_recovery_plans()
        active_execution_servers = _get_active_execution_servers()
        
        # Track results
        results = {
            'success': True,
            'dryRun': dry_run,
            'correlationId': correlation_id,
            'summary': {
                'protectionGroups': {'created': 0, 'skipped': 0, 'failed': 0},
                'recoveryPlans': {'created': 0, 'skipped': 0, 'failed': 0},
            },
            'created': [],
            'skipped': [],
            'failed': [],
        }
        
        # Track which PGs were successfully created/exist for RP dependency resolution
        available_pg_names = set(existing_pgs.keys())
        failed_pg_names = set()
        
        # Build name->ID mapping from existing PGs (case-insensitive keys)
        pg_name_to_id = {
            name.lower(): pg.get('GroupId', '') 
            for name, pg in existing_pgs.items()
        }
        
        # Process Protection Groups first (RPs depend on them)
        for pg in import_pgs:
            pg_result = _process_protection_group_import(
                pg, existing_pgs, active_execution_servers, dry_run, correlation_id
            )
            
            if pg_result['status'] == 'created':
                results['created'].append(pg_result)
                results['summary']['protectionGroups']['created'] += 1
                pg_name = pg.get('GroupName', '')
                available_pg_names.add(pg_name)
                # Add newly created PG to name->ID mapping
                new_pg_id = pg_result.get('details', {}).get('groupId', '')
                if new_pg_id:
                    pg_name_to_id[pg_name.lower()] = new_pg_id
            elif pg_result['status'] == 'skipped':
                results['skipped'].append(pg_result)
                results['summary']['protectionGroups']['skipped'] += 1
            else:  # failed
                results['failed'].append(pg_result)
                results['summary']['protectionGroups']['failed'] += 1
                failed_pg_names.add(pg.get('GroupName', ''))
                results['success'] = False
        
        # Process Recovery Plans (with name->ID resolution)
        for rp in import_rps:
            rp_result = _process_recovery_plan_import(
                rp, existing_rps, available_pg_names, failed_pg_names, 
                pg_name_to_id, dry_run, correlation_id
            )
            
            if rp_result['status'] == 'created':
                results['created'].append(rp_result)
                results['summary']['recoveryPlans']['created'] += 1
            elif rp_result['status'] == 'skipped':
                results['skipped'].append(rp_result)
                results['summary']['recoveryPlans']['skipped'] += 1
            else:  # failed
                results['failed'].append(rp_result)
                results['summary']['recoveryPlans']['failed'] += 1
                results['success'] = False
        
        print(f"[{correlation_id}] Import complete: {results['summary']}")
        return response(200, results)
        
    except Exception as e:
        print(f"Error importing configuration: {str(e)}")
        import traceback
        traceback.print_exc()
        return response(500, {'error': 'Failed to import configuration', 'details': str(e)})


def _get_existing_protection_groups() -> Dict[str, Dict]:
    """Get all existing Protection Groups indexed by name (case-insensitive)"""
    result = protection_groups_table.scan()
    pgs = result.get('Items', [])
    while 'LastEvaluatedKey' in result:
        result = protection_groups_table.scan(ExclusiveStartKey=result['LastEvaluatedKey'])
        pgs.extend(result.get('Items', []))
    return {pg.get('GroupName', '').lower(): pg for pg in pgs}


def _get_existing_recovery_plans() -> Dict[str, Dict]:
    """Get all existing Recovery Plans indexed by name (case-insensitive)"""
    result = recovery_plans_table.scan()
    rps = result.get('Items', [])
    while 'LastEvaluatedKey' in result:
        result = recovery_plans_table.scan(ExclusiveStartKey=result['LastEvaluatedKey'])
        rps.extend(result.get('Items', []))
    return {rp.get('PlanName', '').lower(): rp for rp in rps}


def _get_active_execution_servers() -> Dict[str, Dict]:
    """Get servers involved in active executions with execution details"""
    # Query executions with active statuses
    active_statuses = ['PENDING', 'POLLING', 'INITIATED', 'LAUNCHING', 'STARTED', 
                       'IN_PROGRESS', 'RUNNING', 'PAUSED']
    
    servers = {}
    for status in active_statuses:
        try:
            result = execution_history_table.query(
                IndexName='StatusIndex',
                KeyConditionExpression='#s = :status',
                ExpressionAttributeNames={'#s': 'Status'},
                ExpressionAttributeValues={':status': status}
            )
            for exec_item in result.get('Items', []):
                exec_id = exec_item.get('ExecutionId', '')
                plan_name = exec_item.get('PlanName', '')
                exec_status = exec_item.get('Status', '')
                # Get servers from waves
                for wave in exec_item.get('Waves', []):
                    for server in wave.get('Servers', []):
                        server_id = server.get('sourceServerId', '')
                        if server_id:
                            servers[server_id] = {
                                'executionId': exec_id,
                                'planName': plan_name,
                                'status': exec_status
                            }
        except Exception as e:
            print(f"Warning: Could not query executions for status {status}: {e}")
    
    return servers


def _get_all_assigned_servers() -> Dict[str, str]:
    """Get all servers assigned to any Protection Group"""
    result = protection_groups_table.scan()
    pgs = result.get('Items', [])
    while 'LastEvaluatedKey' in result:
        result = protection_groups_table.scan(ExclusiveStartKey=result['LastEvaluatedKey'])
        pgs.extend(result.get('Items', []))
    
    assigned = {}
    for pg in pgs:
        pg_name = pg.get('GroupName', '')
        for server_id in pg.get('SourceServerIds', []):
            assigned[server_id] = pg_name
    return assigned


def _process_protection_group_import(
    pg: Dict, 
    existing_pgs: Dict[str, Dict],
    active_execution_servers: Dict[str, Dict],
    dry_run: bool,
    correlation_id: str
) -> Dict:
    """Process a single Protection Group import"""
    pg_name = pg.get('GroupName', '')
    region = pg.get('Region', '')
    
    result = {
        'type': 'ProtectionGroup',
        'name': pg_name,
        'status': 'failed',
        'reason': '',
        'details': {}
    }
    
    # Check if already exists
    if pg_name.lower() in existing_pgs:
        result['status'] = 'skipped'
        result['reason'] = 'ALREADY_EXISTS'
        result['details'] = {'existingGroupId': existing_pgs[pg_name.lower()].get('GroupId', '')}
        print(f"[{correlation_id}] Skipping PG '{pg_name}': already exists")
        return result
    
    # Get server IDs to validate
    source_server_ids = pg.get('SourceServerIds', [])
    server_selection_tags = pg.get('ServerSelectionTags', {})
    
    # Validate explicit servers
    if source_server_ids:
        # Check servers exist in DRS
        try:
            regional_drs = boto3.client('drs', region_name=region)
            drs_response = regional_drs.describe_source_servers(
                filters={'sourceServerIDs': source_server_ids}
            )
            found_ids = {s['sourceServerID'] for s in drs_response.get('items', [])}
            missing = set(source_server_ids) - found_ids
            
            if missing:
                result['reason'] = 'SERVER_NOT_FOUND'
                result['details'] = {'missingServerIds': list(missing), 'region': region}
                print(f"[{correlation_id}] Failed PG '{pg_name}': missing servers {missing}")
                return result
        except Exception as e:
            if 'UninitializedAccountException' in str(e):
                result['reason'] = 'DRS_NOT_INITIALIZED'
                result['details'] = {'region': region, 'error': str(e)}
            else:
                result['reason'] = 'DRS_VALIDATION_ERROR'
                result['details'] = {'region': region, 'error': str(e)}
            print(f"[{correlation_id}] Failed PG '{pg_name}': DRS error {e}")
            return result
        
        # Check for server conflicts with existing PGs
        assigned_servers = _get_all_assigned_servers()
        conflicts = []
        for server_id in source_server_ids:
            if server_id in assigned_servers:
                conflicts.append({
                    'serverId': server_id,
                    'assignedTo': assigned_servers[server_id]
                })
        
        if conflicts:
            result['reason'] = 'SERVER_CONFLICT'
            result['details'] = {'conflicts': conflicts}
            print(f"[{correlation_id}] Failed PG '{pg_name}': server conflicts {conflicts}")
            return result
        
        # Check for conflicts with active executions
        exec_conflicts = []
        for server_id in source_server_ids:
            if server_id in active_execution_servers:
                exec_conflicts.append({
                    'serverId': server_id,
                    **active_execution_servers[server_id]
                })
        
        if exec_conflicts:
            result['reason'] = 'ACTIVE_EXECUTION_CONFLICT'
            result['details'] = {'executionConflicts': exec_conflicts}
            print(f"[{correlation_id}] Failed PG '{pg_name}': active execution conflicts")
            return result
    
    # Validate tag-based selection
    elif server_selection_tags:
        try:
            # Extract account context from request body if available
            account_context = None
            if body and body.get('AccountId'):
                account_context = {
                    'AccountId': body.get('AccountId'),
                    'AssumeRoleName': body.get('AssumeRoleName')
                }
            resolved = query_drs_servers_by_tags(region, server_selection_tags, account_context)
            if not resolved:
                result['reason'] = 'NO_TAG_MATCHES'
                result['details'] = {'tags': server_selection_tags, 'region': region, 'matchCount': 0}
                print(f"[{correlation_id}] Failed PG '{pg_name}': no servers match tags")
                return result
        except Exception as e:
            result['reason'] = 'TAG_RESOLUTION_ERROR'
            result['details'] = {'tags': server_selection_tags, 'region': region, 'error': str(e)}
            print(f"[{correlation_id}] Failed PG '{pg_name}': tag resolution error {e}")
            return result
    else:
        result['reason'] = 'NO_SELECTION_METHOD'
        result['details'] = {'message': 'Either SourceServerIds or ServerSelectionTags required'}
        return result
    
    # Create the Protection Group (unless dry run)
    if not dry_run:
        try:
            group_id = str(uuid.uuid4())
            timestamp = int(time.time())
            
            item = {
                'GroupId': group_id,
                'GroupName': pg_name,
                'Description': pg.get('Description', ''),
                'Region': region,
                'AccountId': pg.get('AccountId', ''),
                'Owner': pg.get('Owner', ''),
                'CreatedDate': timestamp,
                'LastModifiedDate': timestamp,
                'Version': 1,
            }
            
            if source_server_ids:
                item['SourceServerIds'] = source_server_ids
                item['ServerSelectionTags'] = {}
            elif server_selection_tags:
                item['ServerSelectionTags'] = server_selection_tags
                item['SourceServerIds'] = []
            
            launch_config = pg.get('LaunchConfig')
            if launch_config:
                item['LaunchConfig'] = launch_config
            
            protection_groups_table.put_item(Item=item)
            result['details'] = {'groupId': group_id}
            print(f"[{correlation_id}] Created PG '{pg_name}' with ID {group_id}")
            
            # Apply LaunchConfig to DRS servers (same as create/update)
            if launch_config:
                server_ids_to_apply = []
                if source_server_ids:
                    server_ids_to_apply = source_server_ids
                elif server_selection_tags:
                    # Extract account context from request body if available
                    account_context = None
                    if body and body.get('AccountId'):
                        account_context = {
                            'AccountId': body.get('AccountId'),
                            'AssumeRoleName': body.get('AssumeRoleName')
                        }
                    resolved = query_drs_servers_by_tags(region, server_selection_tags, account_context)
                    server_ids_to_apply = [s.get('sourceServerId') for s in resolved if s.get('sourceServerId')]
                
                if server_ids_to_apply:
                    try:
                        apply_results = apply_launch_config_to_servers(
                            server_ids_to_apply, launch_config, region,
                            protection_group_id=group_id, protection_group_name=pg_name
                        )
                        result['details']['launchConfigApplied'] = apply_results.get('applied', 0)
                        result['details']['launchConfigFailed'] = apply_results.get('failed', 0)
                        print(f"[{correlation_id}] Applied LaunchConfig to {apply_results.get('applied', 0)} servers")
                    except Exception as lc_err:
                        print(f"[{correlation_id}] Warning: Failed to apply LaunchConfig: {lc_err}")
        except Exception as e:
            result['reason'] = 'CREATE_ERROR'
            result['details'] = {'error': str(e)}
            print(f"[{correlation_id}] Failed to create PG '{pg_name}': {e}")
            return result
    else:
        result['details'] = {'wouldCreate': True}
        print(f"[{correlation_id}] [DRY RUN] Would create PG '{pg_name}'")
    
    result['status'] = 'created'
    result['reason'] = ''
    return result


def _process_recovery_plan_import(
    rp: Dict,
    existing_rps: Dict[str, Dict],
    available_pg_names: set,
    failed_pg_names: set,
    pg_name_to_id: Dict[str, str],
    dry_run: bool,
    correlation_id: str
) -> Dict:
    """Process a single Recovery Plan import
    
    Supports both ProtectionGroupId and ProtectionGroupName in waves.
    If ProtectionGroupName is provided, resolves it to ProtectionGroupId.
    """
    plan_name = rp.get('PlanName', '')
    waves = rp.get('Waves', [])
    
    result = {
        'type': 'RecoveryPlan',
        'name': plan_name,
        'status': 'failed',
        'reason': '',
        'details': {}
    }
    
    # Check if already exists
    if plan_name.lower() in existing_rps:
        result['status'] = 'skipped'
        result['reason'] = 'ALREADY_EXISTS'
        result['details'] = {'existingPlanId': existing_rps[plan_name.lower()].get('PlanId', '')}
        print(f"[{correlation_id}] Skipping RP '{plan_name}': already exists")
        return result
    
    # Validate and resolve Protection Group references in waves
    missing_pgs = []
    cascade_failed_pgs = []
    resolved_waves = []
    
    for wave in waves:
        wave_copy = dict(wave)  # Don't modify original
        pg_id = wave.get('ProtectionGroupId', '')
        pg_name = wave.get('ProtectionGroupName', '')
        
        # Try to resolve ProtectionGroupId
        resolved_pg_id = None
        resolved_pg_name = None
        
        # Case 1: ProtectionGroupId provided - validate it exists
        if pg_id:
            # Check if this ID maps to a known PG name
            for name, gid in pg_name_to_id.items():
                if gid == pg_id:
                    resolved_pg_id = pg_id
                    resolved_pg_name = name
                    break
            
            # If ID not found in mapping, it might be an old/invalid ID
            # Try to resolve via ProtectionGroupName if provided
            if not resolved_pg_id and pg_name:
                pg_name_lower = pg_name.lower()
                if pg_name_lower in pg_name_to_id:
                    resolved_pg_id = pg_name_to_id[pg_name_lower]
                    resolved_pg_name = pg_name
                    print(f"[{correlation_id}] Resolved PG '{pg_name}' from name (ID was stale)")
            
            # If still not resolved, the ID is invalid
            if not resolved_pg_id:
                # Check if we have a ProtectionGroupName to fall back to
                if not pg_name:
                    missing_pgs.append(f"ID:{pg_id}")
                    continue
        
        # Case 2: Only ProtectionGroupName provided - resolve to ID
        if not resolved_pg_id and pg_name:
            pg_name_lower = pg_name.lower()
            print(f"[{correlation_id}] Resolving PG name '{pg_name}' (lower: '{pg_name_lower}')")
            print(f"[{correlation_id}] Available PG names in mapping: {list(pg_name_to_id.keys())}")
            
            # Check if PG failed import (cascade failure)
            if pg_name in failed_pg_names:
                cascade_failed_pgs.append(pg_name)
                continue
            
            # Check if PG exists and get its ID
            if pg_name_lower in pg_name_to_id:
                resolved_pg_id = pg_name_to_id[pg_name_lower]
                resolved_pg_name = pg_name
                print(f"[{correlation_id}] Resolved '{pg_name}' -> ID '{resolved_pg_id}'")
            else:
                print(f"[{correlation_id}] PG name '{pg_name_lower}' NOT FOUND in mapping")
                missing_pgs.append(pg_name)
                continue
        
        # Case 3: Neither provided
        if not resolved_pg_id and not pg_name and not pg_id:
            # Wave without PG reference - might be valid for some use cases
            resolved_waves.append(wave_copy)
            continue
        
        # Update wave with resolved ID
        if resolved_pg_id:
            wave_copy['ProtectionGroupId'] = resolved_pg_id
            if resolved_pg_name:
                wave_copy['ProtectionGroupName'] = resolved_pg_name
            resolved_waves.append(wave_copy)
    
    if cascade_failed_pgs:
        result['reason'] = 'CASCADE_FAILURE'
        result['details'] = {
            'failedProtectionGroups': list(set(cascade_failed_pgs)),
            'message': 'Referenced Protection Groups failed to import'
        }
        print(f"[{correlation_id}] Failed RP '{plan_name}': cascade failure from PGs {cascade_failed_pgs}")
        return result
    
    if missing_pgs:
        result['reason'] = 'MISSING_PROTECTION_GROUP'
        result['details'] = {
            'missingProtectionGroups': list(set(missing_pgs)),
            'message': 'Referenced Protection Groups do not exist'
        }
        print(f"[{correlation_id}] Failed RP '{plan_name}': missing PGs {missing_pgs}")
        return result
    
    # Create the Recovery Plan (unless dry run)
    if not dry_run:
        try:
            plan_id = str(uuid.uuid4())
            timestamp = int(time.time())
            
            item = {
                'PlanId': plan_id,
                'PlanName': plan_name,
                'Description': rp.get('Description', ''),
                'Waves': resolved_waves,  # Use resolved waves with correct IDs
                'CreatedDate': timestamp,
                'LastModifiedDate': timestamp,
                'Version': 1,
            }
            
            recovery_plans_table.put_item(Item=item)
            result['details'] = {'planId': plan_id}
            print(f"[{correlation_id}] Created RP '{plan_name}' with ID {plan_id}")
        except Exception as e:
            result['reason'] = 'CREATE_ERROR'
            result['details'] = {'error': str(e)}
            print(f"[{correlation_id}] Failed to create RP '{plan_name}': {e}")
            return result
    else:
        result['details'] = {'wouldCreate': True, 'resolvedWaves': len(resolved_waves)}
        print(f"[{correlation_id}] [DRY RUN] Would create RP '{plan_name}'")
    
    result['status'] = 'created'
    result['reason'] = ''
    return result
