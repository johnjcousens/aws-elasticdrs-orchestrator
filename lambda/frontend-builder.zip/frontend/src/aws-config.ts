export const awsConfig = {
  region: 'us-east-1',
  userPoolId: 'us-east-1_RTniwsZbk',
  userPoolWebClientId: '3e5ti95j1hqlg88ctopvcuvlvv',
  identityPoolId: 'us-east-1:e369f665-d985-41b2-8c79-6c9751c50110',
  apiEndpoint: 'https://tg45ni3bm9.execute-api.us-east-1.amazonaws.com/uat'
};
